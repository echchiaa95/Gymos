// GymOS — Couche données.
// Deux modes :
//  1) Supabase (production) : les écritures sensibles passent par des fonctions
//     security definer (check_attendance, revoke_member_qr) — jamais par le client.
//  2) Local (démo) : moteur intégré qui réplique EXACTEMENT les mêmes règles métier
//     (QR permanent, session unique, cooldown, gel, expiration) — données dans localStorage.
window.GYM_STATE = { user: null, org: null, branch: null, lang: localStorage.getItem('gymos_lang') || 'fr', mode: 'local' };

window.DB = (() => {
  const conf = window.GYM_CONFIG;
  let sb = null;
  if (conf.supabaseUrl && conf.supabaseAnonKey && window.supabase) {
    sb = supabase.createClient(conf.supabaseUrl, conf.supabaseAnonKey);
    GYM_STATE.mode = 'live';
  }

  // ============================================================ LOCAL ENGINE
  const L = {
    get(k, d) { try { const v = JSON.parse(localStorage.getItem('gymos_' + k)); return v ?? d; } catch { return d; } },
    set(k, v) { localStorage.setItem('gymos_' + k, JSON.stringify(v)); },
    seed() {
      if (L.get('seeded')) return;
      const orgId = UI.uid(), branchId = UI.uid();
      L.set('org', { id: orgId, name: 'GymOS Demo Gym', settings: { expiry_alert_days: 7, inactive_days: 14, attendance_cooldown_seconds: 10, language: 'fr' } });
      L.set('branches', [{ id: branchId, org_id: orgId, name: 'Main Branch', active: true }]);
      L.set('plans', [
        { id: UI.uid(), org_id: orgId, name: 'Mensuel', price: 300, duration_days: 30, active: true },
        { id: UI.uid(), org_id: orgId, name: 'Trimestre', price: 800, duration_days: 90, active: true },
        { id: UI.uid(), org_id: orgId, name: 'Annuel', price: 2800, duration_days: 365, active: true },
        { id: UI.uid(), org_id: orgId, name: 'VIP', price: 500, duration_days: 30, active: true }
      ]);
      L.set('users', [
        { id: UI.uid(), email: 'owner@gymos.test', name: 'Gym Owner', role: 'owner', password: conf.demoPassword },
        { id: UI.uid(), email: 'manager@gymos.test', name: 'Gym Manager', role: 'manager', password: conf.demoPassword },
        { id: UI.uid(), email: 'reception@gymos.test', name: 'Reception', role: 'receptionist', password: conf.demoPassword },
        { id: UI.uid(), email: 'accountant@gymos.test', name: 'Accountant', role: 'accountant', password: conf.demoPassword },
        { id: UI.uid(), email: 'trainer@gymos.test', name: 'Coach', role: 'trainer', password: conf.demoPassword }
      ]);
      L.set('devices', [{ id: UI.uid(), org_id: orgId, branch_id: branchId, name: 'Main Entrance Tablet', type: 'tablet', device_token: 'DEMO-ENTRY-001', status: 'online', last_seen: new Date().toISOString(), active: true }]);
      ['members', 'memberships', 'membership_freezes', 'attendance', 'payments', 'expenses', 'cash_registers', 'trainers', 'trainer_clients', 'product_categories', 'products', 'inventory_movements', 'sales', 'sale_items', 'leads', 'notifications', 'member_cards', 'audit_logs', 'staff']
        .forEach(k => L.set(k, []));
      L.set('seeded', true);
    }
  };
  L.seed();
  const today = () => new Date().toISOString().slice(0, 10);
  const yesterday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return d.toISOString().slice(0, 10); };
  const local = () => GYM_STATE.mode === 'local';

  function auditLocal(action, entity, entityId, meta = {}) {
    const logs = L.get('audit_logs', []);
    logs.unshift({ id: UI.uid(), org_id: L.get('org').id, user_id: GYM_STATE.user?.id, user_name: GYM_STATE.user?.name || 'system', action, entity, entity_id: entityId, meta, created_at: new Date().toISOString() });
    L.set('audit_logs', logs.slice(0, 2000));
  }

  // État d'adhésion dérivé (règle serveur répliquée)
  function deriveMembershipState(m, ms, freezes) {
    if (!ms) return 'none';
    const cur = ms.filter(x => x.status !== 'cancelled' && x.start_date <= today()).sort((a, b) => (a.end_date < b.end_date ? 1 : -1))[0];
    if (!cur) return 'none';
    const frozen = cur.status === 'frozen' || (freezes || []).some(f => f.membership_id === cur.id && today() >= f.start_date && today() <= f.end_date);
    if (frozen) return { state: 'frozen', current: cur };
    if (cur.end_date < today()) return { state: 'expired', current: cur };
    return { state: 'active', current: cur };
  }

  async function checkAttendanceLocalImpl(qrToken, deviceToken, clientEventId) {
    if (clientEventId && L.get('attendance', []).some(a => a.client_event_id === clientEventId))
      return { ok: false, reason: 'duplicate_sync' };
    const device = L.get('devices', []).find(d => d.device_token === deviceToken && d.active);
    if (!device) return { ok: false, reason: 'device_not_found' };
    device.last_seen = new Date().toISOString(); device.status = 'online';
    L.set('devices', L.get('devices'));
    const m = L.get('members', []).find(x => x.qr_token === qrToken);
    if (!m || m.org_id !== device.org_id || m.status !== 'active') return { ok: false, reason: 'member_not_found' };
    const ms = L.get('memberships', []).filter(x => x.member_id === m.id);
    const st = deriveMembershipState(m, ms, L.get('membership_freezes', []));
    if (st === 'none') return { ok: false, reason: 'no_membership' };
    if (st.state === 'frozen') return { ok: false, reason: 'membership_frozen' };
    if (st.state === 'expired') return { ok: false, reason: 'membership_expired' };
    const cooldown = (L.get('org').settings.attendance_cooldown_seconds ?? 10);
    const all = L.get('attendance', []).filter(a => a.member_id === m.id).sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    if (all[0] && (Date.now() - new Date(all[0].created_at).getTime()) / 1000 < cooldown)
      return { ok: false, reason: 'cooldown', member: { name: m.full_name } };
    const open = all.find(a => a.check_out_at === null);
    const now = new Date().toISOString();
    const list = L.get('attendance', []);
    const memberInfo = { id: m.id, name: m.full_name, plan: st.current.plan_name, valid_until: st.current.end_date };
    if (open) {
      const idx = list.findIndex(a => a.id === open.id);
      const duration = Math.round((new Date(now) - new Date(open.check_in_at)) / 1000);
      if (idx >= 0) {
        list[idx].check_out_at = now;
        list[idx].duration_seconds = duration;
        list[idx].status = 'closed';
        L.set('attendance', list);
      }
      return { ok: true, action: 'check_out', member: memberInfo, check_in_at: open.check_in_at, check_out_at: now, duration_seconds: duration };
    }
    list.push({ id: UI.uid(), org_id: device.org_id, branch_id: device.branch_id, device_id: device.id, member_id: m.id, check_in_at: now, check_out_at: null, duration_seconds: null, status: 'open', client_event_id: clientEventId || null, created_at: now });
    L.set('attendance', list);
    return { ok: true, action: 'check_in', member: memberInfo, check_in_at: now };
  }

  // ============================================================ AUTH
  async function signIn(email, password) {
    if (local()) {
      const u = L.get('users', []).find(x => x.email.toLowerCase() === email.toLowerCase() && x.password === password);
      if (!u) throw new Error('Invalid credentials');
      const org = L.get('org'), branch = L.get('branches', [])[0];
      GYM_STATE.user = { id: u.id, email: u.email, name: u.name, role: u.role };
      GYM_STATE.org = org; GYM_STATE.branch = branch;
      sessionStorage.setItem('gymos_session', JSON.stringify(GYM_STATE.user));
      return GYM_STATE.user;
    }
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return loadProfile(data.user);
  }
  async function loadProfile(u) {
    // Read the profile first, without nested foreign-table selects. This avoids
    // a false 'Profile not found' when a related organization/branch query is
    // affected by RLS or relationship metadata.
    const { data: p, error: profileError } = await sb
      .from('profiles')
      .select('id, org_id, branch_id, full_name, role, active')
      .eq('id', u.id)
      .maybeSingle();

    if (profileError) {
      throw new Error(`Profile query failed: ${profileError.message}`);
    }
    if (!p) {
      throw new Error(`Profile not found for ${u.email}`);
    }
    if (p.active === false) {
      throw new Error('This user profile is inactive');
    }
    if (!p.org_id) {
      throw new Error('Profile has no organization');
    }

    const { data: org, error: orgError } = await sb
      .from('organizations')
      .select('id, name, settings')
      .eq('id', p.org_id)
      .maybeSingle();
    if (orgError) throw new Error(`Organization query failed: ${orgError.message}`);
    if (!org) throw new Error('Organization not found');

    let branch = null;
    if (p.branch_id) {
      const { data: b, error: branchError } = await sb
        .from('branches')
        .select('id, name, active')
        .eq('id', p.branch_id)
        .maybeSingle();
      if (branchError) throw new Error(`Branch query failed: ${branchError.message}`);
      if (!b) throw new Error('Branch not found');
      if (b.active === false) throw new Error('This branch is inactive');
      branch = { id: b.id, name: b.name };
    }

    GYM_STATE.user = { id: p.id, email: u.email, name: p.full_name, role: p.role };
    GYM_STATE.org = { id: org.id, name: org.name || 'Gym', settings: org.settings || {} };
    GYM_STATE.branch = branch;
    return GYM_STATE.user;
  }
  async function signOut() {
    sessionStorage.removeItem('gymos_session');
    GYM_STATE.user = null;
    if (sb) await sb.auth.signOut();
  }
  async function restoreSession() {
    if (local()) {
      const s = sessionStorage.getItem('gymos_session');
      if (s) { const u = JSON.parse(s); GYM_STATE.user = u; GYM_STATE.org = L.get('org'); GYM_STATE.branch = L.get('branches', [])[0]; return u; }
      return null;
    }
    const { data } = await sb.auth.getSession();
    if (data?.session?.user) return loadProfile(data.session.user);
    return null;
  }

  const orgId = () => GYM_STATE.org?.id;
  const can = (...roles) => roles.includes(GYM_STATE.user?.role);

  // ============================================================ GENERIC HELPERS
  async function sbList(table, { select = '*', filters = {}, order = null, limit = 500 } = {}) {
    let q = sb.from(table).select(select);
    for (const [k, v] of Object.entries(filters)) q = q.eq(k, v);
    if (order) q = q.order(order.col, { ascending: order.asc ?? false });
    if (limit) q = q.limit(limit);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  }
  const lList = (k) => L.get(k, []).filter(x => x.org_id === orgId());

  // ============================================================ MEMBERS
  async function listMembers({ q = '', status = 'all', planId = '', page = 1, per = 20 } = {}) {
    const needle = q.toLowerCase().trim();
    let rows;
    if (local()) {
      const ms = L.get('members', []).filter(m => m.org_id === orgId());
      const memberships = L.get('memberships', []), freezes = L.get('membership_freezes', []);
      rows = ms.map(m => {
        const st = deriveMembershipState(m, memberships.filter(x => x.member_id === m.id), freezes);
        return { ...m, mstate: st.state || 'none', current_ms: st.current || null };
      });
      if (needle) rows = rows.filter(m => m.full_name.toLowerCase().includes(needle) || m.phone.includes(needle) || m.qr_token.toLowerCase().includes(needle));
      if (status !== 'all') {
        if (status === 'archived') rows = rows.filter(m => m.status === 'archived');
        else rows = rows.filter(m => m.status === 'active' && m.mstate === status);
      }
      if (planId) rows = rows.filter(m => m.current_ms?.plan_id === planId);
      rows.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    } else {
      const { data, error } = await sb.from('members')
        .select('*, memberships!inner(id, plan_id, plan_name, start_date, end_date, status, created_at)')
        .eq('org_id', orgId()).order('created_at', { ascending: false }).limit(500);
      if (error) throw error;
      const now = today();
      rows = (data || []).map(m => {
        const ms = (m.memberships || []).filter(x => x.status !== 'cancelled' && x.start_date <= today())
        .sort((a, b) => (a.end_date < b.end_date ? 1 : -1));
        const cur = ms[0] || null;
        let mstate = 'none';
        if (cur) mstate = cur.status === 'frozen' ? 'frozen' : (cur.end_date < now ? 'expired' : 'active');
        return { ...m, memberships: undefined, mstate, current_ms: cur };
      });
      if (needle) rows = rows.filter(m => m.full_name.toLowerCase().includes(needle) || m.phone.includes(needle) || m.qr_token.toLowerCase().includes(needle));
      if (status !== 'all') {
        if (status === 'archived') rows = rows.filter(m => m.status === 'archived');
        else rows = rows.filter(m => m.status === 'active' && m.mstate === status);
      }
      if (planId) rows = rows.filter(m => m.current_ms?.plan_id === planId);
    }
    const total = rows.length;
    return { rows: rows.slice((page - 1) * per, page * per), total, pages: Math.max(1, Math.ceil(total / per)) };
  }

  async function getMember(id) {
    if (local()) {
      const m = L.get('members', []).find(x => x.id === id);
      if (!m) return null;
      const memberships = L.get('memberships', []).filter(x => x.member_id === id).sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
      const freezes = L.get('membership_freezes', []).filter(f => memberships.some(m2 => m2.id === f.membership_id));
      const attendance = L.get('attendance', []).filter(a => a.member_id === id).sort((a, b) => (a.check_in_at < b.check_in_at ? 1 : -1));
      const payments = L.get('payments', []).filter(p => p.member_id === id).sort((a, b) => (a.date < b.date ? 1 : -1));
      const visits = attendance.filter(a => a.status === 'closed').length + attendance.filter(a => a.status === 'open').length;
      const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0);
      const st = deriveMembershipState(m, memberships, freezes);
      const cards = L.get('member_cards', []).filter(c => c.member_id === id);
      return { ...m, mstate: st.state || 'none', current_ms: st.current || null, memberships, freezes, attendance, payments, visits, totalPaid, cards };
    }
    const { data: m, error } = await sb.from('members').select('*').eq('id', id).single();
    if (error || !m) return null;
    const [memberships, freezes, att, payments, cards] = await Promise.all([
      sbList('memberships', { filters: { member_id: id }, order: { col: 'created_at' } }),
      sb.from('membership_freezes').select('*').in('membership_id', (await sbList('memberships', { filters: { member_id: id } })).map(x => x.id)).then(r => r.data || []),
      sbList('attendance', { filters: { member_id: id }, order: { col: 'check_in_at' } }),
      sbList('payments', { filters: { member_id: id }, order: { col: 'date' } }),
      sbList('member_cards', { filters: { member_id: id } })
    ]);
    const now = today();
    const cur = memberships.filter(x => x.status !== 'cancelled' && x.start_date <= now)
      .sort((a,b) => (a.end_date < b.end_date ? 1 : -1))[0] || null;
    let mstate = 'none';
    if (cur) mstate = cur.status === 'frozen' || freezes.some(f => f.membership_id === cur.id && now >= f.start_date && now <= f.end_date) ? 'frozen' : (cur.end_date < now ? 'expired' : 'active');
    return { ...m, memberships, freezes, attendance: att, payments, cards, visits: att.length, totalPaid: payments.reduce((s, p) => s + Number(p.amount), 0), mstate, current_ms: cur };
  }

  async function createMember(d) {
    // d: {full_name, phone, plan_id, start_date, price, method, ...optional}
    const plan = d.plan;
    const end = new Date(d.start_date); end.setDate(end.getDate() + (plan.duration_days || 30) - 1);
    const endStr = end.toISOString().slice(0, 10);
    if (local()) {
      // Local demo mode mirrors the same all-or-nothing semantics.
      const snapshot = {
        members: L.get('members', []), memberships: L.get('memberships', []), payments: L.get('payments', []), audit_logs: L.get('audit_logs', [])
      };
      try {
        const now = new Date().toISOString();
        const m = { id: UI.uid(), org_id: orgId(), branch_id: GYM_STATE.branch?.id || L.get('branches', [])[0]?.id, full_name: d.full_name, phone: d.phone, gender: d.gender || null, dob: d.dob || null, address: d.address || null, emergency_contact: d.emergency_contact || null, notes: d.notes || null, photo_url: d.photo_url || null, status: 'active', qr_token: 'GYM-MEMBER-' + Array.from(crypto.getRandomValues(new Uint8Array(16))).map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase(), created_by: GYM_STATE.user?.id, created_at: now, updated_at: now };
        const ms = { id: UI.uid(), org_id: orgId(), member_id: m.id, plan_id: plan.id, plan_name: plan.name, price: Number(d.price), start_date: d.start_date, end_date: endStr, status: 'active', created_by: GYM_STATE.user?.id, created_at: now };
        const members = snapshot.members.slice(); members.push(m); L.set('members', members);
        const memberships = snapshot.memberships.slice(); memberships.push(ms); L.set('memberships', memberships);
        let payment = null;
        if (Number(d.price) > 0) {
          payment = { id: UI.uid(), org_id: orgId(), branch_id: m.branch_id, member_id: m.id, type: 'membership', amount: Number(d.price), method: d.method || 'cash', date: d.start_date, note: null, created_by: GYM_STATE.user?.id, created_at: now };
          const payments = snapshot.payments.slice(); payments.push(payment); L.set('payments', payments);
        }
        auditLocal('INSERT_members', 'member', m.id, { name: m.full_name });
        return { member: m, membership: ms, payment };
      } catch (e) {
        Object.entries(snapshot).forEach(([k,v]) => L.set(k,v));
        throw e;
      }
    }
    const { data, error } = await sb.rpc('create_member_with_membership', {
      p_branch_id: GYM_STATE.branch?.id || null,
      p_full_name: d.full_name,
      p_phone: d.phone,
      p_plan_id: plan.id,
      p_start_date: d.start_date,
      p_price: Number(d.price),
      p_method: d.method || 'cash',
      p_gender: d.gender || null,
      p_dob: d.dob || null,
      p_address: d.address || null,
      p_emergency_contact: d.emergency_contact || null,
      p_notes: d.notes || null,
      p_photo_url: d.photo_url || null
    });
    if (error) throw error;
    return data;
  }

  async function updateMember(id, patch) {
    delete patch.qr_token; // le QR est PERMANENT — jamais modifiable ici
    if (local()) {
      const ms = L.get('members', []).map(m => m.id === id ? { ...m, ...patch, updated_at: new Date().toISOString() } : m);
      L.set('members', ms); auditLocal('UPDATE_members', 'member', id, patch);
      return ms.find(m => m.id === id);
    }
    const { data, error } = await sb.from('members').update(patch).eq('id', id).select().single();
    if (error) throw error;
    return data;
  }

  async function setMemberArchived(id, archived) {
    return updateMember(id, { status: archived ? 'archived' : 'active' });
  }

  async function renewMembership(memberId, { plan, startDate, price, method }) {
    if (local()) {
      const snapshot = { memberships: L.get('memberships', []), payments: L.get('payments', []), audit_logs: L.get('audit_logs', []) };
      try {
        const now = new Date().toISOString();
        const memberships = snapshot.memberships.slice();
        const current = memberships.filter(x => x.member_id === memberId && x.status !== 'cancelled')
          .sort((a, b) => (a.end_date < b.end_date ? 1 : -1))[0];
        let effectiveStart = startDate;
        if (current && current.end_date >= startDate) {
          const next = new Date(current.end_date); next.setDate(next.getDate() + 1);
          effectiveStart = next.toISOString().slice(0, 10);
        }
        const end = new Date(effectiveStart); end.setDate(end.getDate() + (plan.duration_days || 30) - 1);
        const ms = { id: UI.uid(), org_id: orgId(), member_id: memberId, plan_id: plan.id, plan_name: plan.name, price: Number(price), start_date: effectiveStart, end_date: end.toISOString().slice(0, 10), status: 'active', created_by: GYM_STATE.user?.id, created_at: now };
        memberships.push(ms); L.set('memberships', memberships);
        let payment = null;
        if (Number(price) > 0) {
          payment = { id: UI.uid(), org_id: orgId(), branch_id: GYM_STATE.branch?.id, member_id: memberId, type: 'membership', amount: Number(price), method: method || 'cash', date: today(), note: 'membership renewal', created_by: GYM_STATE.user?.id, created_at: now };
          const payments = snapshot.payments.slice(); payments.push(payment); L.set('payments', payments);
        }
        auditLocal('INSERT_memberships', 'membership', ms.id, { renewed: true, plan: plan.name, previous_membership_id: current?.id || null });
        return ms;
      } catch (e) {
        Object.entries(snapshot).forEach(([k,v]) => L.set(k,v));
        throw e;
      }
    }
    const { data, error } = await sb.rpc('renew_membership_atomic', {
      p_member_id: memberId,
      p_plan_id: plan.id,
      p_start_date: startDate,
      p_price: Number(price),
      p_method: method || 'cash'
    });
    if (error) throw error;
    return data?.membership || data;
  }

  async function freezeMembership(membershipId, { startDate, endDate, reason }) {
    if (local()) {
      const fr = { id: UI.uid(), membership_id: membershipId, start_date: startDate, end_date: endDate, reason: reason || null, created_by: GYM_STATE.user?.id, created_at: new Date().toISOString() };
      const arr = L.get('membership_freezes', []); arr.push(fr); L.set('membership_freezes', arr);
      const ms = L.get('memberships', []).map(m => m.id === membershipId ? { ...m, status: 'frozen' } : m); L.set('memberships', ms);
      auditLocal('INSERT_membership_freezes', 'membership', membershipId, { start: startDate, end: endDate });
      return fr;
    }
    const { data, error } = await sb.from('membership_freezes').insert({ membership_id: membershipId, start_date: startDate, end_date: endDate, reason: reason || null, created_by: GYM_STATE.user?.id }).select().single();
    if (error) throw error;
    await sb.from('memberships').update({ status: 'frozen' }).eq('id', membershipId);
    return data;
  }

  async function unfreezeMembership(membershipId) {
    if (local()) {
      const ms = L.get('memberships', []).map(m => m.id === membershipId ? { ...m, status: m.end_date < today() ? 'expired' : 'active' } : m);
      L.set('memberships', ms);
      // clôturer les gels encore actifs (sinon la validation resterait "frozen")
      L.set('membership_freezes', L.get('membership_freezes', []).map(f =>
        f.membership_id === membershipId && f.end_date >= today() ? { ...f, end_date: yesterday() } : f));
      auditLocal('unfreeze', 'membership', membershipId, {});
      return true;
    }
    const ms = (await sbList('memberships', { filters: { id: membershipId } }))[0];
    const { error } = await sb.from('memberships').update({ status: ms.end_date < today() ? 'expired' : 'active' }).eq('id', membershipId);
    if (error) throw error;
    await sb.from('membership_freezes').delete().eq('membership_id', membershipId).gte('end_date', today());
    return true;
  }

  async function revokeQr(memberId) {
    if (local()) {
      const token = 'GYM-MEMBER-' + Array.from(crypto.getRandomValues(new Uint8Array(16))).map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
      const ms = L.get('members', []).map(m => m.id === memberId ? { ...m, qr_token: token, updated_at: new Date().toISOString() } : m);
      L.set('members', ms); auditLocal('qr_revoked', 'member', memberId, {});
      return token;
    }
    const { data, error } = await sb.rpc('revoke_member_qr', { p_member_id: memberId });
    if (error) throw error;
    return data;
  }

  async function logCard(memberId, validityLabel) {
    if (local()) {
      const c = { id: UI.uid(), member_id: memberId, file_url: null, validity_label: validityLabel, created_by: GYM_STATE.user?.id, created_at: new Date().toISOString() };
      const arr = L.get('member_cards', []); arr.unshift(c); L.set('member_cards', arr);
      auditLocal('card_generated', 'member', memberId, { validity: validityLabel });
      return c;
    }
    await sb.from('member_cards').insert({ member_id: memberId, validity_label: validityLabel, created_by: GYM_STATE.user?.id });
  }

  // ============================================================ ATTENDANCE
  // Wrapper : enregistre tous les résultats → synchro hors ligne "exactly once"
  async function checkAttendanceLocal(qrToken, deviceToken, clientEventId) {
    if (clientEventId) {
      const prev = L.get('processed_events', []).find(e => e.id === clientEventId);
      if (prev) return { ...prev.result, replayed: true };
    }
    const result = await checkAttendanceLocalImpl(qrToken, deviceToken, clientEventId);
    if (clientEventId) {
      const arr = L.get('processed_events', []);
      arr.push({ id: clientEventId, result, at: new Date().toISOString() });
      L.set('processed_events', arr.slice(-5000));
    }
    return result;
  }

  async function checkAttendance(qrToken, deviceToken, clientEventId) {
    if (local()) return checkAttendanceLocal(qrToken, deviceToken, clientEventId);
    const { data, error } = await sb.rpc('check_attendance', {
      p_qr_token: qrToken, p_device_token: deviceToken, p_client_event: clientEventId || null
    });
    if (error) throw error;
    return data;
  }

  async function occupancy() {
    if (local()) {
      const open = L.get('attendance', []).filter(a => a.org_id === orgId() && a.check_out_at === null);
      const members = L.get('members', []);
      return open.map(a => ({ ...a, member: members.find(m => m.id === a.member_id) })).filter(a => a.member);
    }
    const { data, error } = await sb.from('attendance').select('*, members(id, full_name)').eq('org_id', orgId()).is('check_out_at', null).order('check_in_at', { ascending: false });
    if (error) throw error;
    return data || [];
  }

  async function attendanceHistory({ from, to, memberId = '', branchId = '', page = 1, per = 25 } = {}) {
    let rows;
    if (local()) {
      rows = L.get('attendance', []).filter(a => a.org_id === orgId());
      const members = L.get('members', []);
      rows = rows.map(a => ({ ...a, member: members.find(m => m.id === a.member_id) }));
      if (from) rows = rows.filter(a => a.check_in_at.slice(0, 10) >= from);
      if (to) rows = rows.filter(a => a.check_in_at.slice(0, 10) <= to);
      if (memberId) rows = rows.filter(a => a.member_id === memberId);
      if (branchId) rows = rows.filter(a => a.branch_id === branchId);
      rows.sort((a, b) => (a.check_in_at < b.check_in_at ? 1 : -1));
    } else {
      let q = sb.from('attendance').select('*, members(id, full_name, qr_token)').eq('org_id', orgId()).order('check_in_at', { ascending: false }).limit(2000);
      if (from) q = q.gte('check_in_at', from);
      if (to) q = q.lte('check_in_at', to + 'T23:59:59');
      if (memberId) q = q.eq('member_id', memberId);
      if (branchId) q = q.eq('branch_id', branchId);
      const { data, error } = await q;
      if (error) throw error;
      rows = data || [];
    }
    const total = rows.length;
    return { rows: rows.slice((page - 1) * per, page * per), total, pages: Math.max(1, Math.ceil(total / per)) };
  }

  async function attendanceStats({ from, to } = {}) {
    let rows;
    if (local()) {
      rows = L.get('attendance', []).filter(a => a.org_id === orgId());
    } else {
      let q = sb.from('attendance').select('check_in_at, check_out_at, duration_seconds, member_id').eq('org_id', orgId()).limit(5000);
      if (from) q = q.gte('check_in_at', from);
      if (to) q = q.lte('check_in_at', to + 'T23:59:59');
      const { data, error } = await q; if (error) throw error;
      rows = data || [];
    }
    const inRange = rows.filter(a => (!from || a.check_in_at.slice(0, 10) >= from) && (!to || a.check_in_at.slice(0, 10) <= to));
    const visits = inRange.length;
    const closed = inRange.filter(a => a.status === 'closed' || a.check_out_at);
    const avgDur = closed.length ? closed.reduce((s, a) => s + (a.duration_seconds || 0), 0) / closed.length : 0;
    const byHour = {}, byDay = {}, byDate = {}, perMember = {};
    inRange.forEach(a => {
      const d = new Date(a.check_in_at);
      byHour[d.getHours()] = (byHour[d.getHours()] || 0) + 1;
      byDay[d.getDay()] = (byDay[d.getDay()] || 0) + 1;
      const key = a.check_in_at.slice(0, 10); byDate[key] = (byDate[key] || 0) + 1;
      perMember[a.member_id] = (perMember[a.member_id] || 0) + 1;
    });
    const peakHour = Object.entries(byHour).sort((a, b) => b[1] - a[1])[0];
    const peakDay = Object.entries(byDay).sort((a, b) => b[1] - a[1])[0];
    return { visits, avgDur, byHour, byDay, byDate, perMember, peakHour: peakHour ? Number(peakHour[0]) : null, peakDay: peakDay ? Number(peakDay[0]) : null };
  }

  async function correctAttendance(id, patch) {
    if (local()) {
      const arr = L.get('attendance', []).map(a => a.id === id ? { ...a, ...patch } : a);
      L.set('attendance', arr); auditLocal('UPDATE_attendance', 'attendance', id, patch);
      return true;
    }
    const { error } = await sb.from('attendance').update(patch).eq('id', id);
    if (error) throw error;
    return true;
  }

  // ============================================================ FINANCE
  async function recordPayment({ member_id = null, type = 'membership', amount, method = 'cash', date = today(), note = null, sale_id = null }) {
    const row = { org_id: orgId(), branch_id: GYM_STATE.branch?.id, member_id, type, amount: Number(amount), method, date, note, sale_id, created_by: GYM_STATE.user?.id };
    if (local()) {
      const p = { id: UI.uid(), ...row, created_at: new Date().toISOString() };
      const ps = L.get('payments', []); ps.push(p); L.set('payments', ps);
      auditLocal('INSERT_payments', 'payment', p.id, { amount, type });
      return p;
    }
    const { data, error } = await sb.from('payments').insert(row).select().single();
    if (error) throw error;
    return data;
  }

  async function listPayments({ from, to, type = '', memberId = '' } = {}) {
    let rows = local() ? lList('payments') : await sbList('payments', { order: { col: 'date' } });
    if (from) rows = rows.filter(p => p.date >= from);
    if (to) rows = rows.filter(p => p.date <= to);
    if (type) rows = rows.filter(p => p.type === type);
    if (memberId) rows = rows.filter(p => p.member_id === memberId);
    const members = local() ? L.get('members', []) : [];
    return rows.map(p => ({ ...p, member: p.members || members.find(m => m.id === p.member_id) || null })).sort((a, b) => (a.date < b.date ? 1 : -1));
  }

  async function addExpense({ category, amount, method = 'cash', date = today(), note = null, attachment_url = null }) {
    const row = { org_id: orgId(), branch_id: GYM_STATE.branch?.id, category, amount: Number(amount), method, date, note, attachment_url, created_by: GYM_STATE.user?.id };
    if (local()) {
      const e = { id: UI.uid(), ...row, created_at: new Date().toISOString() };
      const arr = L.get('expenses', []); arr.push(e); L.set('expenses', arr);
      auditLocal('INSERT_expenses', 'expense', e.id, { amount, category });
      return e;
    }
    const { data, error } = await sb.from('expenses').insert(row).select().single();
    if (error) throw error;
    return data;
  }

  async function listExpenses({ from, to, category = '' } = {}) {
    let rows = local() ? lList('expenses') : await sbList('expenses', { order: { col: 'date' } });
    if (from) rows = rows.filter(e => e.date >= from);
    if (to) rows = rows.filter(e => e.date <= to);
    if (category) rows = rows.filter(e => e.category === category);
    return rows.sort((a, b) => (a.date < b.date ? 1 : -1));
  }

  async function financeSummary({ from, to } = {}) {
    const [payments, expenses] = [await listPayments({ from, to }), await listExpenses({ from, to })];
    const revenue = payments.reduce((s, p) => s + Number(p.amount), 0);
    const exp = expenses.reduce((s, e) => s + Number(e.amount), 0);
    const byType = {}, byMethod = {}, byExpCat = {};
    payments.forEach(p => { byType[p.type] = (byType[p.type] || 0) + Number(p.amount); byMethod[p.method] = (byMethod[p.method] || 0) + Number(p.amount); });
    expenses.forEach(e => { byExpCat[e.category] = (byExpCat[e.category] || 0) + Number(e.amount); });
    return { revenue, expenses: exp, net: revenue - exp, byType, byMethod, byExpCat };
  }

  async function cashRegister(date = today()) {
    const branch = GYM_STATE.branch?.id;
    const regs = local() ? L.get('cash_registers', []) : await sbList('cash_registers', { filters: { branch_id: branch } });
    const reg = regs.find(r => r.date === date && (!branch || r.branch_id === branch)) ||
      { id: null, date, opening_balance: 0, actual_closing: null, closed: false };
    const [payments, expenses] = [await listPayments({ from: date, to: date }), await listExpenses({ from: date, to: date })];
    const cashIn = payments.filter(p => p.method === 'cash').reduce((s, p) => s + Number(p.amount), 0);
    const cashOut = expenses.filter(e => e.method === 'cash').reduce((s, e) => s + Number(e.amount), 0);
    const expected = Number(reg.opening_balance) + cashIn - cashOut;
    const difference = reg.actual_closing != null ? Number(reg.actual_closing) - expected : null;
    return { ...reg, cashIn, cashOut, expected, difference };
  }

  async function openRegister(opening, date = today()) {
    if (local()) {
      const arr = L.get('cash_registers', []);
      const i = arr.findIndex(r => r.date === date);
      const row = { id: i >= 0 ? arr[i].id : UI.uid(), org_id: orgId(), branch_id: GYM_STATE.branch?.id, date, opening_balance: Number(opening), actual_closing: i >= 0 ? arr[i].actual_closing : null, closed: i >= 0 ? arr[i].closed : false };
      if (i >= 0) arr[i] = row; else arr.push(row);
      L.set('cash_registers', arr); return row;
    }
    const { data, error } = await sb.from('cash_registers').upsert({ org_id: orgId(), branch_id: GYM_STATE.branch?.id, date, opening_balance: Number(opening) }, { onConflict: 'branch_id,date' }).select().single();
    if (error) throw error;
    return data;
  }

  async function closeRegister(actual, date = today()) {
    if (local()) {
      const arr = L.get('cash_registers', []);
      const i = arr.findIndex(r => r.date === date);
      if (i >= 0) { arr[i].actual_closing = Number(actual); arr[i].closed = true; arr[i].closed_at = new Date().toISOString(); arr[i].closed_by = GYM_STATE.user?.id; }
      else arr.push({ id: UI.uid(), org_id: orgId(), branch_id: GYM_STATE.branch?.id, date, opening_balance: 0, actual_closing: Number(actual), closed: true, closed_at: new Date().toISOString() });
      L.set('cash_registers', arr); auditLocal('cash_closed', 'cash_register', arr[i >= 0 ? i : arr.length - 1].id, { actual });
      return true;
    }
    const { error } = await sb.from('cash_registers').update({ actual_closing: Number(actual), closed: true, closed_at: new Date().toISOString(), closed_by: GYM_STATE.user?.id }).eq('branch_id', GYM_STATE.branch?.id).eq('date', date);
    if (error) throw error;
    return true;
  }

  // ============================================================ PRODUCTS / POS / INVENTORY
  async function listProducts() {
    let rows = local() ? lList('products') : await sbList('products', { order: { col: 'name', asc: true } });
    const cats = local() ? lList('product_categories') : await sbList('product_categories');
    return rows.map(p => ({ ...p, category: cats.find(c => c.id === p.category_id)?.name || '' }));
  }
  async function listCategories() {
    return local() ? lList('product_categories') : sbList('product_categories');
  }
  async function upsertProduct(p) {
    const row = { org_id: orgId(), category_id: p.category_id || null, name: p.name, sku: p.sku || null, purchase_price: Number(p.purchase_price) || 0, selling_price: Number(p.selling_price) || 0, stock: Number(p.stock) || 0, min_stock: Number(p.min_stock) || 0, active: p.active !== false };
    if (local()) {
      const arr = L.get('products', []);
      if (p.id) { const i = arr.findIndex(x => x.id === p.id); arr[i] = { ...arr[i], ...row }; L.set('products', arr); return arr[i]; }
      const np = { id: UI.uid(), ...row, created_at: new Date().toISOString() }; arr.push(np); L.set('products', arr); return np;
    }
    if (p.id) { const { data, error } = await sb.from('products').update(row).eq('id', p.id).select().single(); if (error) throw error; return data; }
    const { data, error } = await sb.from('products').insert(row).select().single();
    if (error) throw error;
    return data;
  }
  async function adjustStock(productId, { type, qty, note }) {
    const now = new Date().toISOString();
    if (local()) {
      const arr = L.get('products', []).map(p => {
        if (p.id !== productId) return p;
        const delta = type === 'purchase' || type === 'return' ? qty : -qty;
        return { ...p, stock: Math.max(0, p.stock + delta) };
      });
      L.set('products', arr);
      const mv = { id: UI.uid(), product_id: productId, type, qty, unit_price: 0, note, created_by: GYM_STATE.user?.id, created_at: now };
      const mvs = L.get('inventory_movements', []); mvs.push(mv); L.set('inventory_movements', mvs);
      return true;
    }
    const prod = (await sbList('products', { filters: { id: productId } }))[0];
    const delta = type === 'purchase' || type === 'return' ? qty : -qty;
    const { error } = await sb.from('products').update({ stock: Math.max(0, prod.stock + delta) }).eq('id', productId);
    if (error) throw error;
    await sb.from('inventory_movements').insert({ product_id: productId, type, qty, note, created_by: GYM_STATE.user?.id });
    return true;
  }
  async function createSale({ items, method, member_id = null }) {
    // items: [{product_id, name, qty, unit_price}]
    const total = items.reduce((s, i) => s + i.qty * i.unit_price, 0);
    const now = new Date().toISOString();
    if (local()) {
      const sale = { id: UI.uid(), org_id: orgId(), branch_id: GYM_STATE.branch?.id, member_id, total, method, created_by: GYM_STATE.user?.id, created_at: now };
      const sales = L.get('sales', []); sales.push(sale); L.set('sales', sales);
      const sis = L.get('sale_items', []);
      items.forEach(i => sis.push({ id: UI.uid(), sale_id: sale.id, product_id: i.product_id, name: i.name, qty: i.qty, unit_price: i.unit_price }));
      L.set('sale_items', sis);
      const prods = L.get('products', []).map(p => {
        const it = items.find(i => i.product_id === p.id);
        return it ? { ...p, stock: Math.max(0, p.stock - it.qty) } : p;
      });
      L.set('products', prods);
      items.forEach(i => { const mvs = L.get('inventory_movements', []); mvs.push({ id: UI.uid(), product_id: i.product_id, type: 'sale', qty: i.qty, unit_price: i.unit_price, note: 'POS', created_by: GYM_STATE.user?.id, created_at: now }); L.set('inventory_movements', mvs); });
      const payment = await recordPayment({ member_id, type: 'product_sale', amount: total, method, date: today(), note: null, sale_id: sale.id });
      auditLocal('sale', 'sale', sale.id, { total, items: items.length });
      return { sale, payment };
    }
    const { data: sale, error } = await sb.from('sales').insert({ org_id: orgId(), branch_id: GYM_STATE.branch?.id, member_id, total, method, created_by: GYM_STATE.user?.id }).select().single();
    if (error) throw error;
    await sb.from('sale_items').insert(items.map(i => ({ sale_id: sale.id, product_id: i.product_id, name: i.name, qty: i.qty, unit_price: i.unit_price })));
    for (const i of items) {
      const prod = (await sbList('products', { filters: { id: i.product_id } }))[0];
      await sb.from('products').update({ stock: Math.max(0, prod.stock - i.qty) }).eq('id', i.product_id);
      await sb.from('inventory_movements').insert({ product_id: i.product_id, type: 'sale', qty: i.qty, unit_price: i.unit_price, note: 'POS', created_by: GYM_STATE.user?.id });
    }
    const payment = await recordPayment({ member_id, type: 'product_sale', amount: total, method, date: today(), sale_id: sale.id });
    return { sale, payment };
  }
  async function listSales({ from, to } = {}) {
    let sales = local() ? lList('sales') : await sbList('sales');
    if (from) sales = sales.filter(s => s.created_at.slice(0, 10) >= from);
    if (to) sales = sales.filter(s => s.created_at.slice(0, 10) <= to);
    const items = local() ? L.get('sale_items', []) : await sbList('sale_items');
    return sales.sort((a, b) => (a.created_at < b.created_at ? 1 : -1)).map(s => ({ ...s, items: items.filter(i => i.sale_id === s.id) }));
  }

  // ============================================================ PLANS / TRAINERS / LEADS
  async function listPlans() {
    const rows = local() ? lList('plans') : await sbList('membership_plans', { order: { col: 'price', asc: true } });
    return rows.filter(p => p.active);
  }
  async function upsertPlan(p) {
    const row = { org_id: orgId(), name: p.name, price: Number(p.price), duration_days: Number(p.duration_days), description: p.description || null, active: p.active !== false };
    if (local()) {
      const arr = L.get('plans', []);
      if (p.id) { const i = arr.findIndex(x => x.id === p.id); arr[i] = { ...arr[i], ...row }; L.set('plans', arr); return arr[i]; }
      const np = { id: UI.uid(), ...row, created_at: new Date().toISOString() }; arr.push(np); L.set('plans', arr); return np;
    }
    if (p.id) { const { data, error } = await sb.from('membership_plans').update(row).eq('id', p.id).select().single(); if (error) throw error; return data; }
    const { data, error } = await sb.from('membership_plans').insert(row).select().single();
    if (error) throw error;
    return data;
  }
  async function deletePlan(id) {
    if (local()) { L.set('plans', L.get('plans', []).map(p => p.id === id ? { ...p, active: false } : p)); return; }
    const { error } = await sb.from('membership_plans').update({ active: false }).eq('id', id);
    if (error) throw error;
  }

  async function listTrainers() {
    let rows = local() ? lList('trainers') : await sbList('trainers');
    const tcs = local() ? L.get('trainer_clients', []) : await sbList('trainer_clients');
    const members = local() ? L.get('members', []) : [];
    return rows.map(tr => ({ ...tr, clients: tcs.filter(c => c.trainer_id === tr.id).map(c => ({ ...c, member: members.find(m => m.id === c.member_id) })) }));
  }
  async function upsertTrainer(tr) {
    const row = { org_id: orgId(), branch_id: GYM_STATE.branch?.id, name: tr.name, phone: tr.phone || null, specialization: tr.specialization || null, status: tr.status || 'active', notes: tr.notes || null };
    if (local()) {
      const arr = L.get('trainers', []);
      if (tr.id) { const i = arr.findIndex(x => x.id === tr.id); arr[i] = { ...arr[i], ...row }; L.set('trainers', arr); return arr[i]; }
      const nt = { id: UI.uid(), ...row, created_at: new Date().toISOString() }; arr.push(nt); L.set('trainers', arr); return nt;
    }
    if (tr.id) { const { data, error } = await sb.from('trainers').update(row).eq('id', tr.id).select().single(); if (error) throw error; return data; }
    const { data, error } = await sb.from('trainers').insert(row).select().single();
    if (error) throw error;
    return data;
  }
  async function assignClient(trainerId, memberId) {
    if (local()) {
      const arr = L.get('trainer_clients', []);
      if (arr.some(c => c.trainer_id === trainerId && c.member_id === memberId)) return;
      arr.push({ id: UI.uid(), trainer_id: trainerId, member_id: memberId, since: today() });
      L.set('trainer_clients', arr); return;
    }
    const { error } = await sb.from('trainer_clients').insert({ trainer_id: trainerId, member_id: memberId });
    if (error && error.code !== '23505') throw error;
  }

  async function listLeads() {
    return local() ? lList('leads').sort((a, b) => (a.created_at < b.created_at ? 1 : -1)) : sbList('leads', { order: { col: 'created_at' } });
  }
  async function upsertLead(l) {
    const row = { org_id: orgId(), name: l.name, phone: l.phone || null, plan_id: l.plan_id || null, source: l.source || null, status: l.status || 'new', notes: l.notes || null };
    if (local()) {
      const arr = L.get('leads', []);
      if (l.id) { const i = arr.findIndex(x => x.id === l.id); arr[i] = { ...arr[i], ...row }; L.set('leads', arr); return arr[i]; }
      const nl = { id: UI.uid(), ...row, created_at: new Date().toISOString() }; arr.push(nl); L.set('leads', arr); return nl;
    }
    if (l.id) { const { data, error } = await sb.from('leads').update(row).eq('id', l.id).select().single(); if (error) throw error; return data; }
    const { data, error } = await sb.from('leads').insert(row).select().single();
    if (error) throw error;
    return data;
  }
  async function deleteLead(id) {
    if (local()) { L.set('leads', L.get('leads', []).filter(l => l.id !== id)); return; }
    const { error } = await sb.from('leads').delete().eq('id', id);
    if (error) throw error;
  }

  // ============================================================ DEVICES / BRANCHES / STAFF / SETTINGS
  async function listDevices() {
    const rows = local() ? lList('devices') : await sbList('devices');
    return rows.map(d => ({ ...d, last_seen_label: d.last_seen ? relTime(d.last_seen) : '—' }));
  }
  function relTime(iso) {
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return `${Math.max(1, Math.round(s))}s`; if (s < 3600) return `${Math.round(s / 60)}m`;
    if (s < 86400) return `${Math.round(s / 3600)}h`; return `${Math.round(s / 86400)}d`;
  }
  async function upsertDevice(d) {
    const row = { org_id: orgId(), branch_id: d.branch_id || GYM_STATE.branch?.id, name: d.name, type: d.type || 'tablet', active: d.active !== false };
    if (local()) {
      const arr = L.get('devices', []);
      if (d.id) { const i = arr.findIndex(x => x.id === d.id); arr[i] = { ...arr[i], ...row }; L.set('devices', arr); return arr[i]; }
      const nd = { id: UI.uid(), ...row, device_token: 'DEV-' + Array.from(crypto.getRandomValues(new Uint8Array(8))).map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase(), status: 'offline', last_seen: null };
      arr.push(nd); L.set('devices', arr); return nd;
    }
    if (d.id) { const { data, error } = await sb.from('devices').update(row).eq('id', d.id).select().single(); if (error) throw error; return data; }
    const { data, error } = await sb.from('devices').insert(row).select().single();
    if (error) throw error;
    return data;
  }
  async function listBranches() {
    return local() ? L.get('branches', []) : sbList('branches');
  }
  async function addBranch(name) {
    if (local()) { const arr = L.get('branches', []); const b = { id: UI.uid(), org_id: orgId(), name, active: true }; arr.push(b); L.set('branches', arr); return b; }
    const { data, error } = await sb.from('branches').insert({ org_id: orgId(), name }).select().single();
    if (error) throw error;
    return data;
  }
  async function listAudit() {
    return local() ? L.get('audit_logs', []) : sbList('audit_logs');
  }
  async function saveSettings(patch) {
    const org = GYM_STATE.org;
    const settings = { ...org.settings, ...patch };
    if (local()) {
      const o = { ...org, settings }; L.set('org', o); GYM_STATE.org = o;
      return;
    }
    const { error } = await sb.from('organizations').update({ settings }).eq('id', org.id);
    if (error) throw error;
    GYM_STATE.org = { ...org, settings };
  }
  async function entrySnapshot(deviceToken) {
    if (local()) {
      const device = L.get('devices', []).find(d => d.device_token === deviceToken && d.active);
      if (!device) throw new Error('device_not_found');
      const members = L.get('members', []);
      const open = L.get('attendance', []).filter(a =>
        a.org_id === device.org_id && a.check_out_at === null &&
        (!device.branch_id || !a.branch_id || a.branch_id === device.branch_id)
      ).map(a => ({ id:a.id, full_name: members.find(m=>m.id===a.member_id)?.full_name || '', check_in_at:a.check_in_at }));
      const todayStart = today();
      const visits = L.get('attendance', []).filter(a => a.org_id === device.org_id && a.check_in_at >= todayStart &&
        (!device.branch_id || !a.branch_id || a.branch_id === device.branch_id)).length;
      return { inside: open, visits };
    }
    const { data, error } = await sb.rpc('get_entry_snapshot', { p_device_token: deviceToken });
    if (error) throw error;
    return data || { inside: [], visits: 0 };
  }

  async function refreshEntryCache(deviceToken) {
    if (local()) {
      const device = L.get('devices', []).find(d => d.device_token === deviceToken && d.active);
      if (!device) throw new Error('device_not_found');
      const members = L.get('members', []).filter(m =>
        m.org_id === device.org_id &&
        m.status === 'active' &&
        (!device.branch_id || !m.branch_id || m.branch_id === device.branch_id)
      );
      const memberships = L.get('memberships', []);
      const freezes = L.get('membership_freezes', []);
      return members.map(m => {
        const st = deriveMembershipState(m, memberships.filter(x => x.member_id === m.id), freezes);
        return { id:m.id, qr:m.qr_token, name:m.full_name, plan:st.current?.plan_name || '', valid:st.current?.end_date || '', state:st.state || 'none' };
      });
    }
    const { data, error } = await sb.rpc('get_entry_cache', { p_device_token: deviceToken });
    if (error) throw error;
    return (data || []).map(x => ({
      id: x.member_id, qr: x.qr_token, name: x.full_name,
      plan: x.plan_name || '', valid: x.end_date || '', state: x.state
    }));
  }

  async function registerDeviceByToken(token) {
    // Terminal /entry : associe ce navigateur à un device (sans compte staff).
    if (local()) {
      const d = L.get('devices', []).find(x => x.device_token === token && x.active);
      if (!d) throw new Error('device_not_found');
      d.last_seen = new Date().toISOString(); d.status = 'online';
      L.set('devices', L.get('devices'));
      return d;
    }
    const { data, error } = await sb.rpc('check_attendance', { p_qr_token: '__ping__', p_device_token: token, p_client_event: null });
    // check_attendance valide le device même si le QR est inconnu → on récupère le device via une lecture autorisée anon impossible.
    // Solution propre : la fonction met à jour last_seen ; on stocke juste le token localement.
    if (error) throw error;
    return { device_token: token, name: data && data.reason === 'device_not_found' ? null : 'terminal' };
  }

  // ============================================================ DASHBOARD & ALERTS
  async function dashboard() {
    const t = today();
    const monthStart = t.slice(0, 8) + '01';
    const weekStart = new Date(); weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    const wStart = weekStart.toISOString().slice(0, 10);
    const [membersRes, todaySum, monthSum, occ, attToday, attWeek, products, finToday, finMonth] = await Promise.all([
      listMembers({ per: 100000 }),
      financeSummary({ from: t, to: t }),
      financeSummary({ from: monthStart, to: t }),
      occupancy(),
      attendanceStats({ from: t, to: t }),
      attendanceStats({ from: wStart, to: t }),
      listProducts(),
      null, null
    ]);
    const rows = membersRes.rows;
    const active = rows.filter(m => m.status === 'active' && m.mstate === 'active').length;
    const expired = rows.filter(m => m.status === 'active' && m.mstate === 'expired').length;
    const frozen = rows.filter(m => m.status === 'active' && m.mstate === 'frozen').length;
    const alertDays = GYM_STATE.org.settings.expiry_alert_days || 7;
    const soon = new Date(t); soon.setDate(soon.getDate() + alertDays);
    const expiring = rows.filter(m => m.status === 'active' && m.mstate === 'active' && m.current_ms && m.current_ms.end_date <= soon.toISOString().slice(0, 10) && m.current_ms.end_date >= t);
    const newMembers = rows.filter(m => m.created_at.slice(0, 10) >= monthStart).length;
    const lowStock = products.filter(p => p.active && p.stock <= p.min_stock);
    const alerts = [];
    expiring.slice(0, 8).forEach(m => alerts.push({ kind: 'amber', icon: 'clock', text: `${m.full_name} — ${t('validUntil')} ${UI.fmtDate(m.current_ms.end_date)}`, link: `#/members/${m.id}` }));
    rows.filter(m => m.status === 'active' && m.mstate === 'expired').slice(0, 8).forEach(m => alerts.push({ kind: 'red', icon: 'warn', text: `${m.full_name} — ${t('membershipExpired')}`, link: `#/members/${m.id}` }));
    lowStock.slice(0, 8).forEach(p => alerts.push({ kind: 'red', icon: 'inventory', text: `${p.name} — ${t('lowStock')} (${p.stock})`, link: '#/inventory' }));
    return {
      members: { total: rows.filter(m => m.status === 'active').length, active, expiring: expiring.length, expired, frozen, new: newMembers },
      attendance: { inside: occ.length, today: attToday.visits, week: attWeek.visits, avgDur: attToday.avgDur, peakHour: attToday.peakHour },
      finance: { today: todaySum, month: monthSum },
      alerts, lowStock
    };
  }

  return {
    get sb() { return sb; }, isLocal: local, can, orgId, today,
    signIn, signOut, restoreSession, loadProfile,
    listMembers, getMember, createMember, updateMember, setMemberArchived,
    renewMembership, freezeMembership, unfreezeMembership, revokeQr, logCard,
    checkAttendance, occupancy, attendanceHistory, attendanceStats, correctAttendance,
    recordPayment, listPayments, addExpense, listExpenses, financeSummary,
    cashRegister, openRegister, closeRegister,
    listProducts, listCategories, upsertProduct, adjustStock, createSale, listSales,
    listPlans, upsertPlan, deletePlan,
    listTrainers, upsertTrainer, assignClient,
    listLeads, upsertLead, deleteLead,
    listDevices, upsertDevice, registerDeviceByToken, listBranches, addBranch,
    listAudit, saveSettings, dashboard,
    entrySnapshot, refreshEntryCache, relTime
  };
})();
