// GymOS — UI helpers : toasts, modals, SVG charts, formatting
window.UI = (() => {
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const icons = {
    dashboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>',
    members: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    attendance: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>',
    analytics: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 14l4-4 3 3 5-6"/></svg>',
    finance: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M15 9.5c0-1.4-1.3-2.5-3-2.5s-3 .9-3 2.2c0 3.3 6 1.5 6 4.6 0 1.3-1.3 2.2-3 2.2s-3-1.1-3-2.5"/></svg>',
    pos: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="20" r="1.6"/><circle cx="18" cy="20" r="1.6"/><path d="M2 3h3l2.6 12.4a2 2 0 0 0 2 1.6h8.7a2 2 0 0 0 2-1.6L22 7H6"/></svg>',
    inventory: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 8l-9-5-9 5v8l9 5 9-5V8z"/><path d="M3.3 8.3L12 13l8.7-4.7M12 13v9"/></svg>',
    plans: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
    trainers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6.5 6.5L4 4M17 17l-2.5-2.5M4 9l5-1 7-7 3 3-7 7-1 5-3-3"/><path d="M14 6l4 4"/></svg>',
    leads: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
    reports: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h6"/></svg>',
    audit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
    devices: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/></svg>',
    settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6L9 17l-5-5"/></svg>',
    warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>',
    bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
    user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    wallet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
    users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    trend: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 6l-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/></svg>',
    trendDown: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 18l-9.5-9.5-5 5L1 6"/><path d="M17 18h6v-6"/></svg>',
    qr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14h1M14 20h1M20 20h1M17 20v1"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 5v14M5 12h14"/></svg>',
    printer: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>',
    download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg>',
    share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98"/></svg>',
    wa: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.65.07-.3-.15-1.25-.46-2.4-1.47-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51-.17-.01-.37-.01-.57-.01-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.5 0 1.47 1.07 2.9 1.22 3.1.15.2 2.1 3.2 5.1 4.49.71.31 1.27.49 1.7.63.72.23 1.37.2 1.88.12.58-.09 1.76-.72 2.01-1.42.25-.7.25-1.29.17-1.42-.07-.13-.27-.2-.57-.35m-5.42 7.4h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88a9.82 9.82 0 0 1 9.88 9.89c0 5.45-4.43 9.88-9.88 9.88m8.42-18.3A11.82 11.82 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.9c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.9 11.9 0 0 0 5.68 1.45h.01c6.55 0 11.89-5.34 11.89-11.9 0-3.18-1.24-6.16-3.47-8.41"/></svg>',
    box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 8l-9-5-9 5v8l9 5 9-5V8z"/><path d="M3.3 8.3L12 13l8.7-4.7M12 13v9"/></svg>',
    store: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l1.7-5h14.6L21 9M3 9h18M3 9v11a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V9"/><path d="M9 21v-7h6v7"/></svg>',
    lang: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>'
  };
  const icon = (n) => icons[n] || icons.box;

  function toast(msg, kind = 'ok', ms = 3200) {
    let root = document.getElementById('toasts');
    if (!root) { root = document.createElement('div'); root.id = 'toasts'; document.body.appendChild(root); }
    const el = document.createElement('div');
    el.className = `toast ${kind}`;
    el.innerHTML = `${icon(kind === 'err' ? 'warn' : 'check')}<span>${esc(msg)}</span>`;
    root.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 320); }, ms);
  }

  // Modal — returns {el, close}; onSubmit may return a Promise; button shows spinner, form kept on error.
  function modal({ title, sub = '', body, actions = null, wide = false, onSubmit = null, submitLabel = null }) {
    const back = document.createElement('div');
    back.className = 'modal-backdrop show';
    back.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true" style="${wide ? 'max-width:760px' : ''}">
        <div class="row mb"><div style="flex:1"><h2>${esc(title)}</h2>
        ${sub ? `<div class="modal-sub">${esc(sub)}</div>` : ''}</div>
        <button class="btn ghost sm" data-close aria-label="${esc(t('close'))}">${icon('x')}</button></div>
        <div class="modal-body">${body}</div>
        <div class="modal-actions"></div>
      </div>`;
    document.body.appendChild(back);
    const close = () => { back.classList.remove('show'); setTimeout(() => back.remove(), 180); };
    back.querySelector('[data-close]').onclick = close;
    back.addEventListener('click', e => { if (e.target === back) close(); });
    const act = back.querySelector('.modal-actions');
    if (actions) act.innerHTML = actions;
    if (onSubmit) {
      const btn = document.createElement('button');
      btn.className = 'btn primary';
      btn.innerHTML = esc(submitLabel || t('save'));
      btn.onclick = async () => {
        if (btn.disabled) return;
        btn.disabled = true; btn.innerHTML = '<span class="spin"></span>';
        try { await onSubmit(back.querySelector('.modal-body'), close); }
        catch (e) { console.error(e); toast((e && e.message) || t('saveFailed'), 'err', 4500); btn.disabled = false; btn.innerHTML = esc(submitLabel || t('save')); }
      };
      act.appendChild(btn);
      const c = document.createElement('button'); c.className = 'btn'; c.textContent = t('cancel'); c.onclick = close;
      act.appendChild(c);
    }
    const first = back.querySelector('input,select,textarea'); if (first) setTimeout(() => first.focus(), 60);
    return { el: back, close };
  }

  const confirm = (msg) => new Promise(res => {
    const m = modal({
      title: t('deleteConfirm'), body: `<p class="muted">${esc(msg)}</p>`,
      actions: `<button class="btn" data-no>${esc(t('cancel'))}</button><button class="btn danger" data-yes>${esc(t('yesDelete'))}</button>`
    });
    m.el.querySelector('[data-no]').onclick = () => { m.close(); res(false); };
    m.el.querySelector('[data-yes]').onclick = () => { m.close(); res(true); };
  });

  const fmtMoney = (n) => `${(Number(n) || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })} ${t('currency')}`;
  const fmtDate = (d) => { if (!d) return '—'; const x = new Date(d); return isNaN(x) ? String(d) : x.toLocaleDateString(undefined, { day: '2-digit', month: '2-digit', year: 'numeric' }); };
  const fmtTime = (d) => { if (!d) return '—'; const x = new Date(d); return x.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }); };
  const fmtDur = (sec) => {
    if (sec == null) return '—';
    const h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60);
    return h ? `${h}h ${m}m` : `${m}m`;
  };
  const initials = (name) => (name || '?').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  const debounce = (fn, ms = 300) => { let id; return (...a) => { clearTimeout(id); id = setTimeout(() => fn(...a), ms); }; };
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() :
    'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16); }));

  // ---- Minimal SVG charts (no dependency, works offline) ----
  const NS = 'http://www.w3.org/2000/svg';
  function el(tag, attrs) { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; }

  function barChart({ labels, values, color = '#4f7cff', height = 180, money = false, horizontal = false }) {
    if (!values.length) { const d = document.createElement('div'); d.className = 'empty small'; d.textContent = t('emptyGeneric'); return d; }
    const max = Math.max(...values, 1);
    const W = 640, H = height, pad = 8, bw = horizontal ? 14 : Math.max(8, (W - pad * 2) / values.length - 8);
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, class: 'chart' });
    values.forEach((v, i) => {
      if (horizontal) {
        const w = Math.max(2, (v / max) * (W - 150));
        svg.appendChild(el('rect', { x: 130, y: pad + i * (bw + 8), width: w, height: bw, rx: 4, fill: color, opacity: .9 }));
        const t1 = el('text', { x: 124, y: pad + i * (bw + 8) + bw / 2 + 4, 'text-anchor': 'end', 'font-size': 10, fill: '#8b96ad' });
        t1.textContent = String(labels[i]).slice(0, 12); svg.appendChild(t1);
        const t2 = el('text', { x: 134 + w, y: pad + i * (bw + 8) + bw / 2 + 4, 'font-size': 10, fill: '#e8edf6' });
        t2.textContent = money ? fmtMoney(v) : v; svg.appendChild(t2);
      } else {
        const bh = Math.max(2, (v / max) * (H - 46));
        const x = pad + i * ((W - pad * 2) / values.length) + 4;
        svg.appendChild(el('rect', { x, y: H - 28 - bh, width: bw, height: bh, rx: 4, fill: color, opacity: .9 }));
        const t = el('text', { x: x + bw / 2, y: H - 12, 'text-anchor': 'middle', 'font-size': 10, fill: '#8b96ad' });
        t.textContent = String(labels[i]).slice(0, 6); svg.appendChild(t);
        if (values.length <= 16) {
          const tv = el('text', { x: x + bw / 2, y: H - 34 - bh, 'text-anchor': 'middle', 'font-size': 10, fill: '#e8edf6' });
          tv.textContent = v; svg.appendChild(tv);
        }
      }
    });
    const wrap = document.createElement('div'); wrap.className = 'chart'; wrap.appendChild(svg); return wrap;
  }

  function lineChart({ series, labels, height = 200 }) {
    // series: [{name, color, values[]}]
    if (!labels.length) { const d = document.createElement('div'); d.className = 'empty small'; d.textContent = t('emptyGeneric'); return d; }
    const W = 640, H = height, padL = 44, padB = 24, padT = 12, padR = 12;
    const all = series.flatMap(s => s.values);
    const max = Math.max(...all, 1);
    const sx = i => padL + (i * (W - padL - padR)) / Math.max(labels.length - 1, 1);
    const sy = v => padT + (1 - v / max) * (H - padT - padB);
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}` });
    [0, .5, 1].forEach(f => {
      const y = padT + f * (H - padT - padB);
      svg.appendChild(el('line', { x1: padL, x2: W - padR, y1: y, y2: y, stroke: '#26324c', 'stroke-dasharray': '3 5' }));
      const t = el('text', { x: padL - 6, y: y + 3, 'text-anchor': 'end', 'font-size': 9, fill: '#8b96ad' });
      t.textContent = Math.round(max * (1 - f)); svg.appendChild(t);
    });
    series.forEach(s => {
      const d = s.values.map((v, i) => `${i ? 'L' : 'M'}${sx(i).toFixed(1)},${sy(v).toFixed(1)}`).join(' ');
      svg.appendChild(el('path', { d, fill: 'none', stroke: s.color, 'stroke-width': 2.4, 'stroke-linejoin': 'round' }));
      s.values.forEach((v, i) => svg.appendChild(el('circle', { cx: sx(i), cy: sy(v), r: 2.6, fill: s.color })));
    });
    labels.forEach((l, i) => {
      if (labels.length > 10 && i % Math.ceil(labels.length / 10)) return;
      const t = el('text', { x: sx(i), y: H - 8, 'text-anchor': 'middle', 'font-size': 9, fill: '#8b96ad' });
      t.textContent = String(l).slice(0, 5); svg.appendChild(t);
    });
    const wrap = document.createElement('div'); wrap.className = 'chart'; wrap.appendChild(svg);
    const legend = document.createElement('div'); legend.className = 'legend';
    legend.innerHTML = series.map(s => `<span class="k"><span class="sw" style="background:${s.color}"></span>${esc(s.name)}</span>`).join('');
    const box = document.createElement('div'); box.appendChild(wrap); box.appendChild(legend); return box;
  }

  const empty = (msg, hint = '', actionLabel = '', action = null) => {
    const d = document.createElement('div');
    d.className = 'empty';
    d.innerHTML = `${icon('box')}<p><strong>${esc(msg)}</strong></p>${hint ? `<p class="small">${esc(hint)}</p>` : ''}`;
    if (actionLabel) {
      const b = document.createElement('button'); b.className = 'btn primary'; b.textContent = actionLabel;
      if (action) b.onclick = action; d.appendChild(b);
    }
    return d;
  };

  const badge = (label, color) => `<span class="badge ${color}">${esc(label)}</span>`;
  const debounced = debounce;

  return { esc, icon, toast, modal, confirm, fmtMoney, fmtDate, fmtTime, fmtDur, initials, debounce: debounced, uid, barChart, lineChart, empty, badge };
})();
