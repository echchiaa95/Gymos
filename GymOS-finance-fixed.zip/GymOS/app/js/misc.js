// GymOS — Présences, analytique, plans, coachs, prospects, rapports, audit, appareils, réglages
(() => {
  const $ = (s, r = document) => r.querySelector(s);

  // ------------------------------------------------------------ Attendance
  Pages.attendance = async (el) => {
    const { today } = { today: DB.today() };
    const filters = { from: today, to: today, memberId: '', page: 1 };
    el.innerHTML = `
      <div class="grid stats mb">
        <div class="card stat tint-green"><div class="lbl">${UI.esc(t('currentlyInside'))}</div><div class="val" id="att-inside-n">—</div><div class="icon">${UI.icon('user')}</div></div>
        <div class="card stat tint-blue"><div class="lbl">${UI.esc(t('todaysVisits'))}</div><div class="val" id="att-today-n">—</div><div class="icon">${UI.icon('attendance')}</div></div>
        <div class="card stat tint-cyan"><div class="lbl">${UI.esc(t('avgDuration'))}</div><div class="val" id="att-avg">—</div><div class="icon">${UI.icon('clock')}</div></div>
      </div>
      <div class="card mb"><div class="section-title" style="margin-top:0">${UI.esc(t('insideNow'))}</div><div id="att-inside-list" class="inside-list" style="border-color:var(--border);background:var(--bg2);color:var(--text);width:100%;max-height:220px"></div></div>
      <div class="filters">
        <div class="seg" id="att-range">
          <button data-r="today" class="active">${UI.esc(t('today'))}</button>
          <button data-r="yesterday">${UI.esc(t('yesterday'))}</button>
          <button data-r="week">${UI.esc(t('thisWeek'))}</button>
          <button data-r="month">${UI.esc(t('thisMonth'))}</button>
        </div>
        <input id="att-from" type="date" value="${today}"><input id="att-to" type="date" value="${today}">
        <input id="att-m" type="search" placeholder="${UI.esc(t('fullName'))}" list="att-dl" style="min-width:170px"><datalist id="att-dl"></datalist>
        <button class="btn sm" id="att-apply">${UI.esc(t('apply'))}</button>
      </div>
      <div class="table-wrap"><table><thead><tr><th>${UI.esc(t('fullName'))}</th><th>${UI.esc(t('checkIn'))}</th>
      <th>${UI.esc(t('checkOut'))}</th><th>${UI.esc(t('duration'))}</th><th>${UI.esc(t('status'))}</th></tr></thead>
      <tbody id="att-tbody"></tbody></table></div>
      <div class="row mt" id="att-pager"></div>`;
    let memberFilterId = '';
    DB.listMembers({ per: 1000 }).then(({ rows }) => { $('#att-dl', el).innerHTML = rows.map(m => `<option value="${UI.esc(m.full_name)}">`).join(''); });
    async function loadInside() {
      const occ = await DB.occupancy();
      $('#att-inside-n', el).textContent = occ.length;
      $('#att-inside-list', el).innerHTML = occ.length ? occ.map(a => `
        <div class="row"><span class="dot green"></span><div style="flex:1">${UI.esc(a.member.full_name)}</div><strong>${UI.fmtTime(a.check_in_at)}</strong></div>`).join('')
        : `<p class="muted small" style="padding:10px">${UI.esc(t('emptyGeneric'))}</p>`;
    }
    async function load() {
      const tbody = $('#att-tbody', el), pager = $('#att-pager', el);
      tbody.innerHTML = `<tr><td colspan="5"><div class="skeleton"></div></td></tr>`;
      const { rows, total, pages } = await DB.attendanceHistory({ ...filters, memberId: memberFilterId });
      if (!rows.length) {
        tbody.innerHTML = `<tr><td colspan="5"><p class="muted" style="padding:18px;text-align:center">${UI.esc(t('emptyAttendance'))}</p></td></tr>`;
      } else {
        tbody.innerHTML = rows.map(a => `
          <tr><td><strong>${UI.esc(a.member?.full_name || '—')}</strong></td>
          <td>${UI.fmtDate(a.check_in_at)} ${UI.fmtTime(a.check_in_at)}</td>
          <td>${a.check_out_at ? UI.fmtTime(a.check_out_at) : '—'}</td>
          <td>${UI.fmtDur(a.duration_seconds)}</td>
          <td>${a.check_out_at ? UI.badge(t('closed'), 'gray') : UI.badge(t('open'), 'green')}</td></tr>`).join('');
      }
      pager.innerHTML = `<span class="muted small">${total} · ${filters.page}/${pages}</span><div class="spacer"></div>
        <button class="btn sm" id="ap" ${filters.page <= 1 ? 'disabled' : ''}>←</button>
        <button class="btn sm" id="an" ${filters.page >= pages ? 'disabled' : ''}>→</button>`;
      $('#ap', pager).onclick = () => { filters.page--; load(); };
      $('#an', pager).onclick = () => { filters.page++; load(); };
      const st = await DB.attendanceStats(filters);
      $('#att-today-n', el).textContent = st.visits;
      $('#att-avg', el).textContent = UI.fmtDur(st.avgDur);
    }
    $('#att-range', el).querySelectorAll('button').forEach(b => b.onclick = () => {
      $('#att-range', el).querySelectorAll('button').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      const d = new Date();
      if (b.dataset.r === 'today') { filters.from = filters.to = DB.today(); }
      if (b.dataset.r === 'yesterday') { d.setDate(d.getDate() - 1); filters.from = filters.to = d.toISOString().slice(0, 10); }
      if (b.dataset.r === 'week') { d.setDate(d.getDate() - d.getDay()); filters.from = d.toISOString().slice(0, 10); filters.to = DB.today(); }
      if (b.dataset.r === 'month') { filters.from = DB.today().slice(0, 8) + '01'; filters.to = DB.today(); }
      $('#att-from', el).value = filters.from; $('#att-to', el).value = filters.to;
      filters.page = 1; load();
    });
    $('#att-apply', el).onclick = async () => {
      filters.from = $('#att-from', el).value; filters.to = $('#att-to', el).value; filters.page = 1;
      const q = $('#att-m', el).value.trim();
      memberFilterId = '';
      if (q) { const { rows } = await DB.listMembers({ q, per: 1 }); memberFilterId = rows[0]?.id || ''; }
      load();
    };
    await Promise.all([load(), loadInside()]);
    // Rafraîchissement périodique (pas de realtime abusif sur tablettes low-cost)
    const iv = setInterval(() => { if (!document.body.contains(el)) { clearInterval(iv); return; } loadInside(); }, 12000);
  };

  // ------------------------------------------------------------ Analytics
  Pages.analytics = async (el) => {
    const t0 = DB.today();
    const monthStart = t0.slice(0, 8) + '01';
    const stats = await DB.attendanceStats({ from: monthStart, to: t0 });
    const members = await DB.listMembers({ per: 100000 });
    const names = Object.fromEntries(members.rows.map(m => [m.id, m.full_name]));
    const freq = Object.entries(stats.perMember).sort((a, b) => b[1] - a[1]);
    const DAYS = I18N[GYM_STATE.lang].dir === 'rtl' ? ['أحد', 'إثن', 'ثلا', 'أرب', 'خمي', 'جمع', 'سبت'] : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    el.innerHTML = `
      <div class="grid stats mb">
        <div class="card stat tint-blue"><div class="lbl">${UI.esc(t('visits'))} — ${UI.esc(t('thisMonth'))}</div><div class="val">${stats.visits}</div><div class="icon">${UI.icon('attendance')}</div></div>
        <div class="card stat tint-cyan"><div class="lbl">${UI.esc(t('avgDuration'))}</div><div class="val">${UI.fmtDur(stats.avgDur)}</div><div class="icon">${UI.icon('clock')}</div></div>
        <div class="card stat tint-violet"><div class="lbl">${UI.esc(t('peakHour'))}</div><div class="val">${stats.peakHour != null ? String(stats.peakHour).padStart(2, '0') + ':00' : '—'}</div><div class="icon">${UI.icon('trend')}</div></div>
        <div class="card stat tint-amber"><div class="lbl">${UI.esc(t('peakHour'))} · ${UI.esc(t('week'))}</div><div class="val">${stats.peakDay != null ? DAYS[stats.peakDay] : '—'}</div><div class="icon">${UI.icon('analytics')}</div></div>
      </div>
      <div class="card mb"><div class="section-title" style="margin-top:0">${UI.esc(t('attendance'))} — ${UI.esc(t('thisMonth'))}</div><div id="an-daily"></div></div>
      <div class="grid two">
        <div class="card"><div class="section-title" style="margin-top:0">${UI.esc(t('analytics'))} · ${UI.esc(t('peakHour'))}</div><div id="an-hours"></div></div>
        <div class="card"><div class="section-title" style="margin-top:0">${UI.esc(t('week'))}</div><div id="an-days"></div></div>
      </div>
      <div class="grid two mt" style="margin-top:16px">
        <div class="card"><div class="section-title" style="margin-top:0">${UI.esc(t('analytics'))} — top</div><div id="an-top"></div></div>
        <div class="card"><div class="section-title" style="margin-top:0">${UI.esc(t('inactiveMembers'))}</div><div id="an-inactive"></div></div>
      </div>`;
    const dates = Object.keys(stats.byDate).sort();
    $('#an-daily', el).appendChild(UI.barChart({ labels: dates.map(d => d.slice(8)), values: dates.map(d => stats.byDate[d]), color: '#4f7cff' }));
    $('#an-hours', el).appendChild(UI.barChart({ labels: Object.keys(stats.byHour).map(h => h + 'h'), values: Object.values(stats.byHour), color: '#7c5cff' }));
    $('#an-days', el).appendChild(UI.barChart({ labels: Object.keys(stats.byDay).map(d => DAYS[d]), values: Object.values(stats.byDay), color: '#22d3ee' }));
    const topRows = freq.slice(0, 8);
    $('#an-top', el).innerHTML = topRows.length ? topRows.map(([id, n]) =>
      `<div class="list-row"><div style="flex:1">${UI.esc(names[id] || '—')}</div><span class="badge blue">${n}</span></div>`).join('') : t('emptyGeneric');
    // Moins actifs : membres actifs avec peu ou pas de visites sur 30 jours
    const inactive = members.rows.filter(m => m.status === 'active' && (stats.perMember[m.id] || 0) < 2).slice(0, 10);
    $('#an-inactive', el).innerHTML = inactive.length ? inactive.map(m =>
      `<div class="list-row"><div style="flex:1">${UI.esc(m.full_name)}</div><span class="badge gray">${stats.perMember[m.id] || 0}</span></div>`).join('') : t('noAlerts');
  };

  // ------------------------------------------------------------ Plans
  Pages.plans = async (el) => {
    const plans = await DB.listPlans();
    el.innerHTML = `
      <div class="row mb"><div class="spacer"></div><button class="btn primary" id="pl-add">${UI.icon('plus')} ${UI.esc(t('plans'))}</button></div>
      <div class="grid three">${plans.map(p => `
        <div class="card"><div class="row"><strong style="font-size:1.05rem">${UI.esc(p.name)}</strong><div class="spacer"></div>
        <button class="btn sm" data-edit="${p.id}">${UI.esc(t('edit'))}</button></div>
        <div class="val" style="font-size:1.6rem;font-weight:800;margin:10px 0 2px">${UI.fmtMoney(p.price)}</div>
        <div class="muted small">${p.duration_days} ${UI.esc(t('days'))}</div>
        ${p.description ? `<p class="small muted mt">${UI.esc(p.description)}</p>` : ''}</div>`).join('')}</div>`;
    const openForm = (p = null) => UI.modal({
      title: p ? t('edit') + ' — ' + p.name : t('add') + ' — ' + t('plans'),
      body: `
        <div class="form-grid">
          <div><label>${UI.esc(t('name'))} <span class="req">*</span></label><input name="name" value="${UI.esc(p?.name || '')}"></div>
          <div><label>${UI.esc(t('price'))} <span class="req">*</span></label><input name="price" type="number" min="0" step="0.5" value="${p?.price ?? ''}"></div>
          <div><label>${UI.esc(t('duration'))} (${UI.esc(t('days'))})</label><input name="days" type="number" min="1" value="${p?.duration_days ?? 30}"></div>
        </div>
        <label>${UI.esc(t('notes'))}</label><textarea name="desc" rows="2">${UI.esc(p?.description || '')}</textarea>`,
      onSubmit: async (body, close) => {
        const g = n => body.querySelector(`[name=${n}]`).value;
        if (!g('name')) throw new Error(t('name') + ' ' + t('required'));
        await DB.upsertPlan({ id: p?.id, name: g('name'), price: g('price'), duration_days: g('days'), description: g('desc') });
        toast(t('saveOk')); close(); Pages.plans(el);
      }
    });
    $('#pl-add', el).onclick = () => openForm();
    el.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => openForm(plans.find(p => p.id === b.dataset.edit)));
  };

  // ------------------------------------------------------------ Trainers
  Pages.trainers = async (el) => {
    const trainers = await DB.listTrainers();
    const isTrainer = GYM_STATE.user.role === 'trainer';
    el.innerHTML = `
      ${!isTrainer ? `<div class="row mb"><div class="spacer"></div><button class="btn primary" id="tr-add">${UI.icon('plus')} ${UI.esc(t('addTrainer'))}</button></div>` : ''}
      ${trainers.length ? trainers.map(tr => `
        <div class="card mb">
          <div class="row">
            <div class="avatar" style="width:46px;height:46px;border-radius:13px;font-size:1rem">${UI.initials(tr.name)}</div>
            <div style="flex:1"><strong>${UI.esc(tr.name)}</strong>
            <div class="small muted">${UI.esc(tr.specialization || '')} · <span dir="ltr">${UI.esc(tr.phone || '')}</span></div></div>
            ${UI.badge(t(tr.status), tr.status === 'active' ? 'green' : 'gray')}
            ${!isTrainer ? `<button class="btn sm" data-edit="${tr.id}">${UI.esc(t('edit'))}</button>
            <button class="btn sm" data-assign="${tr.id}">+ ${UI.esc(t('member'))}</button>` : ''}
          </div>
          ${tr.clients?.length ? `<div class="mt">${tr.clients.map(c => `<span class="badge blue" style="margin:2px">${UI.esc(c.member?.full_name || '')}</span>`).join('')}</div>` : ''}
          ${tr.notes ? `<p class="small muted mt">${UI.esc(tr.notes)}</p>` : ''}
        </div>`).join('') : UI.empty(t('emptyGeneric')).outerHTML}`;
    if (!isTrainer) {
      $('#tr-add', el).onclick = () => trainerForm();
      el.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => trainerForm(trainers.find(x => x.id === b.dataset.edit)));
      el.querySelectorAll('[data-assign]').forEach(b => b.onclick = () => {
        const tr = trainers.find(x => x.id === b.dataset.assign);
        UI.modal({
          title: t('member') + ' → ' + tr.name,
          body: `<label>${UI.esc(t('member'))}</label><input name="m" list="tr-dl"><datalist id="tr-dl"></datalist>`,
          onSubmit: async (body, close) => {
            const { rows } = await DB.listMembers({ q: body.querySelector('[name=m]').value, per: 1 });
            if (!rows[0]) throw new Error(t('memberNotFound'));
            await DB.assignClient(tr.id, rows[0].id);
            toast(t('saveOk')); close(); Pages.trainers(el);
          }
        });
        DB.listMembers({ per: 1000 }).then(({ rows }) => document.getElementById('tr-dl').innerHTML = rows.map(m => `<option value="${UI.esc(m.full_name)}">`).join(''));
      });
    }
    function trainerForm(tr = null) {
      UI.modal({
        title: tr ? t('edit') : t('addTrainer'),
        body: `
          <label>${UI.esc(t('name'))} <span class="req">*</span></label><input name="name" value="${UI.esc(tr?.name || '')}">
          <div class="form-grid">
            <div><label>${UI.esc(t('phone'))}</label><input name="phone" dir="ltr" value="${UI.esc(tr?.phone || '')}"></div>
            <div><label>${UI.esc(t('status'))}</label><select name="status"><option value="active" ${tr?.status !== 'inactive' ? 'selected' : ''}>${UI.esc(t('active'))}</option><option value="inactive" ${tr?.status === 'inactive' ? 'selected' : ''}>${UI.esc(t('archived'))}</option></select></div>
          </div>
          <label>${UI.esc(t('trainers'))} / specialization</label><input name="spec" value="${UI.esc(tr?.specialization || '')}">
          <label>${UI.esc(t('notes'))}</label><textarea name="notes" rows="2">${UI.esc(tr?.notes || '')}</textarea>`,
        onSubmit: async (body, close) => {
          const g = n => body.querySelector(`[name=${n}]`).value;
          if (!g('name')) throw new Error(t('name') + ' ' + t('required'));
          await DB.upsertTrainer({ id: tr?.id, name: g('name'), phone: g('phone'), specialization: g('spec'), status: g('status'), notes: g('notes') });
          toast(t('saveOk')); close(); Pages.trainers(el);
        }
      });
    }
  };

  // ------------------------------------------------------------ Leads (CRM simple)
  Pages.leads = async (el) => {
    const [leads, plans] = [await DB.listLeads(), await DB.listPlans()];
    const statuses = ['new', 'contacted', 'trial', 'converted', 'lost'];
    let filter = 'all';
    el.innerHTML = `
      <div class="row mb"><div class="seg" id="ld-filter">
        <button data-s="all" class="active">${UI.esc(t('all'))}</button>
        ${statuses.map(s => `<button data-s="${s}">${UI.esc(t(s))}</button>`).join('')}
      </div><div class="spacer"></div>
      <button class="btn primary" id="ld-add">${UI.icon('plus')} ${UI.esc(t('addLead'))}</button></div>
      <div class="table-wrap"><table><thead><tr><th>${UI.esc(t('name'))}</th><th>${UI.esc(t('phone'))}</th>
      <th>${UI.esc(t('plan'))}</th><th>${UI.esc(t('source'))}</th><th>${UI.esc(t('status'))}</th><th></th></tr></thead>
      <tbody id="ld-tbody"></tbody></table></div>`;
    function render() {
      const rows = leads.filter(l => filter === 'all' || l.status === filter);
      const tb = $('#ld-tbody', el);
      if (!rows.length) { tb.innerHTML = `<tr><td colspan="6"><p class="muted" style="padding:16px;text-align:center">${UI.esc(t('emptyGeneric'))}</p></td></tr>`; return; }
      const sc = { new: 'blue', contacted: 'cyan', trial: 'amber', converted: 'green', lost: 'gray' };
      tb.innerHTML = rows.map(l => `
        <tr><td><strong>${UI.esc(l.name)}</strong>${l.notes ? `<div class="small muted">${UI.esc(l.notes)}</div>` : ''}</td>
        <td dir="ltr">${UI.esc(l.phone || '—')}</td>
        <td>${UI.esc(plans.find(p => p.id === l.plan_id)?.name || '—')}</td>
        <td>${UI.esc(l.source || '—')}</td>
        <td><select data-st="${l.id}" style="padding:4px 8px;width:auto">
          ${statuses.map(s => `<option value="${s}" ${l.status === s ? 'selected' : ''}>${UI.esc(t(s))}</option>`).join('')}</select></td>
        <td class="row" style="flex-wrap:nowrap">
          ${l.status !== 'converted' ? `<button class="btn sm success" data-conv="${l.id}">${UI.esc(t('converted'))} →</button>` : ''}
          <button class="btn sm danger" data-del="${l.id}">✕</button></td></tr>`).join('');
      tb.querySelectorAll('[data-st]').forEach(s => s.onchange = async () => {
        await DB.upsertLead({ ...leads.find(x => x.id === s.dataset.st), status: s.value });
        toast(t('saveOk')); Pages.leads(el);
      });
      tb.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
        if (!(await UI.confirm(t('deleteConfirm')))) return;
        await DB.deleteLead(b.dataset.del); Pages.leads(el);
      });
      tb.querySelectorAll('[data-conv]').forEach(b => b.onclick = async () => {
        const lead = leads.find(x => x.id === b.dataset.conv);
        openMemberModal(null, async () => {
          await DB.upsertLead({ ...lead, status: 'converted' });
          Pages.leads(el);
        });
      });
    }
    $('#ld-filter', el).querySelectorAll('button').forEach(b => b.onclick = () => {
      $('#ld-filter', el).querySelectorAll('button').forEach(x => x.classList.remove('active'));
      b.classList.add('active'); filter = b.dataset.s; render();
    });
    $('#ld-add', el).onclick = () => {
      UI.modal({
        title: t('addLead'),
        body: `
          <label>${UI.esc(t('name'))} <span class="req">*</span></label><input name="name">
          <div class="form-grid">
            <div><label>${UI.esc(t('phone'))}</label><input name="phone" dir="ltr"></div>
            <div><label>${UI.esc(t('source'))}</label><input name="source"></div>
            <div><label>${UI.esc(t('plan'))}</label><select name="plan"><option value=""></option>${plans.map(p => `<option value="${p.id}">${UI.esc(p.name)}</option>`).join('')}</select></div>
            <div><label>${UI.esc(t('status'))}</label><select name="status">${statuses.map(s => `<option value="${s}">${UI.esc(t(s))}</option>`).join('')}</select></div>
          </div>
          <label>${UI.esc(t('notes'))}</label><textarea name="notes" rows="2"></textarea>`,
        onSubmit: async (body, close) => {
          const g = n => body.querySelector(`[name=${n}]`).value;
          if (!g('name')) throw new Error(t('name') + ' ' + t('required'));
          await DB.upsertLead({ name: g('name'), phone: g('phone'), source: g('source'), plan_id: g('plan') || null, status: g('status'), notes: g('notes') });
          toast(t('leadSaved')); close(); Pages.leads(el);
        }
      });
    };
    render();
  };

  // ------------------------------------------------------------ Reports
  Pages.reports = async (el) => {
    el.innerHTML = `
      <div class="grid three" id="rp-grid"></div>`;
    const monthStart = DB.today().slice(0, 8) + '01';
    const reports = [
      { id: 'members', title: t('reportMembers'), gen: async () => (await DB.listMembers({ per: 100000 })).rows.map(m => ({
        [t('fullName')]: m.full_name, [t('phone')]: m.phone, [t('plan')]: m.current_ms?.plan_name || '', [t('validUntil')]: m.current_ms?.end_date || '', [t('status')]: m.mstate, QR: m.qr_token })) },
      { id: 'attendance', title: t('reportAttendance'), gen: async () => (await DB.attendanceHistory({ from: monthStart, to: DB.today(), per: 100000 })).rows.map(a => ({
        [t('fullName')]: a.member?.full_name || '', Date: a.check_in_at.slice(0, 10), [t('checkIn')]: a.check_in_at, [t('checkOut')]: a.check_out_at || '', [t('duration')]: a.duration_seconds || '' })) },
      { id: 'finance', title: t('reportFinance'), gen: async () => (await DB.listPayments({ from: monthStart, to: DB.today() })).map(p => ({
        [t('date')]: p.date, [t('type')]: p.type, [t('fullName')]: p.member?.full_name || '', [t('paymentMethod')]: p.method, [t('amount')]: p.amount })) },
      { id: 'expenses', title: t('expenses'), gen: async () => (await DB.listExpenses({ from: monthStart, to: DB.today() })).map(x => ({
        [t('date')]: x.date, [t('category')]: x.category, [t('amount')]: x.amount, [t('notes')]: x.note || '' })) },
      { id: 'inventory', title: t('reportInventory'), gen: async () => (await DB.listProducts()).map(p => ({
        [t('name')]: p.name, SKU: p.sku || '', [t('category')]: p.category || '', [t('stock')]: p.stock, [t('minStock')]: p.min_stock, [t('sellingPrice')]: p.selling_price })) },
      { id: 'sales', title: t('reportSales'), gen: async () => (await DB.listSales({ from: monthStart, to: DB.today() })).map(s => ({
        Date: s.created_at.slice(0, 10), Items: (s.items || []).map(i => `${i.name}×${i.qty}`).join(', '), [t('paymentMethod')]: s.method, [t('total')]: s.total })) }
    ];
    $('#rp-grid', el).innerHTML = reports.map(r => `
      <div class="card"><div class="row"><strong style="flex:1">${UI.esc(r.title)}</strong>${UI.icon('reports')}</div>
      <p class="small muted mt">${UI.esc(t('thisMonth'))}</p>
      <div class="row mt">
        <button class="btn sm" data-csv="${r.id}">${UI.esc(t('exportCsv'))}</button>
        <button class="btn sm" data-pdf="${r.id}">${UI.esc(t('exportPdf'))}</button>
      </div></div>`).join('');
    const toCsv = (rows) => {
      if (!rows.length) return '';
      const cols = Object.keys(rows[0]);
      const q = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
      return '﻿' + [cols.map(q).join(','), ...rows.map(r => cols.map(c => q(r[c])).join(','))].join('\n');
    };
    const dl = (content, name, mime) => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([content], { type: mime }));
      a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 3000);
    };
    el.querySelectorAll('[data-csv]').forEach(b => b.onclick = async () => {
      const r = reports.find(x => x.id === b.dataset.csv);
      dl(toCsv(await r.gen()), `gymos-${r.id}.csv`, 'text/csv');
    });
    el.querySelectorAll('[data-pdf]').forEach(b => b.onclick = async () => {
      const r = reports.find(x => x.id === b.dataset.pdf);
      const rows = await r.gen();
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({ orientation: 'landscape' });
      doc.setFontSize(13); doc.text(`${GYM_STATE.org?.name || 'GymOS'} — ${r.title} (${DB.today()})`, 14, 14);
      if (rows.length) {
        const cols = Object.keys(rows[0]);
        doc.autoTable ? doc.autoTable({ startY: 22, head: [cols], body: rows.map(x => cols.map(c => String(x[c] ?? ''))), styles: { fontSize: 7 } }) : null;
        if (!doc.autoTable) {
          doc.setFontSize(8); let y = 24;
          doc.text(cols.join(' | ').slice(0, 160), 14, y); y += 6;
          rows.slice(0, 40).forEach(row => { doc.text(cols.map(c => String(row[c] ?? '')).join(' | ').slice(0, 160), 14, y); y += 5; });
        }
      } else doc.text(t('emptyGeneric'), 14, 24);
      doc.save(`gymos-${r.id}.pdf`);
    });
  };

  // ------------------------------------------------------------ Audit log
  Pages.audit = async (el) => {
    const logs = await DB.listAudit();
    el.innerHTML = `<div class="table-wrap"><table><thead><tr><th>${UI.esc(t('date'))}</th><th>User</th>
    <th>Action</th><th>${UI.esc(t('type'))}</th></tr></thead>
    <tbody>${logs.slice(0, 200).map(l => `
      <tr><td class="small">${UI.fmtDate(l.created_at)} ${UI.fmtTime(l.created_at)}</td>
      <td class="small">${UI.esc(l.user_name || '—')}</td>
      <td><code class="small">${UI.esc(l.action)}</code></td>
      <td class="small muted">${UI.esc(l.entity)} ${l.entity_id ? '· ' + String(l.entity_id).slice(0, 8) : ''}</td></tr>`).join('') || `<tr><td colspan="4"><p class="muted" style="padding:16px">${UI.esc(t('emptyGeneric'))}</p></td></tr>`}
    </tbody></table></div>`;
  };

  // ------------------------------------------------------------ Devices
  Pages.devices = async (el) => {
    const devices = await DB.listDevices();
    el.innerHTML = `
      <div class="row mb"><div class="spacer"></div><button class="btn primary" id="dv-add">${UI.icon('plus')} Device</button></div>
      ${devices.map(d => `
        <div class="card mb"><div class="row">
          <span class="dot ${d.status === 'online' ? 'green' : 'gray'}"></span>
          <div style="flex:1"><strong>${UI.esc(d.name)}</strong>
          <div class="small muted">${UI.esc(d.type)} · ${UI.esc(t('branch'))}: ${UI.esc(d.branch_id ? (GYM_STATE.branch?.id === d.branch_id ? (GYM_STATE.branch?.name || '—') : String(d.branch_id).slice(0, 6)) : '—')}</div>
          <div class="small" style="margin-top:4px">${UI.esc(t('deviceToken'))}: <code>${UI.esc(d.device_token)}</code>
          <button class="btn ghost sm" data-copy="${UI.esc(d.device_token)}" title="${UI.esc(t('share'))}">📋</button></div></div>
          <div style="text-align:end"><div class="small muted">${UI.esc(t('lastSeen')) || 'Last seen'}</div>
          <strong class="small">${UI.esc(d.last_seen_label)}</strong>
          <div class="mt">${UI.badge(d.active ? t('active') : t('archived'), d.active ? 'green' : 'gray')}</div></div>
          <button class="btn sm" data-tgl="${d.id}" data-act="${d.active ? 0 : 1}">${d.active ? UI.esc(t('archive')) : UI.esc(t('unarchive'))}</button>
        </div></div>`).join('') || UI.empty(t('emptyGeneric')).outerHTML}
      <p class="small muted">📱 ${UI.esc(t('entryTerminal'))}: <a href="entry.html" target="_blank"><code>/entry</code></a> — ${UI.esc(t('deviceToken'))} requis.</p>`;
    $('#dv-add', el).onclick = () => {
      UI.modal({
        title: 'Device',
        body: `<label>${UI.esc(t('name'))}</label><input name="name" placeholder="Main Entrance Tablet">
        <label>Type</label><select name="type"><option>tablet</option><option>kiosk</option><option>phone</option><option>other</option></select>`,
        onSubmit: async (body, close) => {
          const d = await DB.upsertDevice({ name: body.querySelector('[name=name]').value || 'Device', type: body.querySelector('[name=type]').value });
          toast(`${t('saveOk')} — ${d.device_token}`, 'ok', 6000);
          close(); Pages.devices(el);
        }
      });
    };
    el.querySelectorAll('[data-copy]').forEach(b => b.onclick = () => { navigator.clipboard?.writeText(b.dataset.copy); toast(t('saveOk')); });
    el.querySelectorAll('[data-tgl]').forEach(b => b.onclick = async () => {
      const d = devices.find(x => x.id === b.dataset.tgl);
      await DB.upsertDevice({ ...d, active: b.dataset.act === '1' });
      Pages.devices(el);
    });
  };

  // ------------------------------------------------------------ Settings
  Pages.settings = async (el) => {
    const s = GYM_STATE.org.settings || {};
    const branches = await DB.listBranches();
    el.innerHTML = `
      <div class="grid two">
        <div class="card">
          <div class="section-title" style="margin-top:0">${UI.esc(t('settings'))}</div>
          <label>${UI.esc(t('gymName'))}</label><input id="st-name" value="${UI.esc(GYM_STATE.org.name)}">
          <div class="form-grid">
            <div><label>${UI.esc(t('language'))}</label>
              <select id="st-lang"><option value="fr" ${GYM_STATE.lang === 'fr' ? 'selected' : ''}>Français</option>
              <option value="en" ${GYM_STATE.lang === 'en' ? 'selected' : ''}>English</option>
              <option value="ar" ${GYM_STATE.lang === 'ar' ? 'selected' : ''}>العربية</option></select></div>
            <div><label>${UI.esc(t('expiringAlert'))}</label><input id="st-exp" type="number" min="1" value="${s.expiry_alert_days || 7}"></div>
            <div><label>${UI.esc(t('memberNotVisited'))} (X ${UI.esc(t('days'))})</label><input id="st-inact" type="number" min="1" value="${s.inactive_days || 14}"></div>
            <div><label>Cooldown scan (s)</label><input id="st-cool" type="number" min="0" value="${s.attendance_cooldown_seconds ?? 10}"></div>
          </div>
          <button class="btn primary mt" id="st-save">${UI.esc(t('save'))}</button>
        </div>
        <div class="card">
          <div class="section-title" style="margin-top:0">${UI.esc(t('branch'))}</div>
          ${branches.map(b => `<div class="list-row"><strong>${UI.esc(b.name)}</strong><div class="spacer"></div>${UI.badge(b.active ? t('active') : t('archived'), b.active ? 'green' : 'gray')}</div>`).join('')}
          <button class="btn mt" id="br-add">${UI.icon('plus')} ${UI.esc(t('add'))}</button>
          <p class="small muted mt">${UI.esc(t('selectBranch'))}: <strong>${UI.esc(GYM_STATE.branch?.name || '—')}</strong>. ${UI.esc(t('demoMode')) === 'Mode démo local' ? '' : 'RLS isole les données par organisation/branche.'}</p>
        </div>
      </div>`;
    $('#st-save', el).onclick = async () => {
      try {
        await DB.saveSettings({
          expiry_alert_days: Number($('#st-exp', el).value),
          inactive_days: Number($('#st-inact', el).value),
          attendance_cooldown_seconds: Number($('#st-cool', el).value)
        });
        applyLang($('#st-lang', el).value);
        toast(t('saveOk'));
      } catch (e) { toast(e.message, 'err'); }
    };
    $('#br-add', el).onclick = () => UI.modal({
      title: t('branch'),
      body: `<label>${UI.esc(t('name'))}</label><input name="n">`,
      onSubmit: async (body, close) => {
        await DB.addBranch(body.querySelector('[name=n]').value);
        toast(t('saveOk')); close(); Pages.settings(el);
      }
    });
  };
})();
