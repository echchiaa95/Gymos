// GymOS — App core : boot, auth, layout, router, dashboard, members
window.Pages = {}; // chaque module JS enregistre ses pages ici

(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const app = () => $('#app');

  // ------------------------------------------------------------ Login
  function renderLogin(error = '') {
    app().innerHTML = `
      <div class="login-wrap"><div class="login-card card">
        <div class="brand"><div class="logo">G</div> GymOS</div>
        ${error ? `<div class="badge red mb" style="width:100%;justify-content:center;padding:9px">${UI.esc(error)}</div>` : ''}
        <form id="login-form" novalidate>
          <label>Email</label><input type="email" name="email" required autocomplete="username" placeholder="elbordiji1995@gmail.com">
          <label>${UI.esc(t('password') || 'Mot de passe')}</label><input type="password" name="password" required autocomplete="current-password" placeholder="••••••••">
          <button class="btn primary block mt" type="submit" style="margin-top:18px">${UI.esc(t('greeting'))} →</button>
        </form>
        ${DB.isLocal() ? `<p class="small muted mt" style="text-align:center">Mode démo : <code>owner@gymos.test / gymos123</code></p>` : ''}
        <p class="small muted mt" style="text-align:center">
          <a href="entry.html">🎫 ${UI.esc(t('entryTerminal'))} (/entry)</a></p>
        <p class="small muted mt" style="text-align:center">
          <button class="btn ghost sm" onclick="applyLang('fr')">FR</button>
          <button class="btn ghost sm" onclick="applyLang('en')">EN</button>
          <button class="btn ghost sm" onclick="applyLang('ar')">عربي</button></p>
      </div></div>`;
    $('#login-form').onsubmit = async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector('button');
      btn.disabled = true; btn.innerHTML = '<span class="spin"></span>';
      try {
        const fd = new FormData(e.target);
        await DB.signIn(fd.get('email').trim(), fd.get('password'));
        renderApp();
      } catch (err) {
        btn.disabled = false; btn.textContent = '→';
        renderLogin(err.message === 'Invalid credentials' ? 'Identifiants invalides' : err.message);
      }
    };
  }

  // ------------------------------------------------------------ Layout
  const NAV = [
    { id: 'dashboard', icon: 'dashboard', roles: ['owner', 'manager', 'receptionist', 'accountant', 'trainer'] },
    { id: 'members', icon: 'members', roles: ['owner', 'manager', 'receptionist', 'trainer'] },
    { id: 'attendance', icon: 'attendance', roles: ['owner', 'manager', 'receptionist', 'trainer'] },
    { id: 'analytics', icon: 'analytics', roles: ['owner', 'manager'] },
    { id: 'finance', icon: 'finance', roles: ['owner', 'manager', 'accountant'] },
    { id: 'pos', icon: 'pos', roles: ['owner', 'manager', 'receptionist'] },
    { id: 'inventory', icon: 'inventory', roles: ['owner', 'manager', 'receptionist'] },
    { id: 'plans', icon: 'plans', roles: ['owner', 'manager'] },
    { id: 'trainers', icon: 'trainers', roles: ['owner', 'manager', 'trainer'] },
    { id: 'leads', icon: 'leads', roles: ['owner', 'manager', 'receptionist'] },
    { id: 'reports', icon: 'reports', roles: ['owner', 'manager', 'accountant'] },
    { id: 'audit', icon: 'audit', roles: ['owner', 'manager'] },
    { id: 'devices', icon: 'devices', roles: ['owner', 'manager'] },
    { id: 'settings', icon: 'settings', roles: ['owner', 'manager'] }
  ];

  function renderShell(route) {
    const items = NAV.filter(n => n.roles.includes(GYM_STATE.user.role));
    app().innerHTML = `
      <div class="layout">
        <aside class="sidebar" id="sidebar">
          <div class="brand"><div class="logo">G</div> GymOS</div>
          <nav>${items.map(n => `
            <button class="nav-item ${route === n.id ? 'active' : ''}" data-nav="${n.id}">
              ${UI.icon(n.icon)}<span>${UI.esc(t(n.id))}</span></button>`).join('')}
          </nav>
          <div class="side-foot">
            <div class="row" style="gap:6px;margin-bottom:8px">
              <span class="dot ${DB.isLocal() ? 'gray' : 'green'}"></span>
              <span>${DB.isLocal() ? UI.esc(t('demoMode')) : UI.esc(t('liveMode'))}</span>
            </div>
            <div>${UI.esc(GYM_STATE.user.name)} · ${UI.esc(GYM_STATE.user.role)}</div>
            <button class="btn ghost sm mt" id="btn-logout" style="padding:4px 0">${UI.esc(t('logout'))}</button>
          </div>
        </aside>
        <div class="overlay" id="overlay"></div>
        <div class="main">
          <header class="topbar">
            <button class="menu-btn" id="btn-menu" aria-label="Menu">${UI.icon('menu')}</button>
            <h1 id="page-title">${UI.esc(t(route))}</h1>
            <button class="btn sm" id="btn-lang" title="${UI.esc(t('language'))}">${UI.icon('lang')} ${GYM_STATE.lang.toUpperCase()}</button>
          </header>
          <main class="content" id="page"></main>
        </div>
      </div>`;
    $('#btn-menu').onclick = () => { $('#sidebar').classList.add('open'); $('#overlay').classList.add('show'); };
    $('#overlay').onclick = () => { $('#sidebar').classList.remove('open'); $('#overlay').classList.remove('show'); };
    document.querySelectorAll('[data-nav]').forEach(b => b.onclick = () => { location.hash = '#/' + b.dataset.nav; });
    $('#btn-logout').onclick = async () => { await DB.signOut(); location.hash = ''; renderApp(); };
    $('#btn-lang').onclick = () => {
      const order = ['fr', 'en', 'ar'];
      applyLang(order[(order.indexOf(GYM_STATE.lang) + 1) % 3]);
    };
  }

  // ------------------------------------------------------------ Router
  const MODULES = {
    finance: 'js/finance.js?v=3',
    pos: 'js/finance.js?v=3',
    inventory: 'js/finance.js?v=3',
    attendance: 'js/misc.js?v=3',
    analytics: 'js/misc.js?v=3',
    plans: 'js/misc.js?v=3',
    trainers: 'js/misc.js?v=3',
    leads: 'js/misc.js?v=3',
    reports: 'js/misc.js?v=3',
    audit: 'js/misc.js?v=3',
    devices: 'js/misc.js?v=3',
    settings: 'js/misc.js?v=3'
  };

  const moduleLoads = {};
  async function ensureRouteModule(route) {
    if (Pages[route]) return;
    const src = MODULES[route];
    if (!src) return;
    if (!moduleLoads[src]) {
      moduleLoads[src] = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = src;
        script.async = false;
        script.onload = resolve;
        script.onerror = () => reject(new Error(`Impossible de charger le module ${src}`));
        document.head.appendChild(script);
      });
    }
    await moduleLoads[src];
    if (!Pages[route]) throw new Error(`Module de page introuvable: ${route}`);
  }

  window.renderApp = async function () {
    document.documentElement.lang = GYM_STATE.lang;
    document.documentElement.dir = I18N[GYM_STATE.lang].dir;
    if (!GYM_STATE.user) {
      const u = await DB.restoreSession().catch(() => null);
      if (!u) { renderLogin(); return; }
    }
    let route = (location.hash || '#/dashboard').replace('#/', '').split('/')[0] || 'dashboard';
    const nav = NAV.find(n => n.id === route && n.roles.includes(GYM_STATE.user.role));
    if (!nav) route = 'dashboard';
    renderShell(route);
    const pageEl = $('#page');
    pageEl.innerHTML = `<div class="skeleton" style="height:120px"></div><div class="skeleton mt" style="height:220px"></div>`;
    try {
      await ensureRouteModule(route);
      const render = Pages[route];
      await render(pageEl);
    } catch (e) {
      console.error(e);
      pageEl.innerHTML = '';
      pageEl.appendChild(UI.empty(t('saveFailed'), e.message, t('retry'), () => renderApp()));
    }
  };
  window.addEventListener('hashchange', () => { if (GYM_STATE.user) renderApp(); });

  // ------------------------------------------------------------ Dashboard
  Pages.dashboard = async (el) => {
    const d = await DB.dashboard();
    const hour = d.attendance.peakHour != null ? `${String(d.attendance.peakHour).padStart(2, '0')}:00` : '—';
    const stat = (lbl, val, icon, tint, sub = '') => `
      <div class="card stat tint-${tint}"><div class="lbl">${UI.esc(lbl)}</div>
      <div class="val">${val}</div>${sub ? `<div class="sub">${UI.esc(sub)}</div>` : ''}
      <div class="icon">${UI.icon(icon)}</div></div>`;
    el.innerHTML = `
      <div class="row mb">
        <strong>${UI.esc(t('greeting'))}, ${UI.esc(GYM_STATE.user.name)}</strong>
        <div class="spacer"></div>
        ${DB.can('owner', 'manager', 'receptionist') ? `<button class="btn primary" id="qa-member">${UI.icon('plus')} ${UI.esc(t('addMember'))}</button>` : ''}
        ${DB.can('owner', 'manager', 'receptionist', 'accountant') ? `<button class="btn" id="qa-pay">${UI.esc(t('recordPayment'))}</button>` : ''}
        ${DB.can('owner', 'manager', 'accountant') ? `<button class="btn" id="qa-exp">${UI.esc(t('addExpense'))}</button>` : ''}
        ${DB.can('owner', 'manager', 'receptionist') ? `<button class="btn" id="qa-sale">${UI.esc(t('sellProduct'))}</button>` : ''}
      </div>
      <div class="section-title">${UI.esc(t('members'))}</div>
      <div class="grid stats">
        ${stat(t('totalMembers'), d.members.total, 'users', 'blue')}
        ${stat(t('activeMemberships'), d.members.active, 'check', 'green')}
        ${stat(t('expiringSoon'), d.members.expiring, 'clock', 'amber')}
        ${stat(t('expired'), d.members.expired, 'warn', 'red')}
        ${stat(t('frozen'), d.members.frozen, 'clock', 'cyan')}
        ${stat(t('newMembers'), d.members.new, 'trend', 'violet', t('month'))}
      </div>
      <div class="section-title">${UI.esc(t('attendance'))}</div>
      <div class="grid stats">
        ${stat(t('currentlyInside'), d.attendance.inside, 'user', 'green', t('occupied'))}
        ${stat(t('todaysVisits'), d.attendance.today, 'attendance', 'blue')}
        ${stat(t('avgDuration'), UI.fmtDur(d.attendance.avgDur), 'clock', 'cyan')}
        ${stat(t('peakHour'), hour, 'trend', 'violet')}
      </div>
      <div class="section-title">${UI.esc(t('finance'))}</div>
      <div class="grid stats">
        ${stat(t('revenueToday'), UI.fmtMoney(d.finance.today.revenue), 'wallet', 'green')}
        ${stat(t('expensesToday'), UI.fmtMoney(d.finance.today.expenses), 'trendDown', 'red')}
        ${stat(t('netToday'), UI.fmtMoney(d.finance.today.net), 'finance', d.finance.today.net >= 0 ? 'green' : 'red')}
        ${stat(t('revenueMonth'), UI.fmtMoney(d.finance.month.revenue), 'trend', 'blue')}
        ${stat(t('netMonth'), UI.fmtMoney(d.finance.month.net), 'finance', d.finance.month.net >= 0 ? 'violet' : 'red')}
      </div>
      <div class="grid two mt" style="margin-top:18px">
        <div class="card"><div class="section-title" style="margin-top:0">${UI.icon('bell')} ${UI.esc(t('alerts') || 'Alertes')}</div><div id="dash-alerts"></div></div>
        <div class="card"><div class="section-title" style="margin-top:0">${UI.icon('user')} ${UI.esc(t('currentlyInside'))}</div><div id="dash-inside"></div></div>
      </div>`;
    const alertsEl = $('#dash-alerts', el);
    if (!d.alerts.length) alertsEl.innerHTML = `<p class="muted small">${UI.esc(t('noAlerts'))}</p>`;
    else alertsEl.innerHTML = d.alerts.map(a => `
      <div class="alert-item"><div class="ic" style="background:rgba(245,158,11,.14);color:var(--amber)">${UI.icon(a.icon)}</div>
      <div><a href="${a.link}">${UI.esc(a.text)}</a></div></div>`).join('');
    const insideEl = $('#dash-inside', el);
    const occ = await DB.occupancy();
    insideEl.innerHTML = occ.length ? `<div style="max-height:260px;overflow-y:auto">` + occ.map(a => `
      <div class="list-row"><div class="avatar" style="width:36px;height:36px;border-radius:10px;font-size:.85rem">${UI.initials(a.member.full_name)}</div>
      <div style="flex:1"><strong>${UI.esc(a.member.full_name)}</strong></div>
      <span class="badge green">${UI.fmtTime(a.check_in_at)}</span></div>`).join('') + '</div>'
      : `<p class="muted small">${UI.esc(t('emptyGeneric'))}</p>`;

    // Actions rapides
    const qa = $('#qa-member', el); if (qa) qa.onclick = () => openMemberModal();
    const qp = $('#qa-pay', el); if (qp) qp.onclick = () => Pages.finance && Pages.finance.quickPayment && Pages.finance.quickPayment();
    const qe = $('#qa-exp', el); if (qe) qe.onclick = () => Pages.finance && Pages.finance.quickExpense && Pages.finance.quickExpense();
    const qs = $('#qa-sale', el); if (qs) qs.onclick = () => { location.hash = '#/pos'; };
  };

  // ------------------------------------------------------------ Members list
  const stateBadge = (m) => {
    if (m.status === 'archived') return UI.badge(t('archived'), 'gray');
    if (m.mstate === 'active') return UI.badge(t('active'), 'green');
    if (m.mstate === 'frozen') return UI.badge(t('frozen'), 'cyan');
    if (m.mstate === 'expired') return UI.badge(t('expired'), 'red');
    return UI.badge(t('noMembership'), 'amber');
  };

  Pages.members = async (el, params) => {
    if (params && params[0]) return Pages.memberProfile(el, params[0]);
    const filters = { q: '', status: 'all', planId: '', page: 1 };
    const plans = await DB.listPlans();
    el.innerHTML = `
      <div class="filters">
        <div class="grow"><input id="f-q" type="search" placeholder="${UI.esc(t('search'))}" aria-label="${UI.esc(t('search'))}"></div>
        <select id="f-status">
          <option value="all">${UI.esc(t('all'))}</option>
          <option value="active">${UI.esc(t('active'))}</option>
          <option value="frozen">${UI.esc(t('frozen'))}</option>
          <option value="expired">${UI.esc(t('expired'))}</option>
          <option value="archived">${UI.esc(t('archived'))}</option>
        </select>
        <select id="f-plan"><option value="">${UI.esc(t('plan'))}: ${UI.esc(t('all'))}</option>
          ${plans.map(p => `<option value="${p.id}">${UI.esc(p.name)}</option>`).join('')}</select>
        <button class="btn primary" id="add-member">${UI.icon('plus')} ${UI.esc(t('addMember'))}</button>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>${UI.esc(t('fullName'))}</th><th>${UI.esc(t('phone'))}</th><th>${UI.esc(t('plan'))}</th>
        <th>${UI.esc(t('validUntil'))}</th><th>${UI.esc(t('status'))}</th><th></th></tr></thead>
        <tbody id="members-tbody"></tbody>
      </table></div>
      <div class="row mt" id="members-pager"></div>`;
    const tbody = $('#members-tbody', el), pager = $('#members-pager', el);
    async function load() {
      tbody.innerHTML = `<tr><td colspan="6"><div class="skeleton"></div><div class="skeleton mt"></div></td></tr>`;
      const { rows, total, pages } = await DB.listMembers(filters);
      if (!rows.length) {
        const empty = UI.empty(t('emptyMembers'), t('emptyMembersHint'), t('addMember'), () => openMemberModal());
        tbody.innerHTML = ''; const tr = document.createElement('tr'); const td = document.createElement('td');
        td.colSpan = 6; td.appendChild(empty); tr.appendChild(td); tbody.appendChild(tr);
      } else {
        tbody.innerHTML = rows.map(m => `
          <tr data-id="${m.id}" style="cursor:pointer">
            <td><strong>${UI.esc(m.full_name)}</strong></td>
            <td dir="ltr">${UI.esc(m.phone)}</td>
            <td>${UI.esc(m.current_ms?.plan_name || '—')}</td>
            <td>${UI.fmtDate(m.current_ms?.end_date)}</td>
            <td>${stateBadge(m)}</td>
            <td><button class="btn sm" data-view="${m.id}">→</button></td>
          </tr>`).join('');
        tbody.querySelectorAll('tr').forEach(tr => tr.onclick = () => location.hash = '#/members/' + tr.dataset.id);
      }
      pager.innerHTML = `<span class="muted small">${total} · ${filters.page}/${pages}</span><div class="spacer"></div>
        <button class="btn sm" id="pg-prev" ${filters.page <= 1 ? 'disabled' : ''}>←</button>
        <button class="btn sm" id="pg-next" ${filters.page >= pages ? 'disabled' : ''}>→</button>`;
      $('#pg-prev', pager).onclick = () => { filters.page--; load(); };
      $('#pg-next', pager).onclick = () => { filters.page++; load(); };
    }
    $('#f-q', el).oninput = UI.debounce(e => { filters.q = e.target.value; filters.page = 1; load(); }, 300);
    $('#f-status', el).onchange = e => { filters.status = e.target.value; filters.page = 1; load(); };
    $('#f-plan', el).onchange = e => { filters.planId = e.target.value; filters.page = 1; load(); };
    $('#add-member', el).onclick = () => openMemberModal(null, load);
    await load();
  };

  // ------------------------------------------------------------ Member profile
  Pages.memberProfile = async (el, id) => {
    const m = await DB.getMember(id);
    if (!m) { el.appendChild(UI.empty(t('memberNotFound'), '', t('backToAdmin').replace('← Admin', '←'), () => location.hash = '#/members')); return; }
    const tabs = ['overview', 'membership', 'attendance', 'payments', 'notes', 'card'];
    let activeTab = 'overview';
    el.innerHTML = `
      <div class="card">
        <div class="profile-head">
          <div class="avatar">${m.photo_url ? `<img src="${UI.esc(m.photo_url)}" alt="">` : UI.initials(m.full_name)}</div>
          <div style="flex:1;min-width:200px">
            <div class="row"><h2 style="font-size:1.25rem">${UI.esc(m.full_name)}</h2> ${stateBadge(m)}</div>
            <div class="muted small">${UI.esc(t('memberId'))}: ${m.id.slice(0, 8).toUpperCase()} · ${UI.esc(t('since'))} ${UI.fmtDate(m.created_at)}</div>
            <div class="muted small" dir="ltr">${UI.esc(m.phone)}</div>
          </div>
          <div class="row">
            <button class="btn sm" id="p-edit">${UI.esc(t('edit'))}</button>
            ${DB.can('owner', 'manager', 'receptionist') ? `<button class="btn sm primary" id="p-renew">${UI.esc(t('renewMembership'))}</button>` : ''}
            <button class="btn sm" id="p-archive">${UI.esc(m.status === 'archived' ? t('unarchive') : t('archive'))}</button>
          </div>
        </div>
        <div class="kv">
          <div class="item"><div class="k">${UI.esc(t('plan'))}</div><div class="v">${UI.esc(m.current_ms?.plan_name || '—')}</div></div>
          <div class="item"><div class="k">${UI.esc(t('validUntil'))}</div><div class="v">${UI.fmtDate(m.current_ms?.end_date)}</div></div>
          <div class="item"><div class="k">${UI.esc(t('visits'))}</div><div class="v">${m.visits}</div></div>
          <div class="item"><div class="k">${UI.esc(t('totalPaid'))}</div><div class="v">${UI.fmtMoney(m.totalPaid)}</div></div>
        </div>
        <div class="tabs mt">${tabs.map(tb => `<button class="tab ${tb === 'overview' ? 'active' : ''}" data-tab="${tb}">${UI.esc(t(tb))}</button>`).join('')}</div>
        <div id="tab-body"></div>
      </div>`;
    const body = $('#tab-body', el);
    async function renderTab() {
      el.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === activeTab));
      if (activeTab === 'overview') {
        body.innerHTML = `
          <div class="grid two">
            <div>
              <p class="muted small">${UI.esc(t('gender'))}: ${UI.esc(m.gender || '—')}</p>
              <p class="muted small mt">${UI.esc(t('dob'))}: ${UI.fmtDate(m.dob)}</p>
              <p class="muted small mt">${UI.esc(t('address'))}: ${UI.esc(m.address || '—')}</p>
              <p class="muted small mt">${UI.esc(t('emergencyContact'))}: ${UI.esc(m.emergency_contact || '—')}</p>
            </div>
            <div>
              <p class="muted small">${UI.esc(t('lastVisit'))}: ${m.attendance[0] ? UI.fmtDate(m.attendance[0].check_in_at) + ' ' + UI.fmtTime(m.attendance[0].check_in_at) : t('never')}</p>
              <p class="muted small mt">${UI.esc(t('phone'))}: <span dir="ltr">${UI.esc(m.phone)}</span></p>
              <p class="muted small mt">${UI.esc(t('barcodeId'))}: <code>${UI.esc(m.qr_token.slice(0, 22))}…</code></p>
            </div>
          </div>
          <div class="row mt">
            <button class="btn sm" id="p-freeze">${UI.esc(m.mstate === 'frozen' ? t('reactivate') : t('freeze'))}</button>
            <button class="btn sm danger" id="p-revoke">${UI.esc(t('revokeQr'))}</button>
          </div>
          ${m.notes ? `<p class="mt small">${UI.esc(t('notes'))}: ${UI.esc(m.notes)}</p>` : ''}`;
        $('#p-freeze', body).onclick = async () => {
          if (m.mstate === 'frozen') { await DB.unfreezeMembership(m.current_ms.id); toast(t('saveOk')); Pages.memberProfile(el, id); }
          else openFreezeModal(m);
        };
        $('#p-revoke', body).onclick = async () => {
          if (!(await UI.confirm(t('revokeQr') + ' — ' + m.full_name))) return;
          try { await DB.revokeQr(m.id); toast(t('saveOk')); Pages.memberProfile(el, id); }
          catch (e) { toast(e.message, 'err'); }
        };
      }
      if (activeTab === 'membership') {
        const hist = m.memberships || [];
        body.innerHTML = hist.length ? `
          <div class="table-wrap"><table><thead><tr><th>${UI.esc(t('plan'))}</th><th>${UI.esc(t('startDate'))}</th>
          <th>${UI.esc(t('endDate'))}</th><th>${UI.esc(t('price'))}</th><th>${UI.esc(t('status'))}</th></tr></thead>
          <tbody>${hist.map(x => `<tr><td>${UI.esc(x.plan_name)}</td><td>${UI.fmtDate(x.start_date)}</td>
            <td>${UI.fmtDate(x.end_date)}</td><td>${UI.fmtMoney(x.price)}</td>
            <td>${x.status === 'active' ? UI.badge(t('active'), 'green') : x.status === 'frozen' ? UI.badge(t('frozen'), 'cyan') : UI.badge(x.status, 'gray')}</td></tr>`).join('')}
          </tbody></table></div>
          ${m.freezes?.length ? `<p class="section-title">${UI.esc(t('freezeHistory'))}</p>` + m.freezes.map(f =>
            `<p class="small muted">${UI.fmtDate(f.start_date)} → ${UI.fmtDate(f.end_date)} ${f.reason ? '· ' + UI.esc(f.reason) : ''}</p>`).join('') : ''}`
          : `<p class="muted">${UI.esc(t('noMemberships'))}</p>`;
      }
      if (activeTab === 'attendance') {
        const rows = m.attendance || [];
        body.innerHTML = rows.length ? `
          <div class="table-wrap"><table><thead><tr><th>${UI.esc(t('checkIn'))}</th><th>${UI.esc(t('checkOut'))}</th>
          <th>${UI.esc(t('duration'))}</th><th>${UI.esc(t('status'))}</th>${DB.can('owner', 'manager') ? '<th></th>' : ''}</tr></thead>
          <tbody>${rows.slice(0, 100).map(a => `<tr><td>${UI.fmtDate(a.check_in_at)} ${UI.fmtTime(a.check_in_at)}</td>
            <td>${a.check_out_at ? UI.fmtTime(a.check_out_at) : '—'}</td><td>${UI.fmtDur(a.duration_seconds)}</td>
            <td>${a.check_out_at ? UI.badge(t('closed'), 'gray') : UI.badge(t('open'), 'green')}</td>
            ${DB.can('owner', 'manager') ? `<td><button class="btn sm" data-corr="${a.id}">${UI.esc(t('correctAttendance'))}</button></td>` : ''}</tr>`).join('')}
          </tbody></table></div>` : UI.empty(t('emptyAttendance')).outerHTML;
        body.querySelectorAll('[data-corr]').forEach(b => b.onclick = () => openAttendanceCorrection(rows.find(r => r.id === b.dataset.corr), async () => Pages.memberProfile(el, id)));
      }
      if (activeTab === 'payments') {
        const rows = m.payments || [];
        body.innerHTML = rows.length ? `
          <div class="table-wrap"><table><thead><tr><th>${UI.esc(t('date'))}</th><th>${UI.esc(t('type'))}</th>
          <th>${UI.esc(t('paymentMethod'))}</th><th>${UI.esc(t('amount'))}</th></tr></thead>
          <tbody>${rows.map(p => `<tr><td>${UI.fmtDate(p.date)}</td><td>${UI.esc(p.type)}</td>
            <td>${UI.esc(p.method)}</td><td><strong>${UI.fmtMoney(p.amount)}</strong></td></tr>`).join('')}
          </tbody></table></div>` : UI.empty(t('emptyGeneric')).outerHTML;
      }
      if (activeTab === 'notes') {
        body.innerHTML = `
          <label>${UI.esc(t('notes'))}</label>
          <textarea id="notes-ta" rows="5">${UI.esc(m.notes || '')}</textarea>
          <button class="btn primary mt" id="notes-save">${UI.esc(t('save'))}</button>`;
        $('#notes-save', body).onclick = async () => {
          try { await DB.updateMember(id, { notes: $('#notes-ta', body).value }); toast(t('saveOk')); }
          catch (e) { toast(e.message, 'err'); }
        };
      }
      if (activeTab === 'card') {
        body.innerHTML = `<div id="card-preview" class="mt"></div>
          <p class="small muted mt">${UI.esc(t('printCardHint'))}</p>
          <div class="row mt">
            <button class="btn primary" id="c-dl">${UI.icon('download')} ${UI.esc(t('download'))} PDF</button>
            <button class="btn" id="c-print">${UI.icon('printer')} ${UI.esc(t('print'))}</button>
            <button class="btn success" id="c-wa">${UI.icon('wa')} ${UI.esc(t('whatsappCard'))}</button>
            <button class="btn ghost" id="c-regen">${UI.esc(t('regenerateCard'))}</button>
          </div>`;
        const opts = { planName: m.current_ms?.plan_name, validUntil: UI.fmtDate(m.current_ms?.end_date), photo: m.photo_url };
        const prev = await Cards.previewEl(m, opts);
        $('#card-preview', body).appendChild(prev);
        const regen = async () => { $('#card-preview', body).innerHTML = ''; $('#card-preview', body).appendChild(await Cards.previewEl(await DB.getMember(id), opts)); };
        $('#c-dl', body).onclick = async () => { try { await Cards.download(m, opts); toast(t('saveOk')); } catch (e) { toast(e.message, 'err'); } };
        $('#c-print', body).onclick = async () => { try { await Cards.print(m, opts); } catch (e) { toast(e.message, 'err'); } };
        $('#c-wa', body).onclick = async () => { try { await Cards.shareWhatsApp(m, opts); } catch (e) { toast(e.message, 'err'); } };
        $('#c-regen', body).onclick = regen;
      }
    }
    el.querySelectorAll('.tab').forEach(b => b.onclick = () => { activeTab = b.dataset.tab; renderTab(); });
    $('#p-edit', el).onclick = () => openMemberModal(m, () => Pages.memberProfile(el, id));
    $('#p-renew', el)?.addEventListener('click', () => openRenewModal(m, () => Pages.memberProfile(el, id)));
    $('#p-archive', el).onclick = async () => {
      await DB.setMemberArchived(id, m.status !== 'archived'); toast(t('saveOk')); Pages.memberProfile(el, id);
    };
    await renderTab();
  };

  // ------------------------------------------------------------ Member form (création / édition)
  window.openMemberModal = function (member = null, onDone = null) {
    DB.listPlans().then(plans => {
      if (!plans.length) { UI.toast('Créez d’abord une formule (Plans)', 'warn'); return; }
      const m = member || {};
      const mo = UI.modal({
        title: member ? t('edit') + ' — ' + member.full_name : t('addMember'),
        sub: t('qrPermanentNote'),
        wide: true,
        body: `
          <div class="form-grid">
            <div><label>${UI.esc(t('fullName'))} <span class="req">*</span></label>
              <input name="full_name" required value="${UI.esc(m.full_name || '')}"></div>
            <div><label>${UI.esc(t('phone'))} <span class="req">*</span></label>
              <input name="phone" required dir="ltr" value="${UI.esc(m.phone || '')}"></div>
            ${member ? '' : `
            <div><label>${UI.esc(t('plan'))} <span class="req">*</span></label>
              <select name="plan_id">${plans.map(p => `<option value="${p.id}" data-price="${p.price}" data-days="${p.duration_days}">${UI.esc(p.name)} — ${UI.fmtMoney(p.price)}</option>`).join('')}</select></div>
            <div><label>${UI.esc(t('startDate'))} <span class="req">*</span></label>
              <input name="start_date" type="date" value="${DB.today()}"></div>
            <div><label>${UI.esc(t('price'))} <span class="req">*</span></label>
              <input name="price" type="number" min="0" step="0.5" value="${plans[0].price}"></div>
            <div><label>${UI.esc(t('paymentMethod'))}</label>
              <select name="method"><option value="cash">${UI.esc(t('cash'))}</option><option value="card">${UI.esc(t('cardPayment'))}</option><option value="other">${UI.esc(t('other'))}</option></select></div>`}
            <div><label>${UI.esc(t('gender'))} (${UI.esc(t('optional'))})</label>
              <select name="gender"><option value=""></option><option ${m.gender === 'M' ? 'selected' : ''}>M</option><option ${m.gender === 'F' ? 'selected' : ''}>F</option></select></div>
            <div><label>${UI.esc(t('dob'))} (${UI.esc(t('optional'))})</label>
              <input name="dob" type="date" value="${UI.esc(m.dob || '')}"></div>
            <div class="full"><label>${UI.esc(t('address'))} (${UI.esc(t('optional'))})</label>
              <input name="address" value="${UI.esc(m.address || '')}"></div>
            <div class="full"><label>${UI.esc(t('emergencyContact'))} (${UI.esc(t('optional'))})</label>
              <input name="emergency_contact" value="${UI.esc(m.emergency_contact || '')}"></div>
            <div class="full"><label>${UI.esc(t('photo'))} URL (${UI.esc(t('optional'))})</label>
              <input name="photo_url" dir="ltr" placeholder="https://…" value="${UI.esc(m.photo_url || '')}"></div>
            <div class="full"><label>${UI.esc(t('notes'))} (${UI.esc(t('optional'))})</label>
              <textarea name="notes" rows="2">${UI.esc(m.notes || '')}</textarea></div>
          </div>`,
        onSubmit: async (body, close) => {
          const fd = new FormData();
          body.querySelectorAll('input,select,textarea').forEach(i => { if (i.name) fd.append(i.name, i.value.trim()); });
          if (!fd.get('full_name') || !fd.get('phone')) throw new Error(t('fullName') + ' / ' + t('phone') + ' ' + t('required'));
          if (member) {
            await DB.updateMember(member.id, {
              full_name: fd.get('full_name'), phone: fd.get('phone'), gender: fd.get('gender') || null,
              dob: fd.get('dob') || null, address: fd.get('address') || null,
              emergency_contact: fd.get('emergency_contact') || null, notes: fd.get('notes') || null,
              photo_url: fd.get('photo_url') || null
            });
            toast(t('saveOk')); close(); if (onDone) onDone();
            return;
          }
          const plan = plans.find(p => p.id === fd.get('plan_id'));
          if (!plan) throw new Error(t('plan') + ' ' + t('required'));
          const start = fd.get('start_date') || DB.today();
          const { member: nm } = await DB.createMember({
            full_name: fd.get('full_name'), phone: fd.get('phone'), plan,
            start_date: start, price: fd.get('price') || plan.price, method: fd.get('method'),
            gender: fd.get('gender') || null, dob: fd.get('dob') || null,
            address: fd.get('address') || null, emergency_contact: fd.get('emergency_contact') || null,
            notes: fd.get('notes') || null, photo_url: fd.get('photo_url') || null
          });
          toast(t('memberSaved') + ' — QR ✓');
          close(); if (onDone) onDone();
          // Proposer immédiatement la carte (PDF / impression / WhatsApp)
          const fresh = await DB.getMember(nm.id);
          const opts = { planName: plan.name, validUntil: UI.fmtDate(fresh.current_ms?.end_date), photo: fresh.photo_url };
          const mm = UI.modal({
            title: t('card') + ' — ' + fresh.full_name, sub: t('printCardHint'), wide: true,
            body: `<div id="new-card-prev" style="display:flex;justify-content:center"></div>`,
            actions: `
              <button class="btn" data-a="dl">${UI.icon('download')} PDF</button>
              <button class="btn" data-a="pr">${UI.icon('printer')} ${UI.esc(t('print'))}</button>
              <button class="btn success" data-a="wa">${UI.icon('wa')} WhatsApp</button>
              <button class="btn ghost" data-a="no">${UI.esc(t('close'))}</button>`
          });
          mm.el.querySelector('#new-card-prev').appendChild(await Cards.previewEl(fresh, opts));
          mm.el.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
            const a = b.dataset.a;
            if (a === 'dl') { await Cards.download(fresh, opts); }
            if (a === 'pr') { await Cards.print(fresh, opts); }
            if (a === 'wa') { await Cards.shareWhatsApp(fresh, opts); }
            if (a === 'no') { mm.close(); }
          });
        }
      });
      if (!member) {
        const sel = mo.el.querySelector('[name=plan_id]');
        if (sel) sel.onchange = () => {
          const o = sel.selectedOptions[0];
          mo.el.querySelector('[name=price]').value = o.dataset.price;
        };
      }
    });
  };

  // ------------------------------------------------------------ Renew / Freeze modals
  window.openRenewModal = function (member, onDone) {
    DB.listPlans().then(plans => {
      UI.modal({
        title: t('renewMembership') + ' — ' + member.full_name,
        sub: t('renewHint'),
        body: `
          <label>${UI.esc(t('plan'))}</label>
          <select name="plan_id">${plans.map(p => `<option value="${p.id}" data-price="${p.price}">${UI.esc(p.name)} — ${UI.fmtMoney(p.price)}</option>`).join('')}</select>
          <div class="form-grid">
            <div><label>${UI.esc(t('startDate'))}</label><input name="start" type="date" value="${member.current_ms && member.current_ms.end_date >= DB.today() ? member.current_ms.end_date : DB.today()}"></div>
            <div><label>${UI.esc(t('price'))}</label><input name="price" type="number" min="0" step="0.5" value="${plans[0].price}"></div>
            <div><label>${UI.esc(t('paymentMethod'))}</label>
              <select name="method"><option value="cash">${UI.esc(t('cash'))}</option><option value="card">${UI.esc(t('cardPayment'))}</option><option value="other">${UI.esc(t('other'))}</option></select></div>
          </div>
          <p class="small muted mt">🔒 ${UI.esc(t('qrPermanentNote'))}</p>`,
        onSubmit: async (body, close) => {
          const plan = plans.find(p => p.id === body.querySelector('[name=plan_id]').value);
          await DB.renewMembership(member.id, {
            plan, startDate: body.querySelector('[name=start]').value || DB.today(),
            price: body.querySelector('[name=price]').value, method: body.querySelector('[name=method]').value
          });
          toast(t('saveOk') + ' — QR ' + (member.qr_token ? 'inchangé' : ''));
          close(); if (onDone) onDone();
        }
      }).el.querySelector('[name=plan_id]').onchange = function () {
        this.closest('.modal-body').querySelector('[name=price]').value = this.selectedOptions[0].dataset.price;
      };
    });
  };

  window.openFreezeModal = function (member, onDone) {
    UI.modal({
      title: t('freeze') + ' — ' + member.full_name, sub: t('freezeHint'),
      body: `
        <div class="form-grid">
          <div><label>${UI.esc(t('freezeStart'))}</label><input name="fs" type="date" value="${DB.today()}"></div>
          <div><label>${UI.esc(t('freezeEnd'))}</label><input name="fe" type="date" value="${DB.today()}"></div>
        </div>
        <label>${UI.esc(t('reason'))}</label><input name="reason">`,
      onSubmit: async (body, close) => {
        if (!member.current_ms) throw new Error(t('noMembership'));
        await DB.freezeMembership(member.current_ms.id, {
          startDate: body.querySelector('[name=fs]').value,
          endDate: body.querySelector('[name=fe]').value,
          reason: body.querySelector('[name=reason]').value
        });
        toast(t('saveOk')); close(); if (onDone) onDone(); else renderApp();
      }
    });
  };

  window.openAttendanceCorrection = function (att, onDone) {
    UI.modal({
      title: t('correctAttendance'), sub: t('history'),
      body: `
        <div class="form-grid">
          <div><label>Check-in</label><input name="ci" type="datetime-local" value="${att.check_in_at.slice(0, 16)}"></div>
          <div><label>Check-out</label><input name="co" type="datetime-local" value="${att.check_out_at ? att.check_out_at.slice(0, 16) : ''}"></div>
        </div>`,
      onSubmit: async (body, close) => {
        const ci = body.querySelector('[name=ci]').value;
        const co = body.querySelector('[name=co]').value;
        if (!ci) throw new Error('check-in ' + t('required'));
        const patch = { check_in_at: new Date(ci).toISOString(), check_out_at: co ? new Date(co).toISOString() : null };
        patch.status = patch.check_out_at ? 'closed' : 'open';
        patch.duration_seconds = patch.check_out_at ? Math.round((new Date(patch.check_out_at) - new Date(patch.check_in_at)) / 1000) : null;
        await DB.correctAttendance(att.id, patch);
        toast(t('saveOk')); close(); if (onDone) onDone();
      }
    });
  };

  // ------------------------------------------------------------ Boot
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => renderApp());
  else renderApp();
})();
