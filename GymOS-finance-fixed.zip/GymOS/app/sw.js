// GymOS Service Worker — cache app shell (PWA installable, rapide sur tablettes low-cost)
const CACHE = 'gymos-v3';
const ASSETS = [
  './', './index.html', './entry.html', './manifest.webmanifest', './css/styles.css',
  './js/config.js', './js/i18n.js', './js/ui.js', './js/db.js', './js/card.js',
  './js/finance.js', './js/misc.js', './js/app.js', './js/entry.js', './js/app.js?v=3', './js/finance.js?v=3', './js/misc.js?v=3'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
// Cache-first pour les assets, network-first pour les API/CDN
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  if (url.origin === location.origin) {
    const isCode = /\.(js|html)$/.test(url.pathname);
    if (isCode) {
      e.respondWith(fetch(e.request).then(res => {
        const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy));
        return res;
      }).catch(() => caches.match(e.request)));
      return;
    }
    e.respondWith(caches.match(e.request).then(r => r || fetch(e.request).then(res => {
      const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); return res;
    }).catch(() => caches.match('./index.html'))));
  }
});
