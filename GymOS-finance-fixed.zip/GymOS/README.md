# GymOS — Gym Management Platform

PWA responsive de gestion de salle de sport : plateforme admin, terminal d'embarquement (tablette) et cartes membres QR permanentes.

## Structure

```
gymos/
  supabase/
    schema.sql        # Schéma PostgreSQL complet : tables, index, contraintes, RLS, fonctions
  app/                # La PWA (statique, hébergeable partout : Netlify, Vercel, S3, Supabase Storage)
    index.html        # /admin — plateforme d'administration (SPA)
    entry.html        # /entry — terminal d'embarquement (kiosk, caméra arrière)
    manifest.webmanifest
    sw.js             # Service worker (cache + PWA)
    css/styles.css
    js/
      config.js       # Clés Supabase + réglages
      i18n.js         # fr / en / ar (RTL)
      ui.js           # composants UI, graphiques SVG, toasts, modales
      db.js           # couche données : Supabase + mode local (démo hors-ligne)
      card.js         # génération carte membre PDF (QR permanent)
      app.js          # routeur + auth + dashboard + membres
      finance.js      # finance, caisse, POS, inventaire
      misc.js         # présences, analytique, plans, trainers, leads, rapports, audit, devices, réglages
      entry.js        # scanner QR, check-in/out, file de synchro hors ligne
```

## Installation

1. Créez un projet sur [supabase.com](https://supabase.com) (gratuit).
2. Ouvrez **SQL Editor** et exécutez le contenu de `supabase/schema.sql` en entier.
3. Dans **Authentication → Users**, créez vos comptes staff (email + mot de passe). Définissez `raw_user_meta_data = {"org_id": "<uuid org>", "role": "owner", "full_name": "...", "branch_id": "<uuid branche>"}` — ou créez l'organisation/branche à la main puis mettez à jour `profiles`.
4. Hébergez le dossier `app/` (Netlify/Vercel/Storage). Déclarez `app/` comme site statique.
5. Sur la tablette d'entrée : ouvrez `https://votre-domaine/entry`, entrez le **Device Token** affiché dans Admin → Devices, activez l'écran plein (kiosk). La caméra arrière est utilisée automatiquement (`facingMode: environment`).
6. Installez la PWA : « Ajouter à l'écran d'accueil » sur Android/iPhone.

## Mode démo (sans Supabase)

Si `config.js` est laissé vide (valeurs `''`), l'application fonctionne en **mode local** : données dans le navigateur (localStorage), utilisateurs de démo `owner@gymos.test / gymos123` (rôles : owner, manager, reception, accountant, trainer — même mot de passe). Idéal pour tester les 15 scénarios de validation avant le déploiement. Le terminal `/entry` fonctionne aussi en local.

## Règles métier clés (implémentées côté serveur ET côté local)

- **QR permanent** : généré une seule fois (`GYM-MEMBER-<128 bits aléatoires>`), immuable (trigger SQL qui bloque toute modification, fonction `revoke_member_qr` pour révocation explicite).
- **Validation à l'embarquement** : la fonction `check_attendance()` (security definer) est la source de vérité — jamais le client. Refus si membre inexplicable/expiré/gelé/annulé.
- **Un seul session ouverte** : index partiel unique `attendance(member_id) WHERE check_out_at IS NULL` + bascule check-in ⇄ check-out atomique.
- **Anti double-scan** : cooldown configurable (`organizations.settings.attendance_cooldown_seconds`).
- **Renouvellement** : le membre et son QR restent identiques ; l'historique d'adhésions est conservé.
- **Hors ligne** : `/entry` utilise un cache minimal autorisé par `device_token`, met les événements en file locale avec `client_event_id` (UUID unique), puis synchronise via `check_attendance()` avec idempotence serveur.

## Sécurité

- RLS activé sur toutes les tables ; politiques par rôle (owner, manager, receptionist, accountant, trainer).
- Le terminal n'utilise **pas** de compte staff : il présente un `device_token` (table `devices`), la fonction `check_attendance` est `security definer` et ne renvoie que le minimum (aucune donnée sensible).
- Aucune clé service-role côté client : uniquement la clé anon.
- Audit log sur : création/édition membre, renouvellement, gel, paiement, dépense, archivage, révocation QR, correction présence.

## Rôles

| Rôle | Accès |
|---|---|
| owner | tout |
| manager | tout sauf réglages org critiques |
| receptionist | membres, présences, paiements, carte |
| accountant | finance, rapports, caisse |
| trainer | fiche trainer + ses clients |

## Les 15 scénarios de validation

Tous testables en mode démo (voir README section Mode démo) : création membre + QR permanent, PDF, check-in/out, anti double-scan, refus expiration, renouvellement sans changement de QR, changement téléphone sans changement de QR, gel, file hors ligne + synchro unique, paiement → caisse, dépense → caisse, multi-branches (données isolées par `org_id`/`branch_id`), restrictions par rôle.


## Correctifs de cette version

- Ajout de `processed_events` pour garantir l'idempotence réelle des synchronisations Offline côté serveur.
- Ajout de `get_entry_cache()` : le terminal peut préparer son cache sans compte staff et sans exposer les tables métier directement.
- Ajout de `get_entry_snapshot()` : statistiques d'occupation et visites du terminal via RPC sécurisée.
- Vérification `branch_id` entre le terminal et le membre lors du contrôle d'accès.
- Correction de la révocation explicite d'un QR : le QR reste immuable dans les opérations normales, mais `revoke_member_qr()` peut volontairement en générer un nouveau.
- Le terminal n'utilise plus les requêtes RLS d'administration pour alimenter son cache/statistiques.

## Production Hardening / QA

- Member onboarding uses `create_member_with_membership()` as one PostgreSQL transaction: member + membership + optional payment succeed or fail together.
- Renewal uses `renew_membership_atomic()` and always appends a new membership history record; it never rewrites the previous membership.
- A renewal cannot become effective before its start date; attendance and entry-cache selection use the membership effective today.
- QR tokens remain immutable except through the explicit `revoke_member_qr()` function.
- Attendance has one-open-session protection and idempotent `client_event_id` handling.
- Sensitive `security definer` RPCs have explicit EXECUTE grants.
- JavaScript syntax QA passes for every file in `app/js/`.
