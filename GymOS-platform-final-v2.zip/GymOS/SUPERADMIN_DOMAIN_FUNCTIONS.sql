-- GymOS — exact Superadmin + custom-domain setup
-- Run after GymOS_schema.sql and supabase/platform_upgrade.sql.
-- Exact Superadmin UID supplied by the owner.

insert into public.platform_admins(user_id)
values ('57582ebd-69f5-4c22-9eb9-7b6b8ccc188b')
on conflict (user_id) do nothing;

-- Verify Superadmin
select pa.user_id, u.email, pa.created_at
from public.platform_admins pa
join auth.users u on u.id=pa.user_id
where pa.user_id='57582ebd-69f5-4c22-9eb9-7b6b8ccc188b';

-- Domain request: generates the TXT challenge.
select public.platform_request_domain(
  'ORGANIZATION_UUID',
  'gym-yemen.com'
);

-- After the TXT record has been added at the domain provider, confirm it.
select public.platform_confirm_domain(
  'ORGANIZATION_UUID',
  'gym-yemen.com'
);

-- Resolve a verified domain (public-safe result; no verification token is returned).
select * from public.resolve_organization_by_domain('gym-yemen.com');
