-- Create the requested tenant: الجيم اليمانية
-- Run after supabase/platform_upgrade.sql and SUPERADMIN_SETUP.sql.
-- No domain is required now. Add the real domain later from Superadmin > Domain.

select public.platform_create_gym(
  'الجيم اليمانية',
  'gym-yemen',
  'Main Branch'
);

-- Later, from Superadmin or SQL:
-- select public.platform_request_domain('ORGANIZATION_UUID', 'gym-yemen.com');
-- After adding the TXT record at the domain provider:
-- select public.platform_confirm_domain('ORGANIZATION_UUID', 'gym-yemen.com');
