-- GymOS Platform / Superadmin + Domain Verification upgrade
-- Run once in Supabase SQL Editor after the current GymOS_schema.sql.
-- Safe to re-run.

create extension if not exists pgcrypto;

alter table public.organizations add column if not exists slug text;
create unique index if not exists uq_organizations_slug on public.organizations(slug) where slug is not null;

create table if not exists public.platform_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.organization_domains (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.organizations(id) on delete cascade,
  hostname text not null unique,
  is_primary boolean not null default true,
  verified boolean not null default false,
  verification_token text unique,
  verification_name text,
  verification_value text,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.organization_domains add column if not exists verification_token text;
alter table public.organization_domains add column if not exists verification_name text;
alter table public.organization_domains add column if not exists verification_value text;
alter table public.organization_domains add column if not exists verified_at timestamptz;

create unique index if not exists uq_org_domains_verification_token
  on public.organization_domains(verification_token)
  where verification_token is not null;

alter table public.platform_admins enable row level security;
alter table public.organization_domains enable row level security;

create or replace function public.is_platform_admin()
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.platform_admins where user_id = auth.uid());
$$;

revoke execute on function public.is_platform_admin() from public;
grant execute on function public.is_platform_admin() to authenticated;

drop policy if exists p_platform_admin_self on public.platform_admins;
create policy p_platform_admin_self on public.platform_admins
for select using (user_id = auth.uid());

drop policy if exists p_domain_public_resolve on public.organization_domains;
drop policy if exists p_domain_platform_admin on public.organization_domains;
create policy p_domain_platform_admin on public.organization_domains
for select using (is_platform_admin());

-- Normalize a hostname for safe storage/comparison.
create or replace function public.normalize_gym_hostname(p_hostname text)
returns text
language sql immutable
as $$
  select lower(
    split_part(
      regexp_replace(trim(coalesce(p_hostname,'')), '^https?://', ''),
      '/',
      1
    )
  );
$$;

create or replace function public.platform_list_organizations()
returns table(
  id uuid,
  name text,
  slug text,
  active boolean,
  created_at timestamptz,
  primary_domain text,
  domain_verified boolean,
  domain_verification_name text,
  domain_verification_value text,
  branch_count bigint,
  member_count bigint
)
language sql security definer set search_path = public
as $$
  select
    o.id,
    o.name,
    o.slug,
    true as active,
    o.created_at,
    d.hostname,
    coalesce(d.verified,false),
    d.verification_name,
    d.verification_value,
    (select count(*) from branches b where b.org_id=o.id),
    (select count(*) from members m where m.org_id=o.id)
  from organizations o
  left join lateral (
    select x.*
    from organization_domains x
    where x.org_id=o.id and x.is_primary=true
    order by x.created_at desc
    limit 1
  ) d on true
  where is_platform_admin()
  order by o.created_at desc;
$$;

create or replace function public.platform_create_gym(
  p_name text,
  p_slug text default null,
  p_branch_name text default 'Main Branch'
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  v_org organizations%rowtype;
  v_branch branches%rowtype;
  v_slug text := lower(regexp_replace(trim(coalesce(p_slug,'')), '[^a-zA-Z0-9-]+', '-', 'g'));
begin
  if not is_platform_admin() then raise exception 'PLATFORM_ADMIN_REQUIRED'; end if;
  if btrim(coalesce(p_name,'')) = '' then raise exception 'GYM_NAME_REQUIRED'; end if;
  if v_slug = '' then v_slug := lower(regexp_replace(trim(p_name), '[^a-zA-Z0-9]+', '-', 'g')); end if;
  if v_slug = '' then v_slug := encode(gen_random_bytes(5), 'hex'); end if;
  if exists(select 1 from organizations where slug = v_slug) then raise exception 'SLUG_ALREADY_EXISTS'; end if;

  insert into organizations(name, slug)
  values (btrim(p_name), v_slug)
  returning * into v_org;

  insert into branches(org_id, name)
  values (v_org.id, coalesce(nullif(btrim(p_branch_name),''),'Main Branch'))
  returning * into v_branch;

  return jsonb_build_object('organization',to_jsonb(v_org),'branch',to_jsonb(v_branch));
end;
$$;

-- Create/update a domain in PENDING state and generate the exact TXT challenge.
-- The Superadmin adds this TXT record at the customer's domain provider later.
create or replace function public.platform_request_domain(
  p_org_id uuid,
  p_hostname text
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  v_host text := public.normalize_gym_hostname(p_hostname);
  v_token text;
  v_row public.organization_domains%rowtype;
begin
  if not is_platform_admin() then raise exception 'PLATFORM_ADMIN_REQUIRED'; end if;
  if not exists(select 1 from organizations where id=p_org_id) then raise exception 'GYM_NOT_FOUND'; end if;
  if v_host='' then raise exception 'DOMAIN_REQUIRED'; end if;

  -- A domain can belong to only one GymOS organization.
  select verification_token into v_token
  from organization_domains
  where hostname=v_host
  limit 1;

  if v_token is null then
    v_token := 'gymos-' || encode(gen_random_bytes(18), 'hex');
  end if;

  update organization_domains
  set is_primary=false
  where org_id=p_org_id;

  insert into organization_domains(
    org_id, hostname, is_primary, verified,
    verification_token, verification_name, verification_value, verified_at
  )
  values(
    p_org_id, v_host, true, false,
    v_token, '_gymos-verification.' || v_host,
    'gymos-verification=' || v_token, null
  )
  on conflict(hostname) do update set
    org_id=excluded.org_id,
    is_primary=true,
    verified=false,
    verification_token=coalesce(organization_domains.verification_token, excluded.verification_token),
    verification_name=excluded.verification_name,
    verification_value=excluded.verification_value,
    verified_at=null
  returning * into v_row;

  return jsonb_build_object(
    'id',v_row.id,
    'org_id',v_row.org_id,
    'hostname',v_row.hostname,
    'verified',v_row.verified,
    'status','pending',
    'dns_type','TXT',
    'dns_name',v_row.verification_name,
    'dns_value',v_row.verification_value
  );
end;
$$;

-- Manual confirmation after the Superadmin has checked the TXT record
-- at the domain provider. This keeps the static PWA free of secret keys.
create or replace function public.platform_confirm_domain(
  p_org_id uuid,
  p_hostname text
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  v_host text := public.normalize_gym_hostname(p_hostname);
  v_row public.organization_domains%rowtype;
begin
  if not is_platform_admin() then raise exception 'PLATFORM_ADMIN_REQUIRED'; end if;

  update organization_domains
  set verified=true, verified_at=now(), is_primary=true
  where org_id=p_org_id and hostname=v_host
  returning * into v_row;

  if not found then raise exception 'DOMAIN_NOT_FOUND'; end if;

  update organization_domains
  set is_primary=false
  where org_id=p_org_id and id<>v_row.id;

  return jsonb_build_object(
    'id',v_row.id,
    'hostname',v_row.hostname,
    'verified',true,
    'verified_at',v_row.verified_at
  );
end;
$$;

create or replace function public.platform_set_domain(
  p_org_id uuid,
  p_hostname text
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
begin
  return public.platform_request_domain(p_org_id,p_hostname);
end;
$$;

create or replace function public.resolve_organization_by_domain(p_hostname text)
returns table(org_id uuid, org_name text, org_slug text)
language sql security definer set search_path = public
as $$
  select o.id, o.name, o.slug
  from organization_domains d
  join organizations o on o.id=d.org_id
  where d.hostname=public.normalize_gym_hostname(p_hostname)
    and d.verified=true
  limit 1;
$$;

revoke execute on function public.normalize_gym_hostname(text) from public;
revoke execute on function public.platform_list_organizations() from public;
revoke execute on function public.platform_create_gym(text,text,text) from public;
revoke execute on function public.platform_request_domain(uuid,text) from public;
revoke execute on function public.platform_confirm_domain(uuid,text) from public;
revoke execute on function public.platform_set_domain(uuid,text) from public;
revoke execute on function public.resolve_organization_by_domain(text) from public;

grant execute on function public.platform_list_organizations() to authenticated;
grant execute on function public.platform_create_gym(text,text,text) to authenticated;
grant execute on function public.platform_request_domain(uuid,text) to authenticated;
grant execute on function public.platform_confirm_domain(uuid,text) to authenticated;
grant execute on function public.platform_set_domain(uuid,text) to authenticated;
grant execute on function public.resolve_organization_by_domain(text) to anon,authenticated;

-- IMPORTANT:
-- The exact platform owner UID is configured separately in SUPERADMIN_SETUP.sql.
-- UID: 57582ebd-69f5-4c22-9eb9-7b6b8ccc188b

-- Trainer QR + attendance support
alter table public.trainers add column if not exists qr_token text;
update public.trainers
set qr_token = 'GYM-TRAINER-' || upper(encode(gen_random_bytes(16), 'hex'))
where qr_token is null or qr_token = '';
create unique index if not exists uq_trainers_qr_token on public.trainers(qr_token);

create or replace function public.protect_trainer_qr_token()
returns trigger language plpgsql as $$
begin
  if old.qr_token is distinct from new.qr_token
     and current_setting('gymos.allow_trainer_qr_rotation', true) <> 'on' then
    raise exception 'TRAINER_QR_TOKEN_IMMUTABLE';
  end if;
  return new;
end $$;
drop trigger if exists trg_protect_trainer_qr on public.trainers;
create trigger trg_protect_trainer_qr before update on public.trainers
for each row execute function public.protect_trainer_qr_token();

create table if not exists public.trainer_attendance (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  branch_id uuid references branches(id) on delete set null,
  device_id uuid references devices(id) on delete set null,
  trainer_id uuid not null references trainers(id) on delete cascade,
  check_in_at timestamptz not null default now(),
  check_out_at timestamptz,
  duration_seconds int,
  status text not null default 'open' check(status in ('open','closed')),
  client_event_id uuid unique,
  created_at timestamptz not null default now()
);
create unique index if not exists uq_trainer_attendance_open on trainer_attendance(trainer_id) where check_out_at is null;
alter table trainer_attendance enable row level security;
drop policy if exists p_read_trainer_attendance on trainer_attendance;
create policy p_read_trainer_attendance on trainer_attendance for select
using (org_id = auth_org() and has_any_role('{owner,manager,receptionist,trainer}'));

-- Replace the entry cache function with a combined member + trainer cache.
drop function if exists public.get_entry_cache(text);
create or replace function public.get_entry_cache(p_device_token text)
returns table(
  member_id uuid,
  qr_token text,
  full_name text,
  plan_name text,
  end_date date,
  state text,
  person_type text
)
language sql security definer set search_path = public
as $$
  select m.id, m.qr_token, m.full_name,
         coalesce(ms.plan_name,''), ms.end_date,
         case when m.status <> 'active' then 'archived'
              when ms.id is null then 'none'
              when ms.status='frozen' then 'frozen'
              when exists(select 1 from membership_freezes mf where mf.membership_id=ms.id and current_date between mf.start_date and mf.end_date) then 'frozen'
              when ms.end_date < current_date then 'expired' else 'active' end,
         'member'
  from devices d
  join members m on m.org_id=d.org_id and (d.branch_id is null or m.branch_id is null or m.branch_id=d.branch_id)
  left join lateral (
    select x.* from memberships x where x.member_id=m.id and x.status<>'cancelled' and x.start_date<=current_date
    order by x.end_date desc,x.created_at desc limit 1
  ) ms on true
  where d.device_token=p_device_token and d.active=true
  union all
  select tr.id, tr.qr_token, tr.name, 'Coach', null::date,
         case when tr.status='active' then 'active' else 'archived' end,
         'trainer'
  from devices d
  join trainers tr on tr.org_id=d.org_id and (d.branch_id is null or tr.branch_id is null or tr.branch_id=d.branch_id)
  where d.device_token=p_device_token and d.active=true;
$$;
grant execute on function public.get_entry_cache(text) to anon, authenticated;

-- Combined live terminal snapshot.
create or replace function public.get_entry_snapshot(p_device_token text)
returns jsonb
language sql security definer set search_path = public
as $$
  with d as (select id,org_id,branch_id from devices where device_token=p_device_token and active=true limit 1),
  open_sessions as (
    select a.id,a.check_in_at,m.full_name,'member' as person_type
    from attendance a join d on d.org_id=a.org_id and (d.branch_id is null or a.branch_id=d.branch_id)
    join members m on m.id=a.member_id where a.check_out_at is null
    union all
    select a.id,a.check_in_at,tr.name,'trainer' as person_type
    from trainer_attendance a join d on d.org_id=a.org_id and (d.branch_id is null or a.branch_id=d.branch_id)
    join trainers tr on tr.id=a.trainer_id where a.check_out_at is null
  ),
  today_visits as (
    select (select count(*) from attendance a join d on d.org_id=a.org_id and (d.branch_id is null or a.branch_id=d.branch_id) where a.check_in_at>=current_date and a.check_in_at<current_date+interval '1 day')
         + (select count(*) from trainer_attendance a join d on d.org_id=a.org_id and (d.branch_id is null or a.branch_id=d.branch_id) where a.check_in_at>=current_date and a.check_in_at<current_date+interval '1 day') as visits
  )
  select jsonb_build_object('inside',coalesce((select jsonb_agg(jsonb_build_object('id',id,'full_name',full_name,'check_in_at',check_in_at,'person_type',person_type) order by check_in_at) from open_sessions),'[]'::jsonb),'visits',coalesce((select visits from today_visits),0));
$$;
grant execute on function public.get_entry_snapshot(text) to anon, authenticated;

-- Replace check_attendance with member + trainer support.
create or replace function public.check_attendance(p_qr_token text,p_device_token text,p_client_event uuid default null)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare
  v_device devices%rowtype; v_member members%rowtype; v_trainer trainers%rowtype; v_ms memberships%rowtype;
  v_open attendance%rowtype; v_topen trainer_attendance%rowtype; v_last timestamptz; v_cooldown int; v_now timestamptz:=now(); v_result jsonb;
  v_prev jsonb;
begin
  if p_client_event is not null then
    select result into v_prev from processed_events where client_event_id=p_client_event;
    if found then return v_prev || jsonb_build_object('replayed',true); end if;
  end if;
  select * into v_device from devices where device_token=p_device_token and active=true;
  if not found then return jsonb_build_object('ok',false,'reason','device_not_found'); end if;
  update devices set last_seen=v_now,status='online' where id=v_device.id;
  select coalesce((settings->>'attendance_cooldown_seconds')::int,10) into v_cooldown from organizations where id=v_device.org_id;

  select * into v_trainer from trainers where qr_token=p_qr_token and org_id=v_device.org_id and status='active';
  if found and (v_device.branch_id is null or v_trainer.branch_id is null or v_trainer.branch_id=v_device.branch_id) then
    select max(created_at) into v_last from trainer_attendance where trainer_id=v_trainer.id;
    if v_last is not null and extract(epoch from(v_now-v_last))<v_cooldown then
      return jsonb_build_object('ok',false,'reason','cooldown','member',jsonb_build_object('name',v_trainer.name,'type','trainer'));
    end if;
    select * into v_topen from trainer_attendance where trainer_id=v_trainer.id and check_out_at is null;
    if found then
      update trainer_attendance set check_out_at=v_now,duration_seconds=extract(epoch from(v_now-check_in_at))::int,status='closed' where id=v_topen.id;
      v_result:=jsonb_build_object('ok',true,'action','check_out','member',jsonb_build_object('id',v_trainer.id,'name',v_trainer.name,'plan','Coach','type','trainer'),'check_in_at',v_topen.check_in_at,'check_out_at',v_now,'duration_seconds',extract(epoch from(v_now-v_topen.check_in_at))::int);
    else
      insert into trainer_attendance(org_id,branch_id,device_id,trainer_id,client_event_id) values(v_device.org_id,v_device.branch_id,v_device.id,v_trainer.id,p_client_event);
      v_result:=jsonb_build_object('ok',true,'action','check_in','member',jsonb_build_object('id',v_trainer.id,'name',v_trainer.name,'plan','Coach','type','trainer'),'check_in_at',v_now);
    end if;
  else
    select * into v_member from members where qr_token=p_qr_token and org_id=v_device.org_id;
    if not found then return jsonb_build_object('ok',false,'reason','member_not_found'); end if;
    if v_device.branch_id is not null and v_member.branch_id is not null and v_member.branch_id<>v_device.branch_id then return jsonb_build_object('ok',false,'reason','member_not_found'); end if;
    if v_member.status<>'active' then return jsonb_build_object('ok',false,'reason','member_not_found'); end if;
    select * into v_ms from memberships where member_id=v_member.id and status<>'cancelled' and start_date<=current_date order by end_date desc,created_at desc limit 1;
    if not found then return jsonb_build_object('ok',false,'reason','no_membership'); end if;
    if v_ms.status='frozen' or exists(select 1 from membership_freezes mf where mf.membership_id=v_ms.id and current_date between mf.start_date and mf.end_date) then return jsonb_build_object('ok',false,'reason','membership_frozen'); end if;
    if v_ms.end_date<current_date then return jsonb_build_object('ok',false,'reason','membership_expired'); end if;
    select max(created_at) into v_last from attendance where member_id=v_member.id;
    if v_last is not null and extract(epoch from(v_now-v_last))<v_cooldown then return jsonb_build_object('ok',false,'reason','cooldown','member',jsonb_build_object('name',v_member.full_name)); end if;
    select * into v_open from attendance where member_id=v_member.id and check_out_at is null;
    if found then
      update attendance set check_out_at=v_now,duration_seconds=extract(epoch from(v_now-check_in_at))::int,status='closed' where id=v_open.id;
      v_result:=jsonb_build_object('ok',true,'action','check_out','member',jsonb_build_object('id',v_member.id,'name',v_member.full_name,'plan',v_ms.plan_name,'valid_until',v_ms.end_date,'type','member'),'check_in_at',v_open.check_in_at,'check_out_at',v_now,'duration_seconds',extract(epoch from(v_now-v_open.check_in_at))::int);
    else
      insert into attendance(org_id,branch_id,device_id,member_id,client_event_id) values(v_device.org_id,v_device.branch_id,v_device.id,v_member.id,p_client_event);
      v_result:=jsonb_build_object('ok',true,'action','check_in','member',jsonb_build_object('id',v_member.id,'name',v_member.full_name,'plan',v_ms.plan_name,'valid_until',v_ms.end_date,'type','member'),'check_in_at',v_now);
    end if;
  end if;
  if p_client_event is not null then
    insert into processed_events(client_event_id,org_id,device_id,result) values(p_client_event,v_device.org_id,v_device.id,v_result) on conflict(client_event_id) do nothing;
  end if;
  return v_result;
end $$;
revoke execute on function public.check_attendance(text,text,uuid) from public;
grant execute on function public.check_attendance(text,text,uuid) to anon,authenticated;
