// GymOS — Génération de la carte membre (PDF, impression, partage WhatsApp)
// Le QR contient uniquement le token permanent. Les infos visibles (validité)
// peuvent être régénérées — le token, lui, ne change JAMAIS.
window.Cards = (() => {
  const qrDataUrl = (text, size = 512) => new Promise((res, rej) => {
    if (window.QRCode && QRCode.toDataURL) {
      QRCode.toDataURL(text, { width: size, margin: 1, errorCorrectionLevel: 'M' }, (err, url) => err ? rej(err) : res(url));
    } else {
      // Fallback : API publique de génération si la lib n'est pas chargée
      res('https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=' + encodeURIComponent(text));
    }
  });

  async function buildPdf(member, opts = {}) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: [86, 54] }); // carte CR80
    const W = 86, H = 54;
    // Fond
    doc.setFillColor(13, 19, 34); doc.rect(0, 0, W, H, 'F');
    doc.setFillColor(79, 124, 255); doc.rect(0, 0, W, 10, 'F');
    doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
    doc.text(opts.gymName || (GYM_STATE.org?.name || 'GymOS').toUpperCase(), 4, 6.5);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(6); doc.setTextColor(220, 228, 245);
    doc.text('MEMBERSHIP CARD', W - 4, 6.5, { align: 'right' });

    // QR (le token permanent — jamais de dates dans le QR)
    const url = await qrDataUrl(member.qr_token);
    doc.setFillColor(255, 255, 255); doc.roundedRect(4, 14, 26, 26, 2, 2, 'F');
    doc.addImage(url, 'PNG', 5, 15, 24, 24);

    // Photo (optionnel)
    let tx = 34;
    if (opts.photo) {
      try { doc.addImage(opts.photo, 'JPEG', 34, 14, 16, 20); tx = 52; } catch { }
    }
    // Infos
    doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
    doc.text(String(member.full_name).slice(0, 26), tx, 19);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(160, 172, 195);
    doc.text(`${t('memberId')}: ${member.id.slice(0, 8).toUpperCase()}`, tx, 25);
    doc.setTextColor(232, 237, 246); doc.setFontSize(8);
    doc.text(`${t('plan')}: ${opts.planName || ''}`, tx, 31);
    doc.setTextColor(34, 211, 238);
    doc.text(`${t('validUntil')}: ${opts.validUntil || '—'}`, tx, 37);
    // Pied
    doc.setDrawColor(120, 132, 160); doc.setLineWidth(.2); doc.line(4, 44, W - 4, 44);
    doc.setFontSize(5.5); doc.setTextColor(139, 150, 173);
    doc.text(`QR ${t('qrPermanentNote')} · ${member.qr_token.slice(0, 24)}…`, 4, 48);
    doc.text(new Date().toLocaleDateString(), W - 4, 48, { align: 'right' });
    return doc;
  }

  async function download(member, opts = {}) {
    const doc = await buildPdf(member, opts);
    const fname = `gymos-card-${member.full_name.replace(/\s+/g, '_')}.pdf`;
    doc.save(fname);
    await DB.logCard(member.id, opts.validUntil || '');
    return fname;
  }

  async function print(member, opts = {}) {
    const doc = await buildPdf(member, opts);
    doc.autoPrint();
    const blob = doc.output('bloburl');
    const w = window.open(blob, '_blank');
    if (!w) { // fallback : impression via iframe caché
      const f = document.createElement('iframe');
      f.style.display = 'none'; f.src = blob;
      document.body.appendChild(f); f.onload = () => { f.contentWindow.print(); };
    }
    await DB.logCard(member.id, opts.validUntil || '');
  }

  // Aperçu dans la page (profil membre, onglet Carte)
  async function previewEl(member, opts = {}) {
    const url = await qrDataUrl(member.qr_token, 256);
    const div = document.createElement('div');
    div.className = 'member-card-preview';
    div.innerHTML = `
      <div class="mc-head">
        <div class="brand"><div class="logo" style="width:26px;height:26px;border-radius:8px;font-size:.8rem">G</div></div>
        <div><div style="font-weight:800;font-size:.9rem">${UI.esc(GYM_STATE.org?.name || 'GymOS')}</div>
        <div class="mc-line">${UI.esc(t('membership'))} · GymOS</div></div>
      </div>
      <div class="mc-body">
        <div class="mc-qr"><img src="${url}" alt="QR"></div>
        <div>
          <div class="mc-name">${UI.esc(member.full_name)}</div>
          <div class="mc-line">${UI.esc(t('memberId'))}: ${member.id.slice(0, 8).toUpperCase()}</div>
          <div class="mc-line">${UI.esc(t('plan'))}: ${UI.esc(opts.planName || '—')}</div>
          <div class="mc-line">${UI.esc(t('validUntil'))}: ${UI.esc(opts.validUntil || '—')}</div>
          <div class="mc-line" style="color:var(--cyan)">${UI.esc(t('qrPermanentNote'))}</div>
        </div>
      </div>
      <div class="mc-foot"><span>${UI.esc(member.qr_token.slice(0, 20))}…</span><span>${new Date().toLocaleDateString()}</span></div>`;
    return div;
  }

  // Partage WhatsApp : PDF sur desktop (wa.me avec texte), Web Share API sur mobile.
  async function shareWhatsApp(member, opts = {}) {
    const phone = (member.phone || '').replace(/[^\d]/g, '');
    const msg = `${GYM_STATE.org?.name || 'GymOS'} — ${t('card')}\n${member.full_name}\n${t('plan')}: ${opts.planName || ''}\n${t('validUntil')}: ${opts.validUntil || ''}\n${t('qrPermanentNote')}`;
    try {
      const doc = await buildPdf(member, opts);
      const blob = doc.output('blob');
      const file = new File([blob], `gymos-card-${member.full_name}.pdf`, { type: 'application/pdf' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: 'GymOS Card', text: msg });
        await DB.logCard(member.id, opts.validUntil || '');
        return;
      }
    } catch (e) { if (e && e.name === 'AbortError') return; }
    // Fallback universel
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
    await DB.logCard(member.id, opts.validUntil || '');
  }

  return { qrDataUrl, download, print, previewEl, shareWhatsApp };
})();
