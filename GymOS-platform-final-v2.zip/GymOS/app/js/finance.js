// GymOS — Finance : revenus, dépenses, caisse journalière, POS, inventaire
(() => {
  const $ = (s, r = document) => r.querySelector(s);

  const INCOME_TYPES = ['membership', 'personal_training', 'class', 'product_sale', 'other'];
  const EXPENSE_CATS = ['rent', 'electricity', 'water', 'salaries', 'maintenance', 'equipment', 'marketing', 'other'];
  const METHODS = ['cash', 'card', 'other'];
  const typeLabel = (x) => t(x) !== x ? t(x) : x;

  function rangeSeg() {
    const t = DB.today();
    const monthStart = t.slice(0, 8) + '01';
    const weekStart = new Date(); weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    return { t, monthStart, weekStart: weekStart.toISOString().slice(0, 10) };
  }

  // ------------------------------------------------------------ Finance page
  Pages.finance = async (el) => {
    const { t: today, monthStart, weekStart } = rangeSeg();
    el.innerHTML = `
      <div class="row mb">
        <button class="btn primary" id="f-add-pay">${UI.icon('plus')} ${UI.esc(t('recordPayment'))}</button>
        <button class="btn" id="f-add-exp">${UI.esc(t('addExpense'))}</button>
        <div class="spacer"></div>
        <div class="seg" id="f-range">
          <button data-r="today">${UI.esc(t('today'))}</button>
          <button data-r="week">${UI.esc(t('thisWeek'))}</button>
          <button data-r="month" class="active">${UI.esc(t('thisMonth'))}</button>
        </div>
      </div>
      <div class="grid stats" id="f-stats"></div>
      <div class="grid two mt" style="margin-top:16px">
        <div class="card"><div class="section-title" style="margin-top:0">${UI.esc(t('income'))} / ${UI.esc(t('expense'))}</div><div id="f-trend"></div></div>
        <div class="card"><div class="section-title" style="margin-top:0">${UI.esc(t('paymentMethod'))}</div><div id="f-methods"></div>
        <div class="section-title">${UI.esc(t('expense'))} — ${UI.esc(t('category'))}</div><div id="f-cats"></div></div>
      </div>
      <div class="card mt"><div class="section-title" style="margin-top:0">${UI.esc(t('cashRegister'))}</div><div id="f-cash"></div></div>
      <div class="grid two mt" style="margin-top:16px">
        <div class="card"><div class="section-title" style="margin-top:0">${UI.esc(t('payments'))}</div><div id="f-pays"></div></div>
        <div class="card"><div class="section-title" style="margin-top:0">${UI.esc(t('expenses'))}</div><div id="f-exps"></div></div>
      </div>`;
    let range = { from: monthStart, to: today };
    async function load() {
      const sum = await DB.financeSummary(range);
      $('#f-stats', el).innerHTML = `
        <div class="card stat tint-green"><div class="lbl">${UI.esc(t('income'))}</div><div class="val">${UI.fmtMoney(sum.revenue)}</div><div class="icon">${UI.icon('wallet')}</div></div>
        <div class="card stat tint-red"><div class="lbl">${UI.esc(t('expenses'))}</div><div class="val">${UI.fmtMoney(sum.expenses)}</div><div class="icon">${UI.icon('trendDown')}</div></div>
        <div class="card stat ${sum.net >= 0 ? 'tint-violet' : 'tint-red'}"><div class="lbl">NET</div><div class="val">${UI.fmtMoney(sum.net)}</div><div class="icon">${UI.icon('finance')}</div></div>`;
      // Tendance sur 14 jours
      const days = []; for (let i = 13; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d.toISOString().slice(0, 10)); }
      const s14 = await DB.financeSummary({ from: days[0], to: today });
      const daily = {};
      (await DB.listPayments({ from: days[0], to: today })).forEach(p => { daily[p.date] = daily[p.date] || { r: 0, e: 0 }; daily[p.date].r += Number(p.amount); });
      (await DB.listExpenses({ from: days[0], to: today })).forEach(x => { daily[x.date] = daily[x.date] || { r: 0, e: 0 }; daily[x.date].e += Number(x.amount); });
      $('#f-trend', el).innerHTML = '';
      $('#f-trend', el).appendChild(UI.lineChart({
        labels: days.map(d => d.slice(5)),
        series: [
          { name: t('income'), color: '#22c55e', values: days.map(d => daily[d]?.r || 0) },
          { name: t('expense'), color: '#ef4444', values: days.map(d => daily[d]?.e || 0) }
        ]
      }));
      $('#f-methods', el).innerHTML = '';
      $('#f-methods', el).appendChild(UI.barChart({
        labels: Object.keys(sum.byMethod), values: Object.values(sum.byMethod), color: '#4f7cff', money: true, horizontal: true
      }));
      $('#f-cats', el).innerHTML = '';
      $('#f-cats', el).appendChild(UI.barChart({
        labels: Object.keys(sum.byExpCat).map(typeLabel), values: Object.values(sum.byExpCat), color: '#f59e0b', money: true, horizontal: true
      }));
      // Caisse
      const reg = await DB.cashRegister();
      $('#f-cash', el).innerHTML = `
        <div class="grid stats">
          <div class="card stat"><div class="lbl">${UI.esc(t('openingBalance'))}</div><div class="val">${UI.fmtMoney(reg.opening_balance)}</div></div>
          <div class="card stat tint-green"><div class="lbl">${UI.esc(t('cashIncome'))}</div><div class="val">${UI.fmtMoney(reg.cashIn)}</div></div>
          <div class="card stat tint-red"><div class="lbl">${UI.esc(t('cashExpenses'))}</div><div class="val">${UI.fmtMoney(reg.cashOut)}</div></div>
          <div class="card stat tint-blue"><div class="lbl">${UI.esc(t('expectedClosing'))}</div><div class="val">${UI.fmtMoney(reg.expected)}</div></div>
        </div>
        ${reg.closed
          ? `<p class="mt">✅ ${UI.esc(t('closeDay'))} — ${UI.esc(t('actualClosing'))}: <strong>${UI.fmtMoney(reg.actual_closing)}</strong> · ${UI.esc(t('difference'))}: <strong style="color:${reg.difference ? 'var(--red)' : 'var(--green)'}">${UI.fmtMoney(reg.difference || 0)}</strong></p>`
          : `<div class="row mt">
              <button class="btn" id="cash-open">${UI.esc(t('openingBalance'))}: ${UI.fmtMoney(reg.opening_balance)} ✏️</button>
              <button class="btn primary" id="cash-close">${UI.esc(t('closeDay'))}</button>
            </div>`}`;
      $('#cash-open', el).onclick = () => {
        UI.modal({
          title: t('openingBalance'),
          body: `<label>${UI.esc(t('amount'))}</label><input name="v" type="number" min="0" step="0.5" value="${reg.opening_balance}">`,
          onSubmit: async (b, c) => { await DB.openRegister(b.querySelector('[name=v]').value); toast(t('saveOk')); c(); load(); }
        });
      };
      $('#cash-close', el).onclick = () => {
        UI.modal({
          title: t('closeDay'), sub: `${t('expectedClosing')}: ${UI.fmtMoney(reg.expected)}`,
          body: `<label>${UI.esc(t('actualClosing'))}</label><input name="v" type="number" min="0" step="0.5" value="${reg.expected}">`,
          onSubmit: async (b, c) => { await DB.closeRegister(b.querySelector('[name=v]').value); toast(t('saveOk')); c(); load(); }
        });
      };
      // Listes
      const pays = await DB.listPayments(range);
      $('#f-pays', el).innerHTML = pays.length ? `<div style="max-height:300px;overflow-y:auto">` + pays.slice(0, 50).map(p => `
        <div class="list-row"><div style="flex:1"><strong>${UI.esc(p.member?.full_name || typeLabel(p.type))}</strong>
        <div class="small muted">${UI.esc(typeLabel(p.type))} · ${UI.esc(p.method)}</div></div>
        <span class="badge green">+${UI.fmtMoney(p.amount)}</span><span class="small muted">${UI.fmtDate(p.date)}</span></div>`).join('') + '</div>' : t('emptyGeneric');
      const exps = await DB.listExpenses(range);
      $('#f-exps', el).innerHTML = exps.length ? `<div style="max-height:300px;overflow-y:auto">` + exps.slice(0, 50).map(x => `
        <div class="list-row"><div style="flex:1"><strong>${UI.esc(typeLabel(x.category))}</strong>
        <div class="small muted">${UI.esc(x.note || '')}</div></div>
        <span class="badge red">−${UI.fmtMoney(x.amount)}</span><span class="small muted">${UI.fmtDate(x.date)}</span></div>`).join('') + '</div>' : t('emptyGeneric');
    }
    $('#f-range', el).querySelectorAll('button').forEach(b => b.onclick = () => {
      $('#f-range', el).querySelectorAll('button').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      if (b.dataset.r === 'today') range = { from: today, to: today };
      if (b.dataset.r === 'week') range = { from: weekStart, to: today };
      if (b.dataset.r === 'month') range = { from: monthStart, to: today };
      load();
    });
    $('#f-add-pay', el).onclick = () => quickPayment(load);
    $('#f-add-exp', el).onclick = () => quickExpense(load);
    await load();
  };

  // ------------------------------------------------------------ Quick forms (dashboard)
  Pages.finance.quickPayment = function (onDone) {
    UI.modal({
      title: t('recordPayment'),
      body: `
        <label>${UI.esc(t('type'))}</label>
        <select name="type">${INCOME_TYPES.map(x => `<option value="${x}">${UI.esc(typeLabel(x))}</option>`).join('')}</select>
        <div class="form-grid">
          <div><label>${UI.esc(t('amount'))} <span class="req">*</span></label><input name="amount" type="number" min="0" step="0.5" required></div>
          <div><label>${UI.esc(t('paymentMethod'))}</label><select name="method">${METHODS.map(m => `<option value="${m}">${UI.esc(typeLabel(m))}</option>`).join('')}</select></div>
          <div><label>${UI.esc(t('date'))}</label><input name="date" type="date" value="${DB.today()}"></div>
          <div><label>${UI.esc(t('member'))}</label><input name="member" list="dl-members" placeholder="${UI.esc(t('optional'))}"><datalist id="dl-members"></datalist></div>
        </div>
        <label>${UI.esc(t('notes'))}</label><input name="note">`,
      onSubmit: async (body, close) => {
        const amount = Number(body.querySelector('[name=amount]').value);
        if (!amount) throw new Error(t('amount') + ' ' + t('required'));
        const name = body.querySelector('[name=member]').value.trim();
        let memberId = null;
        if (name) {
          const { rows } = await DB.listMembers({ q: name, per: 5 });
          memberId = rows[0]?.id || null;
        }
        await DB.recordPayment({
          member_id: memberId, type: body.querySelector('[name=type]').value, amount,
          method: body.querySelector('[name=method]').value,
          date: body.querySelector('[name=date]').value || DB.today(),
          note: body.querySelector('[name=note]').value || null
        });
        toast(t('paymentRecorded')); close(); if (onDone) onDone(); else renderApp();
      }
    });
    DB.listMembers({ per: 1000 }).then(({ rows }) => {
      const dl = document.getElementById('dl-members');
      if (dl) dl.innerHTML = rows.map(m => `<option value="${UI.esc(m.full_name)}">`).join('');
    });
  };

  Pages.finance.quickExpense = function (onDone) {
    UI.modal({
      title: t('addExpense'),
      body: `
        <label>${UI.esc(t('category'))}</label>
        <select name="cat">${EXPENSE_CATS.map(c => `<option value="${c}">${UI.esc(typeLabel(c))}</option>`).join('')}</select>
        <div class="form-grid">
          <div><label>${UI.esc(t('amount'))} <span class="req">*</span></label><input name="amount" type="number" min="0" step="0.5" required></div>
          <div><label>${UI.esc(t('paymentMethod'))}</label><select name="method">${METHODS.map(m => `<option value="${m}">${UI.esc(typeLabel(m))}</option>`).join('')}</select></div>
          <div><label>${UI.esc(t('date'))}</label><input name="date" type="date" value="${DB.today()}"></div>
          <div><label>${UI.esc(t('receipt'))} (${UI.esc(t('optional'))})</label><input name="att" type="file" accept="image/*"></div>
        </div>
        <label>${UI.esc(t('notes'))}</label><input name="note">`,
      onSubmit: async (body, close) => {
        const amount = Number(body.querySelector('[name=amount]').value);
        if (!amount) throw new Error(t('amount') + ' ' + t('required'));
        let attachment = null;
        const file = body.querySelector('[name=att]').files[0];
        if (file) attachment = await new Promise(res => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file); });
        await DB.addExpense({
          category: body.querySelector('[name=cat]').value, amount,
          method: body.querySelector('[name=method]').value,
          date: body.querySelector('[name=date]').value || DB.today(),
          note: body.querySelector('[name=note]').value || null,
          attachment_url: attachment
        });
        toast(t('expenseRecorded')); close(); if (onDone) onDone(); else renderApp();
      }
    });
  };

  // ------------------------------------------------------------ POS
  Pages.pos = async (el) => {
    const products = (await DB.listProducts()).filter(p => p.active);
    let cart = [];
    el.innerHTML = `
      <div class="grid two">
        <div>
          <input id="pos-search" type="search" placeholder="${UI.esc(t('search'))}" class="mb">
          <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr))" id="pos-grid">
            ${products.map(p => `
              <div class="card clickable" data-pid="${p.id}" style="text-align:center">
                <div style="font-size:1.7rem">🥤</div>
                <strong class="small">${UI.esc(p.name)}</strong>
                <div class="muted small">${UI.fmtMoney(p.selling_price)} · ${p.stock}</div>
              </div>`).join('') || UI.empty(t('emptyGeneric')).outerHTML}
          </div>
        </div>
        <div class="card" style="align-self:start;position:sticky;top:76px">
          <div class="section-title" style="margin-top:0">${UI.esc(t('pos'))}</div>
          <div id="pos-cart"><p class="muted small">${UI.esc(t('emptyGeneric'))}</p></div>
          <hr style="border:none;border-top:1px solid var(--border);margin:12px 0">
          <div class="row"><strong style="font-size:1.2rem">${UI.esc(t('total'))}</strong><div class="spacer"></div><strong id="pos-total" style="font-size:1.3rem">0 ${t('currency')}</strong></div>
          <label>${UI.esc(t('paymentMethod'))}</label>
          <select id="pos-method">${METHODS.map(m => `<option value="${m}">${UI.esc(typeLabel(m))}</option>`).join('')}</select>
          <button class="btn primary block mt" id="pos-confirm" disabled>${UI.esc(t('confirmSale'))}</button>
        </div>
      </div>`;
    const cartEl = $('#pos-cart', el);
    function renderCart() {
      if (!cart.length) { cartEl.innerHTML = `<p class="muted small">${UI.esc(t('emptyGeneric'))}</p>`; $('#pos-confirm', el).disabled = true; $('#pos-total', el).textContent = '0 ' + t('currency'); return; }
      cartEl.innerHTML = cart.map((c, i) => `
        <div class="list-row"><div style="flex:1"><strong>${UI.esc(c.name)}</strong>
        <div class="small muted">${UI.fmtMoney(c.unit_price)}</div></div>
        <div class="row" style="gap:5px">
          <button class="btn sm" data-dec="${i}">−</button><strong>${c.qty}</strong><button class="btn sm" data-inc="${i}">+</button>
        </div><strong>${UI.fmtMoney(c.qty * c.unit_price)}</strong></div>`).join('');
      $('#pos-total', el).textContent = UI.fmtMoney(cart.reduce((s, c) => s + c.qty * c.unit_price, 0));
      $('#pos-confirm', el).disabled = false;
      cartEl.querySelectorAll('[data-inc]').forEach(b => b.onclick = () => { const i = +b.dataset.inc; if (cart[i].qty >= cart[i].stock) { toast(t('insufficientStock') + ' ' + cart[i].name, 'warn'); return; } cart[i].qty++; renderCart(); });
      cartEl.querySelectorAll('[data-dec]').forEach(b => b.onclick = () => { const i = +b.dataset.dec; cart[i].qty--; if (cart[i].qty <= 0) cart.splice(i, 1); renderCart(); });
    }
    el.querySelectorAll('[data-pid]').forEach(card => card.onclick = () => {
      const p = products.find(x => x.id === card.dataset.pid);
      const line = cart.find(c => c.product_id === p.id);
      if (line) { if (line.qty >= p.stock) { toast(t('insufficientStock') + ' ' + p.name, 'warn'); return; } line.qty++; }
      else {
        if (p.stock < 1) { toast(t('insufficientStock') + ' ' + p.name, 'warn'); return; }
        cart.push({ product_id: p.id, name: p.name, unit_price: Number(p.selling_price), qty: 1, stock: p.stock });
      }
      renderCart();
    });
    $('#pos-search', el).oninput = UI.debounce(e => {
      const q = e.target.value.toLowerCase();
      el.querySelectorAll('[data-pid]').forEach(c => c.style.display = c.textContent.toLowerCase().includes(q) ? '' : 'none');
    }, 200);
    $('#pos-confirm', el).onclick = async () => {
      const btn = $('#pos-confirm', el);
      btn.disabled = true; btn.innerHTML = '<span class="spin"></span>';
      try {
        await DB.createSale({ items: cart.map(c => ({ product_id: c.product_id, name: c.name, qty: c.qty, unit_price: c.unit_price })), method: $('#pos-method', el).value });
        toast(t('saleRegistered') + ' — ' + UI.fmtMoney(cart.reduce((s, c) => s + c.qty * c.unit_price, 0)));
        Pages.pos(el);
      } catch (e) { toast(e.message, 'err'); btn.disabled = false; btn.textContent = t('confirmSale'); }
    };
  };

  // ------------------------------------------------------------ Inventory
  Pages.inventory = async (el) => {
    const [products, cats] = [await DB.listProducts(), await DB.listCategories()];
    el.innerHTML = `
      <div class="row mb"><div class="spacer"></div>
        <button class="btn" id="inv-cat">${UI.esc(t('category'))}</button>
        <button class="btn primary" id="inv-add">${UI.icon('plus')} ${UI.esc(t('addProduct'))}</button>
      </div>
      <div class="table-wrap"><table><thead><tr><th>${UI.esc(t('name'))}</th><th>${UI.esc(t('sku'))}</th>
      <th>${UI.esc(t('category'))}</th><th>${UI.esc(t('sellingPrice'))}</th><th>${UI.esc(t('stock'))}</th><th></th></tr></thead>
      <tbody>${products.map(p => `
        <tr><td><strong>${UI.esc(p.name)}</strong></td><td>${UI.esc(p.sku || '—')}</td><td>${UI.esc(p.category || '—')}</td>
        <td>${UI.fmtMoney(p.selling_price)}</td>
        <td>${p.stock <= p.min_stock ? UI.badge(`${p.stock} ⚠️`, 'red') : UI.badge(p.stock, 'green')}</td>
        <td class="row" style="flex-wrap:nowrap">
          <button class="btn sm" data-adj="${p.id}">±</button>
          <button class="btn sm" data-edit="${p.id}">${UI.esc(t('edit'))}</button>
        </td></tr>`).join('')}</tbody></table></div>`;
    const openForm = (p = null) => {
      UI.modal({
        title: p ? t('edit') + ' — ' + p.name : t('addProduct'), wide: true,
        body: `
          <div class="form-grid">
            <div><label>${UI.esc(t('name'))} <span class="req">*</span></label><input name="name" value="${UI.esc(p?.name || '')}"></div>
            <div><label>${UI.esc(t('sku'))}</label><input name="sku" value="${UI.esc(p?.sku || '')}"></div>
            <div><label>${UI.esc(t('category'))}</label><select name="cat"><option value=""></option>
              ${cats.map(c => `<option value="${c.id}" ${p?.category_id === c.id ? 'selected' : ''}>${UI.esc(c.name)}</option>`).join('')}</select></div>
            <div><label>${UI.esc(t('stock'))}</label><input name="stock" type="number" min="0" value="${p?.stock ?? 0}"></div>
            <div><label>${UI.esc(t('purchasePrice'))}</label><input name="pp" type="number" min="0" step="0.5" value="${p?.purchase_price ?? 0}"></div>
            <div><label>${UI.esc(t('sellingPrice'))}</label><input name="sp" type="number" min="0" step="0.5" value="${p?.selling_price ?? 0}"></div>
            <div><label>${UI.esc(t('minStock'))}</label><input name="min" type="number" min="0" value="${p?.min_stock ?? 0}"></div>
          </div>`,
        onSubmit: async (body, close) => {
          const g = n => body.querySelector(`[name=${n}]`).value;
          if (!g('name')) throw new Error(t('name') + ' ' + t('required'));
          await DB.upsertProduct({
            id: p?.id, name: g('name'), sku: g('sku'), category_id: g('cat') || null,
            purchase_price: g('pp'), selling_price: g('sp'), stock: g('stock'), min_stock: g('min')
          });
          toast(t('saveOk')); close(); Pages.inventory(el);
        }
      });
    };
    $('#inv-add', el).onclick = () => openForm();
    $('#inv-cat', el).onclick = () => {
      UI.modal({
        title: t('category'),
        body: `<label>${UI.esc(t('name'))}</label><input name="n">
          <div class="mt">${cats.map(c => `<span class="badge blue" style="margin:2px">${UI.esc(c.name)}</span>`).join('')}</div>`,
        onSubmit: async (body, close) => {
          const n = body.querySelector('[name=n]').value.trim();
          if (!n) throw new Error(t('name') + ' ' + t('required'));
          if (DB.isLocal()) {
            const arr = JSON.parse(localStorage.getItem('gymos_product_categories') || '[]');
            arr.push({ id: UI.uid(), org_id: DB.orgId(), name: n });
            localStorage.setItem('gymos_product_categories', JSON.stringify(arr));
          } else {
            const { error } = await DB.sb.from('product_categories').insert({ org_id: DB.orgId(), name: n });
            if (error) throw error;
          }
          toast(t('saveOk')); close(); Pages.inventory(el);
        }
      });
    };
    el.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => openForm(products.find(p => p.id === b.dataset.edit)));
    el.querySelectorAll('[data-adj]').forEach(b => b.onclick = () => {
      const p = products.find(x => x.id === b.dataset.adj);
      UI.modal({
        title: t('adjustStock') + ' — ' + p.name, sub: `${t('stock')}: ${p.stock}`,
        body: `
          <label>${UI.esc(t('movement'))}</label>
          <select name="type"><option value="purchase">${UI.esc(t('income'))} / purchase</option><option value="adjustment">${UI.esc(t('adjustStock'))} (−)</option><option value="return">Return (+)</option></select>
          <label>${UI.esc(t('quantity'))}</label><input name="qty" type="number" min="1" value="1">
          <label>${UI.esc(t('notes'))}</label><input name="note">`,
        onSubmit: async (body, close) => {
          await DB.adjustStock(p.id, {
            type: body.querySelector('[name=type]').value,
            qty: Number(body.querySelector('[name=qty]').value),
            note: body.querySelector('[name=note]').value
          });
          toast(t('saveOk')); close(); Pages.inventory(el);
        }
      });
    });
  };
})();
