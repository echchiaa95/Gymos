// COPY THESE VALUES INTO config.js FOR A REAL DEPLOYMENT.
// Never put a Supabase service_role/secret key here.
window.GYM_CONFIG = {
  supabaseUrl: 'https://YOUR_PROJECT.supabase.co',
  supabaseAnonKey: 'YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY',
  appName: 'GymOS',
  demoPassword: 'gymos123'
};
