// GymOS — Configuration
// 1) Déployez supabase/schema.sql
// 2) Renseignez vos clés ci-dessous. Si laissé vide (''), GymOS fonctionne en
//    mode local (démo) avec des données persistées dans le navigateur.
window.GYM_CONFIG = {
  supabaseUrl: 'https://jhhmyjysphgefayptdfh.supabase.co',
  supabaseAnonKey: 'sb_publishable_pOJ4GNJm8MYww1bWadK2WA_Om5CSifR',
  appName: 'GymOS',
  demoPassword: 'gymos123'
};

// CDN libs (vérifiez les versions si vous auto-hébergez)
window.GYM_CDN = {
  supabase: 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js',
  html5qrcode: 'https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js',
  jspdf: 'https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js',
  qrcode: 'https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js'
};
