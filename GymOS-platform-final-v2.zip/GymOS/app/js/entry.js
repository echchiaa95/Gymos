// GymOS — Terminal d'embarquement (/entry)
// Kiosk : caméra ARRIÈRE, check-in/out par QR permanent, anti double-scan,
// mode hors ligne avec file de synchro dédupliquée (client_event_id).
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const app = () => $('#entry-app');
  const QUEUE_KEY = 'gymos_entry_queue';
  const DEV_KEY = 'gymos_entry_device';
  const CACHE_KEY = 'gymos_member_cache';
  let device = null, scanner = null, busy = false, lastScan = { token: '', at: 0 };
  let online = navigator.onLine;

  const queue = {
    all: () => { try { return JSON.parse(localStorage.getItem(QUEUE_KEY)) || []; } catch { return []; } },
    set: (q) => localStorage.setItem(QUEUE_KEY, JSON.stringify(q)),
    push: (ev) => { const q = queue.all(); q.push(ev); queue.set(q); },
    remove: (id) => queue.set(queue.all().filter(e => e.id !== id))
  };

  function netPill() {
    const q = queue.all();
    if (!online) return `<span class="net-pill off"><span class="dot ${online ? 'green' : 'red'} pulse"></span>${UI.esc(t('offline'))}${q.length ? ` · ${q.length} ${UI.esc(t('pendingSync'))}` : ''}</span>`;
    if (q.length) return `<span class="net-pill" style="background:rgba(245,158,11,.15);color:var(--amber)"><span class="dot green pulse"></span>${q.length} ${UI.esc(t('pendingSync'))}</span>`;
    return `<span class="net-pill"><span class="dot green"></span>${UI.esc(t('synced'))}</span>`;
  }

  // ------------------------------------------------------------ Setup écran (code appareil)
  function renderSetup(msg = '') {
    stopScanner();
    const saved = localStorage.getItem(DEV_KEY) || new URLSearchParams(location.search).get('device') || '';
    app().innerHTML = `
      <div class="entry-page">
        <header class="entry-head">
          <div class="brand"><div class="logo" style="width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent),var(--accent2));font-weight:900">G</div> GymOS</div>
          ${netPill()}
        </header>
        <div class="entry-body">
          <div class="device-setup card">
            <h2 style="margin-bottom:4px">${UI.esc(t('entryTerminal'))}</h2>
            <p class="muted small mb">${UI.esc(t('deviceToken'))} — <a href="index.html">${UI.esc(t('backToAdmin'))}</a></p>
            ${msg ? `<div class="badge red mb" style="width:100%;justify-content:center;padding:9px">${UI.esc(msg)}</div>` : ''}
            <label>${UI.esc(t('deviceToken'))}</label>
            <input id="dev-token" dir="ltr" value="${UI.esc(saved)}" placeholder="DEV-XXXX">
            <button class="btn primary block mt" id="dev-connect">${UI.esc(t('connectDevice'))}</button>
            <p class="small muted mt">Mode démo : <code>DEMO-ENTRY-001</code></p>
            <p class="small muted mt">
              <button class="btn ghost sm" onclick="applyLang('fr');location.reload()">FR</button>
              <button class="btn ghost sm" onclick="applyLang('en');location.reload()">EN</button>
              <button class="btn ghost sm" onclick="applyLang('ar');location.reload()">عربي</button></p>
          </div>
        </div>
      </div>`;
    $('#dev-connect').onclick = async () => {
      const token = $('#dev-token').value.trim();
      if (!token) return;
      const btn = $('#dev-connect');
      btn.disabled = true; btn.innerHTML = '<span class="spin"></span>';
      try {
        device = await DB.registerDeviceByToken(token);
        localStorage.setItem(DEV_KEY, token);
        // en mode démo, registerDeviceByToken retourne le vrai device
        if (device && device.device_token) { startMain(); return; }
        throw new Error(t('deviceInvalid'));
      } catch (e) {
        btn.disabled = false; btn.textContent = t('connectDevice');
        renderSetup(e.message === 'device_not_found' ? t('deviceInvalid') : e.message);
      }
    };
  }

  // ------------------------------------------------------------ Écran principal
  function startMain() {
    app().innerHTML = `
      <div class="entry-page">
        <header class="entry-head">
          <div class="brand"><div class="logo" style="width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent),var(--accent2));font-weight:900">G</div> GymOS</div>
          <div id="net">${netPill()}</div>
        </header>
        <div class="entry-body">
          <div class="scan-title">
            <h2>${UI.esc(t('scanQr'))}</h2>
            <p>${UI.esc(t('placeQr'))}</p>
          </div>
          <div id="qr-reader"></div>
          <div class="scan-stats">
            <div class="s"><div class="n" id="st-inside">—</div><div class="l">${UI.esc(t('currentlyInside'))}</div></div>
            <div class="s"><div class="n" id="st-today">—</div><div class="l">${UI.esc(t('todaysVisits'))}</div></div>
          </div>
          <div class="inside-list" id="inside-list"></div>
          <p class="small muted"><a href="index.html">${UI.esc(t('backToAdmin'))}</a></p>
          <div class="scan-result" id="result"></div>
        </div>
      </div>`;
    startScanner();
    refreshStats();
    setInterval(() => { if (online) refreshStats(); }, 10000);
    // Réveil écran : pleine luminosité impossible en web, mais on garde l'écran actif via wakeLock si dispo
    requestWakeLock();
  }

  async function requestWakeLock() {
    try { if ('wakeLock' in navigator) await navigator.wakeLock.request('screen'); } catch { }
  }

  // ------------------------------------------------------------ Stats & cache
  async function refreshStats() {
    // Cache and terminal statistics use device-authorized RPCs; no staff session is required.
    try {
      const cache = await DB.refreshEntryCache(localStorage.getItem(DEV_KEY));
      localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
    } catch (e) { /* cache will be retried when online */ }
    try {
      const snap = await DB.entrySnapshot(localStorage.getItem(DEV_KEY));
      $('#st-inside').textContent = (snap.inside || []).length;
      $('#st-today').textContent = snap.visits || 0;
      $('#inside-list').innerHTML = (snap.inside || []).length ? snap.inside.slice(0, 12).map(a =>
        `<div class="row"><span>${UI.esc(a.full_name)}</span><div class="spacer"></div><strong>${UI.fmtTime(a.check_in_at)}</strong></div>`).join('')
        : `<p class="muted small" style="padding:10px;text-align:center">${UI.esc(t('emptyGeneric'))}</p>`;
      $('#net').innerHTML = netPill();
    } catch (e) { /* offline/terminal not reachable */ }
  }

  // ------------------------------------------------------------ Scanner (caméra arrière)
  function startScanner() {
    if (!window.Html5Qrcode) { showFatal(t('cameraError')); return; }
    scanner = new Html5Qrcode('qr-reader');
    scanner.start(
      { facingMode: 'environment' }, // caméra arrière
      { fps: 10, qrbox: { width: 220, height: 220 } },
      (text) => onScan(text),
      () => { }
    ).catch(() => showFatal(t('cameraError')));
  }
  function stopScanner() {
    if (scanner) { scanner.stop().catch(() => { }); scanner.clear().catch(() => { }); scanner = null; }
  }
  function showFatal(msg) {
    const box = $('#qr-reader');
    if (box) box.innerHTML = `<div style="padding:26px;text-align:center;color:var(--red)">${UI.icon('warn')}<p class="mt">${UI.esc(msg)}</p></div>`;
  }

  async function onScan(token) {
    if (busy) return;
    const now = Date.now();
    const cooldownMs = (GYM_STATE.org?.settings?.attendance_cooldown_seconds ?? 10) * 1000;
    if (token === lastScan.token && now - lastScan.at < cooldownMs) return; // anti double-scan immédiat
    lastScan = { token, at: now };
    busy = true;
    pauseScan();
    const clientEventId = UI.uid(); // déduplication synchro (unique côté serveur)
    try {
      let result;
      if (online) {
        try { result = await DB.checkAttendance(token, localStorage.getItem(DEV_KEY), clientEventId); }
        catch (e) { online = false; result = await offlineHandle(token, clientEventId); }
      } else {
        result = await offlineHandle(token, clientEventId);
      }
      showResult(result);
    } catch (e) {
      showResult({ ok: false, reason: 'error' });
    }
    setTimeout(() => { busy = false; resumeScan(); }, 3600);
  }

  // Validation hors ligne contre le cache + événement en file d'attente
  async function offlineHandle(token, clientEventId) {
    // Demo/local mode can use the same DB engine directly.
    if (window.GYM_STATE?.mode === 'local') {
      return DB.checkAttendance(token, localStorage.getItem(DEV_KEY), clientEventId);
    }
    // Live PWA: use the cached member snapshot prepared by the terminal.
    const cache = JSON.parse(localStorage.getItem(CACHE_KEY) || '[]');
    const m = cache.find(x => x.qr === token);
    if (!m || m.state === 'archived') return { ok: false, reason: 'member_not_found' };
    if (m.state === 'frozen') return { ok: false, reason: 'membership_frozen', member: { name: m.name } };
    if (m.state === 'expired') return { ok: false, reason: 'membership_expired', member: { name: m.name } };
    if (m.state !== 'active') return { ok: false, reason: 'no_membership', member: { name: m.name } };
    const ev = { id: clientEventId, qr: token, at: new Date().toISOString(), member: m };
    queue.push(ev);
    return { ok: true, action: 'queued', offline: true, member: { name: m.name, plan: m.plan, valid_until: m.valid }, check_in_at: ev.at };
  }

  // Synchronisation : exactement une fois par événement (client_event_id unique côté serveur)
  async function flushQueue() {
    const q = queue.all();
    if (!q.length) return;
    $('#net').innerHTML = netPill();
    for (const ev of q) {
      try {
        await DB.checkAttendance(ev.qr, localStorage.getItem(DEV_KEY), ev.id);
        queue.remove(ev.id);
      } catch (e) { break; } // réseau toujours down → on réessaie plus tard
    }
    $('#net').innerHTML = netPill();
    refreshStats();
  }

  // ------------------------------------------------------------ Affichage résultat
  const reasonText = {
    member_not_found: t('memberNotFound'), no_membership: t('noMembership'),
    membership_expired: t('membershipExpired'), membership_frozen: t('membershipFrozen'),
    membership_cancelled: t('membershipCancelled'), cooldown: t('cooldown'), device_not_found: t('deviceInvalid')
  };
  function showResult(r) {
    const el = $('#result');
    const granted = r.ok && r.action !== 'queued_denied';
    el.className = 'scan-result show ' + (r.ok ? 'granted' : 'denied');
    if (r.ok && r.action === 'check_out') {
      el.innerHTML = `
        <h2 style="color:var(--green)">${UI.esc(t('checkOut'))} ✓</h2>
        <div class="big">${UI.esc(r.member.name)}</div>
        <div class="detail">${UI.esc(t('duration'))}: <strong>${UI.fmtDur(r.duration_seconds)}</strong></div>
        <div class="time">${UI.fmtTime(r.check_in_at)} → ${UI.fmtTime(r.check_out_at)}</div>`;
    } else if (r.ok) {
      el.innerHTML = `
        <h2 style="color:var(--green)">${UI.esc(r.offline || r.action === 'queued' ? t('pendingSync') : t('accessGranted'))}</h2>
        ${r.action === 'check_in' ? `<div style="font-size:.9rem;color:var(--cyan);font-weight:700">${UI.esc(t('checkIn'))} · ${UI.fmtTime(r.check_in_at)}</div>` : ''}
        <div class="big">${UI.esc(r.member?.name || '')}</div>
        ${r.member?.plan ? `<div class="detail">${UI.esc(r.member.plan)}</div>` : ''}
        ${r.member?.valid_until ? `<div class="detail">${UI.esc(t('validUntil'))}: ${UI.fmtDate(r.member.valid_until)}</div>` : ''}
        ${r.offline ? `<div class="detail" style="color:var(--amber)">⚠ ${UI.esc(t('offline'))}</div>` : ''}`;
    } else if (r.reason === 'cooldown') {
      el.innerHTML = `<h2 style="color:var(--amber)">${UI.esc(t('checkIn'))}/${UI.esc(t('checkOut'))} ✓</h2>
        <div class="big">${UI.esc(r.member?.name || '')}</div>
        <div class="detail">${UI.esc(t('cooldown'))}</div>`;
    } else {
      el.innerHTML = `
        <h2 style="color:var(--red)">${UI.esc(t('accessDenied'))}</h2>
        <div class="detail">${UI.esc(reasonText[r.reason] || r.reason || '—')}</div>`;
    }
    setTimeout(() => el.classList.remove('show'), 3400);
  }

  function pauseScan() { if (scanner && scanner.pause) scanner.pause(true); }
  function resumeScan() { try { if (scanner && scanner.resume) scanner.resume(); } catch { } }

  // ------------------------------------------------------------ Réseau
  window.addEventListener('online', () => { online = true; $('#net') && ($('#net').innerHTML = netPill()); flushQueue(); refreshStats(); });
  window.addEventListener('offline', () => { online = false; $('#net') && ($('#net').innerHTML = netPill()); });

  // ------------------------------------------------------------ Boot
  document.documentElement.lang = GYM_STATE.lang;
  document.documentElement.dir = I18N[GYM_STATE.lang].dir;
  const urlToken = new URLSearchParams(location.search).get('device');
  if (urlToken) localStorage.setItem(DEV_KEY, urlToken);
  const savedToken = localStorage.getItem(DEV_KEY);
  if (savedToken) {
    DB.registerDeviceByToken(savedToken)
      .then(d => { device = d; startMain(); })
      .catch(() => renderSetup(t('deviceInvalid')));
  } else renderSetup();
})();
