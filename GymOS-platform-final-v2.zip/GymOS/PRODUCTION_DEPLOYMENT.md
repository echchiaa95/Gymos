# GymOS — Production Deployment Checklist

## 1. Supabase
1. Create a new Supabase project.
2. Open **SQL Editor**.
3. Run the complete `supabase/schema.sql` once, from top to bottom.
4. Create the first owner in **Authentication → Users**.
5. Create the corresponding `profiles` row with the correct `org_id`, `branch_id`, and `role='owner'`.
6. Create the organization and first branch before creating the owner profile if they do not already exist.
7. Create membership plans.
8. Create the entrance tablet device and keep its `device_token` private.

### Important
- Only the Supabase **anon/publishable key** belongs in `app/js/config.js`.
- Never put `service_role` or any secret key in the PWA.
- The tablet device token is a credential: do not publish it in screenshots or source repositories.

## 2. Configure the PWA
Edit `app/js/config.js`:

```js
window.GYM_CONFIG = {
  supabaseUrl: 'https://YOUR_PROJECT.supabase.co',
  supabaseAnonKey: 'YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY',
  appName: 'GymOS',
  demoPassword: 'gymos123'
};
```

`demoPassword` is used only by local demo mode and is not a Supabase production credential.

## 3. Deployment
GymOS is a static PWA. It can be deployed to Netlify, Vercel, GitHub Pages, Cloudflare Pages, S3/CloudFront, or another static host.

Publish the contents of `app/` as the site root.

Required pages:
- `/index.html` — administration
- `/entry.html` — entrance tablet

HTTPS is required for camera access on the entrance tablet.

## 4. Entrance Tablet
1. Open `/entry.html` on the Android tablet.
2. Configure the device token once.
3. Grant camera permission.
4. Use the rear camera (`environment`).
5. Keep the tablet in kiosk/full-screen mode if possible.
6. Test one member through CHECK-IN and CHECK-OUT.
7. Disable automatic screen sleep if the gym uses the tablet continuously.

## 5. First production acceptance test
Run these in order:

1. Create member → permanent QR created.
2. Generate PDF card.
3. Scan → CHECK-IN.
4. Scan again after cooldown → CHECK-OUT.
5. Expire membership → access denied.
6. Renew → same QR, new membership history record.
7. Change phone/name → same QR.
8. Freeze membership → access denied during freeze.
9. Scan while offline → event queued.
10. Restore internet → event syncs once.
11. Add cash membership payment → finance updated.
12. Add cash expense → cash register updated.
13. Verify another branch cannot see the first branch's data.
14. Verify receptionist cannot access owner-only settings.
15. Revoke QR explicitly → old QR stops working.

## 6. Backup
Before the first real gym deployment:
- enable Supabase database backups appropriate for the plan;
- export a schema copy;
- keep a copy of the production configuration outside Git;
- never commit credentials or device tokens.

## 7. Go-live rule
Do not start real member operations until the acceptance test above passes against the actual Supabase project. Local/demo mode is not a substitute for the production test.
