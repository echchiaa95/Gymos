-- GymOS — Superadmin setup
-- Exact Auth UID supplied for the platform owner.
-- Run AFTER supabase/platform_upgrade.sql.

insert into public.platform_admins(user_id)
values ('57582ebd-69f5-4c22-9eb9-7b6b8ccc188b')
on conflict (user_id) do nothing;

-- Verification
select
  pa.user_id,
  u.email,
  pa.created_at
from public.platform_admins pa
join auth.users u on u.id = pa.user_id
where pa.user_id = '57582ebd-69f5-4c22-9eb9-7b6b8ccc188b';
