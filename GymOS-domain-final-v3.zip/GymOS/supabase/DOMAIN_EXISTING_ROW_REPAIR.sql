-- GymOS — repair existing Domain rows whose TXT fields are blank
-- Run once after DOMAIN_RPC_FIX / FINAL DOMAIN REPAIR.

update public.organization_domains
set
  verification_token = coalesce(
    nullif(verification_token, ''),
    'gymos-' || replace(gen_random_uuid()::text, '-', '')
  ),
  verification_name = coalesce(
    nullif(verification_name, ''),
    '_gymos-verification.' || hostname
  ),
  verification_value = coalesce(
    nullif(verification_value, ''),
    'gymos-verification=' || coalesce(
      nullif(verification_token, ''),
      'gymos-' || replace(gen_random_uuid()::text, '-', '')
    )
  ),
  updated_at = now()
where verification_name is null
   or verification_name = ''
   or verification_value is null
   or verification_value = '';

notify pgrst, 'reload schema';

select
  id,
  org_id,
  hostname,
  verified,
  verification_name,
  verification_value
from public.organization_domains
order by created_at desc;
