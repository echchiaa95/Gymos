-- GymOS DOMAIN FINAL REPAIR
-- Fixes the current gen_random_bytes error and removes the conflicting old RPC signature.

-- The PWA calls: platform_request_domain(uuid, text)
drop function if exists public.platform_request_domain(text, uuid);
drop function if exists public.platform_request_domain(uuid, text);

create or replace function public.platform_request_domain(
  p_org_id uuid,
  p_hostname text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_host text;
  v_token text;
  v_row public.organization_domains%rowtype;
begin
  if not public.is_platform_admin() then
    raise exception 'PLATFORM_ADMIN_REQUIRED';
  end if;

  if not exists (select 1 from public.organizations where id = p_org_id) then
    raise exception 'GYM_NOT_FOUND';
  end if;

  v_host := public.normalize_gym_hostname(p_hostname);

  if v_host = '' then
    raise exception 'DOMAIN_REQUIRED';
  end if;

  if v_host !~ '^[a-z0-9][a-z0-9.-]+\.[a-z]{2,}$' then
    raise exception 'INVALID_DOMAIN';
  end if;

  select verification_token
    into v_token
  from public.organization_domains
  where hostname = v_host
  limit 1;

  if v_token is null or v_token = '' then
    -- Built-in PostgreSQL UUID generation; no pgcrypto/gen_random_bytes dependency.
    v_token := 'gymos-' || replace(gen_random_uuid()::text, '-', '');
  end if;

  update public.organization_domains
  set is_primary = false,
      updated_at = now()
  where org_id = p_org_id;

  insert into public.organization_domains(
    org_id,
    hostname,
    is_primary,
    verified,
    verification_token,
    verification_name,
    verification_value,
    verified_at,
    updated_at
  )
  values(
    p_org_id,
    v_host,
    true,
    false,
    v_token,
    '_gymos-verification.' || v_host,
    'gymos-verification=' || v_token,
    null,
    now()
  )
  on conflict(hostname) do update set
    org_id = excluded.org_id,
    is_primary = true,
    verified = false,
    verification_token = coalesce(public.organization_domains.verification_token, excluded.verification_token),
    verification_name = '_gymos-verification.' || excluded.hostname,
    verification_value = 'gymos-verification=' || coalesce(public.organization_domains.verification_token, excluded.verification_token),
    verified_at = null,
    updated_at = now()
  returning * into v_row;

  return jsonb_build_object(
    'ok', true,
    'domain_id', v_row.id,
    'org_id', v_row.org_id,
    'hostname', v_row.hostname,
    'verified', v_row.verified,
    'verification_type', 'TXT',
    'verification_name', v_row.verification_name,
    'verification_value', v_row.verification_value
  );
end;
$$;

revoke execute on function public.platform_request_domain(uuid, text) from public;
grant execute on function public.platform_request_domain(uuid, text) to authenticated;

notify pgrst, 'reload schema';

select p.oid::regprocedure as function_signature
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname = 'platform_request_domain';
