-- GymOS Domain RPC hotfix
-- Run this once in Supabase SQL Editor when Superadmin shows:
-- "Could not find the function public.platform_request_domain(p_org_id, p_hostname) in the schema cache"
-- This recreates the exact RPC signature used by the frontend.

create extension if not exists pgcrypto;

alter table public.organizations
  add column if not exists slug text;

create unique index if not exists uq_organizations_slug
  on public.organizations(slug)
  where slug is not null;

create table if not exists public.organization_domains (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.organizations(id) on delete cascade,
  hostname text not null unique,
  is_primary boolean not null default true,
  verified boolean not null default false,
  verification_token text unique,
  verification_name text,
  verification_value text,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.organization_domains
  add column if not exists verification_token text;

alter table public.organization_domains
  add column if not exists verification_name text;

alter table public.organization_domains
  add column if not exists verification_value text;

alter table public.organization_domains
  add column if not exists verified_at timestamptz;

create unique index if not exists uq_org_domains_verification_token
  on public.organization_domains(verification_token)
  where verification_token is not null;

create or replace function public.normalize_gym_hostname(p_hostname text)
returns text
language sql
immutable
as $$
  select lower(
    split_part(
      regexp_replace(trim(coalesce(p_hostname,'')), '^https?://', ''),
      '/',
      1
    )
  );
$$;

create or replace function public.is_platform_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1
    from public.platform_admins
    where user_id = auth.uid()
  );
$$;

-- Exact RPC signature expected by app/js/db.js:
-- platform_request_domain(uuid, text)
create or replace function public.platform_request_domain(
  p_org_id uuid,
  p_hostname text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_host text := public.normalize_gym_hostname(p_hostname);
  v_token text;
  v_row public.organization_domains%rowtype;
begin
  if not public.is_platform_admin() then
    raise exception 'PLATFORM_ADMIN_REQUIRED';
  end if;

  if not exists (
    select 1 from public.organizations where id = p_org_id
  ) then
    raise exception 'GYM_NOT_FOUND';
  end if;

  if v_host = '' then
    raise exception 'DOMAIN_REQUIRED';
  end if;

  select verification_token
    into v_token
  from public.organization_domains
  where hostname = v_host
  limit 1;

  if v_token is null then
    v_token := 'gymos-' || replace(gen_random_uuid()::text, '-', '');
  end if;

  update public.organization_domains
  set is_primary = false
  where org_id = p_org_id;

  insert into public.organization_domains (
    org_id,
    hostname,
    is_primary,
    verified,
    verification_token,
    verification_name,
    verification_value,
    verified_at
  )
  values (
    p_org_id,
    v_host,
    true,
    false,
    v_token,
    '_gymos-verification.' || v_host,
    'gymos-verification=' || v_token,
    null
  )
  on conflict (hostname) do update
  set
    org_id = excluded.org_id,
    is_primary = true,
    verified = false,
    verification_token = coalesce(
      public.organization_domains.verification_token,
      excluded.verification_token
    ),
    verification_name = excluded.verification_name,
    verification_value = excluded.verification_value,
    verified_at = null
  returning * into v_row;

  return jsonb_build_object(
    'id', v_row.id,
    'org_id', v_row.org_id,
    'hostname', v_row.hostname,
    'verified', v_row.verified,
    'status', 'pending',
    'dns_type', 'TXT',
    'dns_name', v_row.verification_name,
    'dns_value', v_row.verification_value
  );
end;
$$;

create or replace function public.platform_confirm_domain(
  p_org_id uuid,
  p_hostname text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_host text := public.normalize_gym_hostname(p_hostname);
  v_row public.organization_domains%rowtype;
begin
  if not public.is_platform_admin() then
    raise exception 'PLATFORM_ADMIN_REQUIRED';
  end if;

  update public.organization_domains
  set verified = true,
      verified_at = now(),
      is_primary = true
  where org_id = p_org_id
    and hostname = v_host
  returning * into v_row;

  if not found then
    raise exception 'DOMAIN_NOT_FOUND';
  end if;

  update public.organization_domains
  set is_primary = false
  where org_id = p_org_id
    and id <> v_row.id;

  return jsonb_build_object(
    'id', v_row.id,
    'hostname', v_row.hostname,
    'verified', true,
    'verified_at', v_row.verified_at
  );
end;
$$;

revoke execute on function public.platform_request_domain(uuid,text) from public;
grant execute on function public.platform_request_domain(uuid,text) to authenticated;

revoke execute on function public.platform_confirm_domain(uuid,text) from public;
grant execute on function public.platform_confirm_domain(uuid,text) to authenticated;

-- Ask PostgREST/Supabase API to refresh its schema cache immediately.
notify pgrst, 'reload schema';

-- Verification:
select
  p.oid::regprocedure as function_signature
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname = 'platform_request_domain';

-- ============================================================================
-- 13. PLATFORM LIST ORGANIZATIONS — include domain verification details
-- ============================================================================

create or replace function public.platform_list_organizations()
returns table(
    id uuid,
    name text,
    slug text,
    active boolean,
    created_at timestamptz,
    primary_domain text,
    domain_verified boolean,
    domain_verification_name text,
    domain_verification_value text,
    branch_count bigint,
    member_count bigint
)
language sql
security definer
set search_path = public
as $$
    select
        o.id,
        o.name,
        o.slug,
        true as active,
        o.created_at,
        d.hostname as primary_domain,
        coalesce(d.verified, false) as domain_verified,
        d.verification_name as domain_verification_name,
        d.verification_value as domain_verification_value,
        (
            select count(*)
            from public.branches b
            where b.org_id = o.id
        ) as branch_count,
        (
            select count(*)
            from public.members m
            where m.org_id = o.id
        ) as member_count
    from public.organizations o
    left join lateral (
        select od.*
        from public.organization_domains od
        where od.org_id = o.id
          and od.is_primary = true
        order by od.created_at desc
        limit 1
    ) d on true
    where public.is_platform_admin()
    order by o.created_at desc;
$$;

revoke execute
on function public.platform_list_organizations()
from public;

grant execute
on function public.platform_list_organizations()
to authenticated;

notify pgrst, 'reload schema';
