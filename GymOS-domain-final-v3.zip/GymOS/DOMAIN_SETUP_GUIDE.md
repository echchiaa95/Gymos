# GymOS — Custom Domain Workflow

GymOS does not require a domain when a Gym is created.

Later, the Superadmin can open **Superadmin → Domain**, enter the real domain, and generate a DNS verification challenge.

The platform displays:

- Type: `TXT`
- Name: `_gymos-verification.your-domain.com`
- Value: `gymos-verification=gymos-...`

The Gym owner copies that TXT record into the DNS panel of the domain provider.

After the record has been added, the Superadmin confirms the domain in GymOS. Only then does `resolve_organization_by_domain()` return the Gym.

## Important hosting note

DNS verification and GymOS tenant mapping are separate from the hosting provider. The domain must eventually point to a hosting service that serves the GymOS application. The current GitHub Pages deployment can serve the public app, but GitHub Pages is not intended to be a multi-tenant custom-domain router for an unlimited number of Gym domains. For many custom Gym domains, use a hosting layer that supports multiple custom domains and serves the same static GymOS app.

No Supabase service-role key is placed in the frontend.

## Domain RPC hotfix

If the Superadmin Domain dialog reports that `public.platform_request_domain(uuid,text)` is missing from the schema cache, run `DOMAIN_RPC_FIX.sql` once in Supabase SQL Editor. It recreates the exact RPC signature used by the PWA and asks PostgREST to reload its schema cache.
