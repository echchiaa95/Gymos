// GymOS — Superadmin / Platform management
(() => {
  Pages.superadmin = async (el) => {
    if (!GYM_STATE.user?.platformAdmin) {
      el.innerHTML = ''; el.appendChild(UI.empty('Accès refusé', 'Cette page est réservée au Superadmin.')); return;
    }

    const $ = (sel, root = document) => root.querySelector(sel);
    const toast = (...args) => UI.toast(...args);

    async function render() {
      const gyms = await DB.platformListOrganizations();
      el.innerHTML = `
        <div class="row mb"><div><strong style="font-size:1.1rem">GymOS Platform</strong><div class="small muted">Gyms, branches et domaines personnalisés</div></div><div class="spacer"></div><button class="btn primary" id="sa-add">＋ Ajouter un gym</button></div>
        <div class="grid three">
          <div class="card stat"><div class="lbl">Gyms</div><div class="val">${gyms.length}</div></div>
          <div class="card stat"><div class="lbl">Branches</div><div class="val">${gyms.reduce((s,g)=>s+Number(g.branch_count||0),0)}</div></div>
          <div class="card stat"><div class="lbl">Membres</div><div class="val">${gyms.reduce((s,g)=>s+Number(g.member_count||0),0)}</div></div>
        </div>
        <div class="table-wrap mt"><table><thead><tr><th>Gym</th><th>Slug</th><th>Domaine</th><th>État</th><th>Branches</th><th>Membres</th><th></th></tr></thead><tbody>
          ${gyms.map(g=>`<tr>
            <td><strong>${UI.esc(g.name)}</strong></td>
            <td><code>${UI.esc(g.slug||'—')}</code></td>
            <td dir="ltr">${UI.esc(g.primary_domain||'—')}</td>
            <td>${g.primary_domain ? UI.badge(g.domain_verified ? 'Vérifié' : 'En attente', g.domain_verified ? 'green' : 'amber') : UI.badge('Aucun','gray')}</td>
            <td>${g.branch_count||0}</td><td>${g.member_count||0}</td>
            <td><button class="btn sm" data-domain="${g.id}">Domaine</button></td>
          </tr>`).join('') || `<tr><td colspan="7"><p class="muted" style="padding:16px">Aucun gym</p></td></tr>`}
        </tbody></table></div>`;
      $('#sa-add',el).onclick=()=>openGymForm();
      el.querySelectorAll('[data-domain]').forEach(b=>b.onclick=()=>{
        const g=gyms.find(x=>x.id===b.dataset.domain); openDomainForm(g);
      });
    }

    function openGymForm(){
      UI.modal({title:'Ajouter un gym',wide:true,body:`
        <label>Nom du gym <span class="req">*</span></label><input name="name" placeholder="الجيم اليمانية">
        <div class="form-grid"><div><label>Slug</label><input name="slug" dir="ltr" placeholder="gym-yemen"></div><div><label>Branche principale</label><input name="branch" value="Main Branch"></div></div>
        <div class="card mt" style="padding:12px"><strong>Domain</strong><p class="small muted">Le domaine se configure plus tard depuis la fiche du gym. GymOS générera alors un texte TXT de vérification à copier chez le registrar.</p></div>`,
        onSubmit:async(body,close)=>{const name=body.querySelector('[name=name]').value.trim();if(!name)throw new Error('Nom du gym requis');await DB.platformCreateGym(name,body.querySelector('[name=slug]').value.trim(),body.querySelector('[name=branch]').value.trim());toast('Gym créé');close();render();}
      });
    }

    function openDomainForm(g){
      const hasDomain = !!g.primary_domain;
      const dnsBlock = hasDomain ? `
        <div class="card mt" style="padding:14px">
          <strong>Vérification DNS</strong>
          <p class="small muted mt">Ajoutez ce TXT chez le fournisseur du domaine, puis revenez ici et confirmez.</p>
          <div class="small mt"><strong>Type:</strong> TXT</div>
          <div class="small"><strong>Nom:</strong> <code dir="ltr">${UI.esc(g.domain_verification_name||'—')}</code></div>
          <div class="small" style="word-break:break-all"><strong>Valeur:</strong> <code dir="ltr">${UI.esc(g.domain_verification_value||'—')}</code></div>
          <div class="row mt" style="flex-wrap:wrap">
            <button class="btn sm" id="copy-dns-name">Copier le nom</button>
            <button class="btn sm" id="copy-dns-value">Copier la valeur</button>
          </div>
        </div>` : '';
      const modal = UI.modal({title:'Domaine — '+g.name,wide:true,body:`
        <label>Domain</label><input name="domain" dir="ltr" value="${UI.esc(g.primary_domain||'')}" placeholder="gym.example.com" autocomplete="off">
        ${dnsBlock}
        <p class="small muted mt">Le domaine n'est pas considéré comme actif tant que le TXT de vérification n'a pas été ajouté et confirmé.</p>`,
        actions:`<button class="btn ghost" data-a="close">Fermer</button><button class="btn" data-a="request">Générer / régénérer la vérification</button>${g.primary_domain && !g.domain_verified ? '<button class="btn success" data-a="confirm">Confirmer après DNS</button>' : ''}`
      });
      modal.el.querySelector('[data-a=close]').onclick=()=>modal.close();
      modal.el.querySelector('[data-a=request]').onclick=async()=>{
        const d=modal.el.querySelector('[name=domain]').value.trim();
        if(!d) return toast('Domaine requis','warn');
        try { await DB.platformRequestDomain(g.id,d); toast('TXT de vérification généré'); modal.close(); render(); openDomainForm((await DB.platformListOrganizations()).find(x=>x.id===g.id)); }
        catch(e){ toast(e.message,'err'); }
      };
      const confirm=modal.el.querySelector('[data-a=confirm]');
      if(confirm) confirm.onclick=async()=>{
        const d=modal.el.querySelector('[name=domain]').value.trim();
        try { await DB.platformConfirmDomain(g.id,d); toast('Domaine vérifié'); modal.close(); render(); }
        catch(e){ toast(e.message,'err'); }
      };
      const cn=modal.el.querySelector('#copy-dns-name'), cv=modal.el.querySelector('#copy-dns-value');
      if(cn) cn.onclick=()=>{navigator.clipboard?.writeText(g.domain_verification_name||'');toast('Copié');};
      if(cv) cv.onclick=()=>{navigator.clipboard?.writeText(g.domain_verification_value||'');toast('Copié');};
    }

    await render();
  };
})();
